/*****************************************
* Author: Kobi Conn
* Filename: main.cpp
* Date Created: 4/12/22
* Modifications:
*****************************************/
/*****************************************
*
* Lab/Assignment: List Based Queue
*
* Overview:
*	This program will test all of the functions in the templated
*	Queue class with both primitive and complex types.
*
* Input:
*	There is no inputs
*
* Output:
*	Displays whether the test for any of the functions passes or fails in console.
*	Output will be in the form : X function test passed/failed
*****************************************/
#define _CRTDBG_MAP_ALLOC
typedef bool(*FunctionPointer)();  // Define a funtion pointer type
#include <string>
using std::string;
#include <iostream>
using std::cout;
using std::cin;
#include <crtdbg.h>
#include "queue.h"
// Strings to test
const char* NAMES[] = { "Kyle", "Brit", "seth", "Alex", "Josh", "Kian",
"Kate", "Terry", "Ann", "Elaine", "Stephanie", "Wanda", "Oscar",
"Oliver", "Tobey" };
const int NUM_NAMES = 15;
// Test function declaration
bool test_default_ctor();
bool test_copy_ctor();
bool test_move_ctor();
bool test_copy_assignment();
bool test_move_assignment();
bool test_enqueue();
bool test_dequeue();
bool test_peek();
bool test_getsize();
bool test_isempty();
//
// Complex tests
bool test_default_ctor_complex();
bool test_copy_ctor_complex();
bool test_move_ctor_complex();
bool test_copy_assignment_complex();
bool test_move_assignment_complex();
bool test_enqueue_complex();
bool test_dequeue_complex();
bool test_peek_complex();
bool test_getsize_complex();
bool test_isempty_complex();

FunctionPointer test_functions[] =
{
	test_default_ctor
	,test_copy_ctor
	,test_move_ctor
	,test_copy_assignment
	,test_move_assignment
	,test_enqueue
	,test_dequeue
	,test_peek
	,test_getsize
	,test_isempty
	,test_default_ctor_complex
	,test_copy_ctor_complex
	,test_move_ctor_complex
	,test_copy_assignment_complex
	,test_move_assignment_complex
	,test_enqueue_complex
	,test_dequeue_complex
	,test_peek_complex
	,test_getsize_complex
	,test_isempty_complex
};

int main()
{
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
	// Run the test functions
	for (FunctionPointer func : test_functions)
	{
		if (func())
		{
			cout << "passed\n";
		}
		else
		{
			cout << "***** failed *****\n";
		}
	}
	cout << "\nPress Any Key to Exit";

	cin.get();
	return 0;
}
bool test_default_ctor()
{
	bool passed = true;
	Queue<int> test;
	if (!test.isEmpty()) //if it isn't empty
	{
		passed = false;
	}
	cout << "default ctor test ";
	return passed;
}
bool test_copy_ctor()
{
	bool passed = true;
	Queue<int> test;
	test.Enqueue(5);
	Queue<int> test2(test);
	if (test.Dequeue() != 5)
	{
		passed = false;
	}
	if (test2.Dequeue() != 5)
	{
		passed = false;
	}
	cout << "copy ctor test ";
	return passed;
}
bool test_move_ctor()
{
	bool passed = false;
	Queue<int> test;
	test.Enqueue(5);
	Queue<int> test2(std::move(test));
	try
	{
		test.Dequeue();
	}
	catch (Exception a)
	{
		passed = true;
	}
	if (test2.Dequeue() != 5)
	{
		passed = false;
	}
	cout << "move ctor test ";
	return passed;
}
bool test_copy_assignment()
{
	bool passed = true;
	Queue<int> test;
	test.Enqueue(5);
	Queue<int> test2;
	test2 = test;
	test2 = test2; //self assignment not ruin data
	if (test2.Dequeue() != 5)
	{
		passed = false;
	}
	cout << "copy assignment test ";
	return passed;
}
bool test_move_assignment()
{
	bool passed = true;
	Queue<int> test;
	test.Enqueue(5);
	Queue<int> test2;
	test2 = std::move(test);
	test2 = std::move(test2); //self assignment not ruin data
	if (test2.Dequeue() != 5)
	{
		passed = false;
	}
	cout << "move assignment test ";
	return passed;
}
bool test_enqueue()
{
	bool passed = true;
	Queue<int> test;
	for (int i = 0; i < 10; ++i)
	{
		test.Enqueue(i);
	}
	if (test.getSize() != 10)
	{
		passed = false;
	}
	if (test.Dequeue() != 0)
	{
		passed = false;
	}
	cout << "enqueue test ";
	return passed;
}
bool test_dequeue()
{
	bool passed = false;
	Queue<int> test;
	try
	{
		test.Dequeue();
	}
	catch (Exception a)
	{
		passed = true;
	}
	for (int i = 0; i < 5; ++i)
	{
		test.Enqueue(i);
		if (test.getSize() != i+1)
		{
			passed = false;
		}
	}
	for (int i = 0; i < 5; ++i)
	{
		if (test.Dequeue() != i)
		{
			passed = false;
		}
	}
	if (test.getSize() != 0)
	{
		passed = false;
	}
	cout << "dequeue test ";
	return passed;
}
bool test_peek()
{
	bool passed = false;
	Queue<int> test;
	try
	{
		test.Peek();
	}
	catch (Exception a)
	{
		passed = true;
	}
	test.Enqueue(5);
	if (test.Peek() != 5)
	{
		passed = false;
	}
	cout << "peek test ";
	return passed;
}
bool test_getsize()
{
	bool passed = true;
	Queue<int> test;
	for (int i = 0; i < 5; ++i)
	{
		test.Enqueue(i);
	}
	if (test.getSize() != 5)
	{
		passed = false;
	}
	cout << "getsize test ";
	return passed;
}
bool test_isempty()
{
	bool passed = true;
	Queue<int> test;
	if (test.isEmpty() != true)
	{
		passed = false;
	}
	test.Enqueue(5);
	if (test.isEmpty() != false)
	{
		passed = false;
	}
	cout << "isempty test ";
	return passed;
}

bool test_default_ctor_complex()
{
	bool passed = true;
	Queue<string> test;
	if (!test.isEmpty()) //if it isn't empty
	{
		passed = false;
	}
	cout << "default ctor test complex ";
	return passed;
}
bool test_copy_ctor_complex()
{
	bool passed = true;
	Queue<string> test;
	test.Enqueue(NAMES[0]);
	Queue<string> test2(test);
	if (test.Dequeue() != NAMES[0])
	{
		passed = false;
	}
	if (test2.Dequeue() != NAMES[0])
	{
		passed = false;
	}
	cout << "copy ctor test complex ";
	return passed;
}
bool test_move_ctor_complex()
{
	bool passed = false;
	Queue<string> test;
	test.Enqueue(NAMES[0]);
	Queue<string> test2(std::move(test));
	try
	{
		test.Dequeue();
	}
	catch (Exception a)
	{
		passed = true;
	}
	if (test2.Dequeue() != NAMES[0])
	{
		passed = false;
	}
	cout << "move ctor test complex ";
	return passed;
}
bool test_copy_assignment_complex()
{
	bool passed = true;
	Queue<string> test;
	test.Enqueue(NAMES[0]);
	Queue<string> test2;
	test2 = test;
	test2 = test2; //self assignment not ruin data
	if (test2.Dequeue() != NAMES[0])
	{
		passed = false;
	}
	cout << "copy assignment test complex ";
	return passed;
}
bool test_move_assignment_complex()
{
	bool passed = true;
	Queue<string> test;
	test.Enqueue(NAMES[0]);
	Queue<string> test2;
	test2 = std::move(test);
	test2 = std::move(test2); //self assignment not ruin data
	if (test2.Dequeue() != NAMES[0])
	{
		passed = false;
	}
	cout << "move assignment test complex ";
	return passed;
}
bool test_enqueue_complex()
{
	bool passed = true;
	Queue<string> test;
	for (int i = 0; i < 10; ++i)
	{
		test.Enqueue(NAMES[i]);
	}
	if (test.getSize() != 10)
	{
		passed = false;
	}
	if (test.Dequeue() != NAMES[0])
	{
		passed = false;
	}
	cout << "enqueue test complex ";
	return passed;
}
bool test_dequeue_complex()
{
	bool passed = false;
	Queue<string> test;
	try
	{
		test.Dequeue();
	}
	catch (Exception a)
	{
		passed = true;
	}
	for (int i = 0; i < 5; ++i)
	{
		test.Enqueue(NAMES[i]);
	}
	if (test.getSize() != 5)
	{
		passed = false;
	}
	for (int i = 0; i < 5; ++i)
	{
		if (test.Dequeue() != NAMES[i])
		{
			passed = false;
		}
	}
	if (test.getSize() != 0)
	{
		passed = false;
	}
	cout << "dequeue test complex ";
	return passed;
}
bool test_peek_complex()
{
	bool passed = false;
	Queue<string> test;
	try
	{
		test.Peek();
	}
	catch (Exception a)
	{
		passed = true;
	}
	test.Enqueue(NAMES[0]);
	if (test.Peek() != NAMES[0])
	{
		passed = false;
	}

	cout << "peek test complex ";
	return passed;
}
bool test_getsize_complex()
{
	bool passed = true;
	Queue<string> test;
	for (int i = 0; i < 5; ++i)
	{
		test.Enqueue(NAMES[i]);
	}
	if (test.getSize() != 5)
	{
		passed = false;
	}
	cout << "getsize test complex ";
	return passed;
}
bool test_isempty_complex()
{
	bool passed = true;
	Queue<string> test;
	if (test.isEmpty() != true)
	{
		passed = false;
	}
	test.Enqueue(NAMES[0]);
	if (test.isEmpty() != false)
	{
		passed = false;
	}
	cout << "isempty test complex ";
	return passed;
}