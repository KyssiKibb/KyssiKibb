#pragma once
/*****************************************
* Author: Kobi Conn
* Filename: hashtable.h
* Date Created: 4/29/22
* Modifications:
*****************************************/

#include<utility>
#include <vector>
#include <list>
#include "exception.h"

using std::pair;
using std::vector;
using std::list;
using std::get;
using std::make_pair;

/*****************************************
* Class: HashTable
*
* Purpose: This class holds pointers to Node<T> objects that contain any type of data that we want. automatically resizes itself and manipulates data
*
* Manager functions:
*		HashTable ( )
*			The default for m_hashtable is the default ctor for vector, m_buckets is 0, and m_hash is nullptr
*		HashTable (int buckets)
*			instantiates HashTable where m_buckets and size of m_hashtable are initialized to input value
*		HashTable (int buckets,  int (*hash)(K key))
*			instantiates HashTable where m_buckets gets set to buckets and m_hash gets set to hash
*		~HashTable ( )
*			Deletes all allocated memory in m_hashtable, resets m_buckets to 0, and resets m_hash to nullptr
*		HashTable (const HashTable<T> & copy)
*		HashTable (HashTable<T> && copy)
*			moves data from copy into current object
*		operator = (const HashTable<T> & rhs)
*		operator = (HashTable<T> && rhs)
*			moves data from rhs into current object
*
* Methods:
*		Purge ( )
*			resets data members to default state
*		Insert (K key, V value)
*			inserts Key Value pair into hash table in correct bucket
*		setHash (int (*hash)(K key))
*			sets m_hash to hash, rehashes data in hashtable
*		setBuckets (int buckets)
*			sets m_buckets to buckets, rehashes data in hashtable
*		operator [] (K key)
*			returns by value the V of the K V Pair using input key
*		Delete (K key)
*			Deletes K V pair with the K that matches key
*		Traverse (void (*visit)(V value))
*			traverses through all K V pairs in each bucket, displaying them with visit function pointer
*		Display (K key, void (*visit)(V value))
*			Displays value paired with key input using the visit function pointer 
*		getBuckets ( )
*			returns m_buckets
*		is_Empty ( )
*			returns true if all buckets are empty, and false if there is any data in hashtable
*****************************************/
template<typename K, typename V>
class HashTable
{
public:
	HashTable();
	~HashTable();
	HashTable(const HashTable<K,V>& copy);
	HashTable(HashTable<K,V>&& copy) noexcept;
	HashTable& operator =(const HashTable<K,V>& rhs);
	HashTable& operator =(HashTable<K,V>&& rhs) noexcept;
	HashTable(int buckets);
	HashTable(int buckets, int (*hash)(K key));

	void Purge();
	void Insert(K key, V value);
	void setHash(int (*hash)(K key));
	void setBuckets(int buckets);
	V operator [](K key);
	void Delete(K key);
	void Traverse(void (*visit)(V value));
	void Display(K key, void (*visit)(V value));
	int getBuckets();
	bool is_Empty();

private:
	void ReHash(int new_buckets);

	vector<list<pair<K, V>>> m_hashtable;
	int m_buckets;
	int (*m_hash)(K key);
};


/*****************************************
* Purpose: instantiate a HashTable with default values
*
* Precondition:
* 
* Postcondition:
*		defaults:
*		m_hashtable() is default ctor of vector
*		m_buckets = 0
*		m_hash = nullptr
*****************************************/
template<typename K, typename V>
HashTable<K, V>::HashTable() : m_hashtable(), m_buckets(0), m_hash(nullptr)
{}


/*****************************************
* Purpose: resets HashTable to default values
*
* Precondition:
*
* Postcondition:
*		Current object is reset to default values
*****************************************/
template<typename K, typename V>
HashTable<K, V>::~HashTable()
{
	Purge();
}


/*****************************************
* Purpose: instantiate a HashTable with copy of input HashTable
*
* Precondition:
*
* Postcondition:
*		m_hashtable holds copy of copy.m_hashtable
*		m_buckets holds copy of copy.m_hashtable
*		m_hash holds copy of copy.m_hash
*****************************************/
template<typename K, typename V>
HashTable<K, V>::HashTable(const HashTable<K, V>& copy) : m_hashtable(copy.m_hashtable), m_buckets(copy.m_buckets), m_hash(copy.m_hash)
{

}


/*****************************************
* Purpose: instantiate a HashTable with copy of input HashTable
*
* Precondition:
*
* Postcondition:
*		current object is instantiated by moving data from copy
*		copy gets reset to default values
*****************************************/
template<typename K, typename V>
HashTable<K, V>::HashTable(HashTable<K, V>&& copy) noexcept : m_hashtable(std::move(copy.m_hashtable)), m_buckets(std::move(copy.m_buckets)), m_hash(std::move(copy.m_hash))
{
	copy.m_buckets = 0; // this is because the move on a primitive type will turn into a copy
	copy.m_hash = nullptr;
}


/*****************************************
* Purpose: assign data in HashTable with input HashTable
*
* Precondition:
*
* Postcondition:
*		if self assignment, does nothing
*		data in current object gets copy of rhs' data
*		returns *this for function chaining
*****************************************/
template<typename K, typename V>
HashTable<K,V>& HashTable<K, V>::operator =(const HashTable<K, V>& rhs)
{
	if (this != &rhs)
	{
		m_hashtable = rhs.m_hashtable;
		m_buckets = rhs.m_buckets;
		m_hash = rhs.m_hash;
	}
	return *this;
}


/*****************************************
* Purpose: move data in HashTable from input HashTable
*
* Precondition:
*
* Postcondition:
*		if self assignment, does nothing
*		data in current object gets moved from rhs
*		rhs gets reset to default values
*		returns *this for function chaining
*****************************************/
template<typename K, typename V>
HashTable<K,V>& HashTable<K, V>::operator =(HashTable<K, V>&& rhs) noexcept
{
	if (this != &rhs)
	{
		m_hashtable = std::move(rhs.m_hashtable);
		m_buckets = std::move(rhs.m_buckets);
		m_hash = std::move(rhs.m_hash);
		rhs.m_buckets = 0;
		rhs.m_hash = nullptr;
	}
	return *this;
}


/*****************************************
* Purpose: instantiate a HashTable with bucket set to input parameter
*
* Precondition:
*
* Postcondition:
*		if buckets is negative, throws exception
*		else, sets m_buckets and m_hashtable's size to buckets
*		m_hash is set to nullptr
*****************************************/
template<typename K, typename V>
HashTable<K, V>::HashTable(int buckets) : m_hashtable(), m_buckets(buckets), m_hash(nullptr)
{
	if (m_buckets < 0)
	{
		throw Exception("Cannot have negative amount of buckets");
	}
	else
	{
		m_hashtable.resize(buckets);
	}
}


/*****************************************
* Purpose: instantiate a HashTable with bucket set to input parameter 1 and m_hash set to input parameter 2
*
* Precondition:
*
* Postcondition:
*		if buckets is negative, throws exception
*		else, sets m_buckets and m_hashtable's size to buckets input
*		m_hash is set to hash input
*****************************************/
template<typename K, typename V>
HashTable<K, V>::HashTable(int buckets, int (*hash)(K key)) : m_hashtable(), m_buckets(buckets), m_hash(hash)
{
	if (m_buckets < 0)
	{
		throw Exception("Cannot have negative amount of buckets");
	}
	else
	{
		m_hashtable.resize(buckets);
	}
}


/*****************************************
* Purpose: resets HashTable to default values
*
* Precondition:
*
* Postcondition:
*		Current object is reset to default values
*****************************************/
template<typename K, typename V>
void HashTable<K, V>::Purge()
{
	m_hashtable.resize(0);
	m_hash = nullptr;
	m_buckets = 0;
}


/*****************************************
* Purpose: Adds key value pair to correct bucket
*
* Precondition:
*
* Postcondition:
*		if there are no buckets, throws exception
*		if there is no m_hash set, throws exception
*		Bucket found after hashing key gets new pair inserted into list
*****************************************/
template<typename K, typename V>
void HashTable<K, V>::Insert(K key, V value)
{
	if (m_buckets == 0)
	{
		throw Exception("Cannot insert with no buckets");
	}
	else
	{
		if (m_hash == nullptr)
		{
			throw Exception("Cannot insert with no hash function set");
		}
		int location = m_hash(key) % m_buckets;
		pair<K, V> new_pair = make_pair(key, value);
		m_hashtable[location].push_back(new_pair);
	}
}


/*****************************************
* Purpose: sets m_hash to new functionpointer
*
* Precondition:
*
* Postcondition:
*		if input hash is nullptr, clears data in hashtable and sets m_hash to nullptr (cannot have data in hashtable with no hash function)
*		else sets m_hash to hash and rehashes data
*****************************************/
template<typename K, typename V>
void HashTable<K, V>::setHash(int (*hash)(K key))
{
	if (hash == nullptr)
	{
		int tempsize = m_buckets;
		Purge();
		m_buckets = tempsize;
		m_hashtable.resize(m_buckets);
	}
	else
	{
		m_hash = hash;
		ReHash(m_buckets);
	}
}


/*****************************************
* Purpose: changes the amount of buckets for hashtable and rearranges data to conform to new size
*
* Precondition:
*
* Postcondition:
*		if buckets is negative, throws exception
*		else, if buckets is 0, purge all data in hashtable
*		if buckets > 0 and m_hash is not nullptr, rehash data into new bucket size
*		else, set bucket size and resize hashtable
*****************************************/
template<typename K, typename V>
void HashTable<K, V>::setBuckets(int buckets)
{
	if (buckets < 0)
	{
		throw Exception("Cannot have negative amount of buckets");
	}
	else
	{
		if (buckets == 0)
		{
			Purge();
		}
		else
		{
			if (m_hash != nullptr)
			{
				ReHash(buckets);
				m_buckets = buckets;
			}
			else
			{
				m_buckets = buckets;
				m_hashtable.resize(buckets);
			}
		}
	}
}


/*****************************************
* Purpose: return V in K V pair using input K
*
* Precondition:
*
* Postcondition:
*		if buckets == 0, throws exception
*		else, traverse through m_hashtable to find key
*		if found, return V associated with that key
*		else, throw exception
*****************************************/
template<typename K, typename V>
V HashTable<K, V>::operator [](K key)
{
	int location = 0;
	V data;
	if (m_buckets == 0)
	{
		throw Exception("Cannot use subscript on Table with no buckets");
	}
	else
	{
		location = m_hash(key) % m_buckets;
		bool found = false;
		auto&& i = m_hashtable[location].begin();
		for (; i != m_hashtable[location].end() && found != true; ++i)
		{
			if (get<0>(*i) == key)
			{
				found = true;
			}
		}
		if (!is_Empty())
		{
			--i;
		}
		if (found == true)
		{
			data = get<1>(*i);
		}
		else
		{
			throw Exception("Data not found in hash table");
		}
	}
	return data;
}


/*****************************************
* Purpose: Removes key value pair from hashtable
*
* Precondition:
*
* Postcondition:
*		if there are no buckets, throws exception
*		else, traverse through m_hashtable to find key
*		if found, deletes key value pair in m_hashtable based on input key
*		if not found, throws exception
*****************************************/
template<typename K, typename V>
void HashTable<K, V>::Delete(K key)
{
	if (m_buckets == 0)
	{
		throw Exception("Cannot delete from hashtable with no buckets");
	}
	else
	{
		int location = m_hash(key) % m_buckets; //what bucket is the data we are looking for in
		bool found = false;
		auto&& i = m_hashtable[location].begin();
		for (; i != m_hashtable[location].end() && found != true; ++i)
		{
			if (get<0>(*i) == key)
			{
				found = true;
			}
		}
		if (!is_Empty())
		{
			--i;
		}
		if (found == true)
		{
			m_hashtable[location].remove(*i);
		}
		else
		{
			throw Exception("Data not found in hash table");
		}
	}
}



/*****************************************
* Purpose: traverses through all elements in hashtable, calling visit function on them
*
* Precondition:
*
* Postcondition:
*		all data in hashtable is visited using the input visit function
*****************************************/
template<typename K, typename V>
void HashTable<K, V>::Traverse(void (*visit)(V value))
{
	for (auto&& i : m_hashtable)
	{
		for (auto&& j : i)
		{
			visit(get<1>(j));
		}
	}
}


/*****************************************
* Purpose: displays contents of value based on input key. display based on input display function
*
* Precondition:
*
* Postcondition:
*		if there are no buckets, throws exception
*		else, traverse through m_hashtable to find key
*		if found, deletes key value pair in m_hashtable based on input key
*		if not found, throws exception
*****************************************/
template<typename K, typename V>
void HashTable<K, V>::Display(K key,void (*visit)(V value))
{
	if (m_buckets == 0)
	{
		throw Exception("Cannot display from hashtable with no buckets");
	}
	else
	{

		int location = m_hash(key) % m_buckets; //what bucket is the data we are looking for in
		bool found = false;
		auto&& i = m_hashtable[location].begin();
		for (; i != m_hashtable[location].end() && found != true; ++i)
		{
			if (get<0>(*i) == key)
			{
				found = true;
			}
		}
		if (!is_Empty())
		{
			--i;
		}
		if (found == true)
		{
			visit(get<1>(*i));
		}
		else
		{
			throw Exception("Key not found in hash table");
		}
	}
}


/*****************************************
* Purpose: return number of buckets
*
* Precondition:
*
* Postcondition:
*		returns m_buckets by value
*****************************************/
template<typename K, typename V>
int HashTable<K, V>::getBuckets()
{
	return m_buckets;
}


/*****************************************
* Purpose: tells whether there is data in hashtable or not
*
* Precondition:
*
* Postcondition:
*		if there is no data in hashtable, return true
*		else, return false
*****************************************/
template<typename K, typename V>
bool HashTable<K, V>::is_Empty()
{
	bool empty = true;
	int traverse = 0;
	for (auto&& i : m_hashtable)
	{
		for (auto&& j : i)
		{
			traverse++;
		}
	}
	if (traverse != 0)
	{
		empty = false;
	}
	return empty;
}


/*****************************************
* Purpose: change locations of data in hashtable based on new hash function / bucket size
*
* Precondition:
*
* Postcondition:
*		hashtable data is in correct buckets based on new bucketsize/hashfunction
*****************************************/
template<typename K, typename V>
void HashTable<K, V>::ReHash(int new_buckets)
{
	vector<list<pair<K, V>>> temp;
	temp.resize(new_buckets);

	int new_location = 0;
	pair<K, V> new_pair;
	for (auto&& i : m_hashtable)
	{
		for (auto&& j : i)
		{
			new_location = m_hash(get<0>(j)) % new_buckets;
			temp[new_location].push_back(j);
		}
	}
	m_hashtable = std::move(temp);
}