/*****************************************
* Author: Kobi Conn
* Filename: main.cpp
* Date Created: 4/29/22
* Modifications:
*****************************************/
/*****************************************
*
* Lab/Assignment: HashTable
*
* Overview:
*	This program will test all of the functions in the templated
*	HashTable class with Book struct
*
* Input:
*	There is no inputs
*
* Output:
*	Displays whether the test for any of the functions passes or fails in console.
*	Output will be in the form : X function test passed/failed
*****************************************/
#define _CRTDBG_MAP_ALLOC
typedef bool(*FunctionPointer)();  // Define a funtion pointer type
#include <string>
using std::string;
#include <iostream>
using std::cout;
using std::cin;
using std::endl;
#include <crtdbg.h>
#include "hashtable.h"

struct Book
{
	string m_title = "";
	string m_author = "";
	int m_pages = 0;
};

const Book BOOKS[5]{ {"C++: Learn by Doing", "Todd Breedlove, Troy Scevers, et. al.", 635}, {"Rodeo for Dummies", "Calvin Caldwell", 1}, {"And That n There", "Ralph Carestia", 1}, {"Data Structures: A Pseudocode Approach with C++", "Richard F. Gilberg and Behrouz A. Forouzan", 746}, {"12 Rules for Life: an Antidote to Chaos", "Jordan Peterson", 448} };
const string ISBN[5]{ "0763757233","7063757233","7063757234","053495216X","9780345816" };

// Test function declaration
bool test_default_ctor();
bool test_1arg_ctor();
bool test_2arg_ctor();
bool test_copy_ctor();
bool test_move_ctor();
bool test_copy_assignment();
bool test_move_assignment();
bool test_insert();
bool test_delete();
bool test_purge();
bool test_sethash();
bool test_setbuckets();
bool test_subscript();
bool test_traverse();
bool test_display();
bool test_getbuckets();
bool test_isempty();

void Display(Book data);
int HashFunc(string data);
int HashFunc2(string data);
bool operator == (const Book& a, const Book& b);

list<Book> traversal;

FunctionPointer test_functions[] =
{
	test_default_ctor
	,test_1arg_ctor
	,test_2arg_ctor
	,test_copy_ctor
	,test_move_ctor
	,test_copy_assignment
	,test_move_assignment
	,test_insert
	,test_delete
	,test_purge
	,test_sethash
	,test_setbuckets
	,test_subscript
	,test_traverse
	,test_display
	,test_getbuckets
	,test_isempty
};


int main()
{
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
	// Run the test functions
	for (FunctionPointer func : test_functions)
	{
		if (func())
		{
			cout << "passed\n";
		}
		else
		{
			cout << "***** failed *****\n";
		}
	}
	cout << "\nPress Any Key to Exit";

	cin.get();
	return 0;
}

bool test_default_ctor()
{
	bool passed = true;
	HashTable<string,Book> test;
	if (test.getBuckets() != 0)
	{
		passed = false;
	}
	cout << "default ctor test ";
	return passed;
}
bool test_1arg_ctor()
{
	bool passed = true;
	HashTable<string, Book> test(5);
	if (test.getBuckets() != 5)
	{
		passed = false;
	}
	cout << "1arg ctor test ";
	return passed;
}
bool test_2arg_ctor()
{
	bool passed = true;
	HashTable<string, Book> test(5,HashFunc);
	if (test.getBuckets() != 5)
	{
		passed = false;
	}
	cout << "2arg ctor test ";
	return passed;
}
bool test_copy_ctor()
{
	bool passed = true;
	HashTable<string, Book> test(5);
	test.setHash(HashFunc);
	test.Insert(ISBN[0],BOOKS[0]);

	HashTable<string, Book> test2(test);
	if (BOOKS[0].m_title != test2[ISBN[0]].m_title)
	{
		passed = false;
	}
	if (BOOKS[0].m_title != test[ISBN[0]].m_title)
	{
		passed = false;
	}
	cout << "copy ctor test ";
	return passed;
}
bool test_move_ctor()
{
	bool passed = false;
	HashTable<string, Book> test(5);
	test.setHash(HashFunc);
	test.Insert(ISBN[0], BOOKS[0]);

	HashTable<string, Book> test2(std::move(test));
	try
	{
		test.Delete(ISBN[0]);
	}
	catch (Exception a)
	{
		passed = true;
	}
	if (BOOKS[0].m_title != test2[ISBN[0]].m_title)
	{
		passed = false;
	}
	cout << "move ctor test ";
	return passed;
}
bool test_copy_assignment()
{
	bool passed = true;
	HashTable<string, Book> test(5);
	test.setHash(HashFunc);
	test.Insert(ISBN[0], BOOKS[0]);

	HashTable<string, Book> test2;
	test2 = test;
	if (BOOKS[0].m_title != test2[ISBN[0]].m_title)
	{
		passed = false;
	}
	if (BOOKS[0].m_title != test[ISBN[0]].m_title)
	{
		passed = false;
	}
	cout << "copy assignment test ";
	return passed;
}
bool test_move_assignment()
{
	bool passed = false;
	HashTable<string, Book> test(5);
	test.setHash(HashFunc);
	test.Insert(ISBN[0], BOOKS[0]);

	HashTable<string, Book> test2;
	test2 = std::move(test);
	try
	{
		test.Delete(ISBN[0]);
	}
	catch (Exception a)
	{
		passed = true;
	}
	if (BOOKS[0].m_title != test2[ISBN[0]].m_title)
	{
		passed = false;
	}
	cout << "move assignment test ";
	return passed;
}

bool test_insert()
{
	bool passed = true;
	HashTable<string, Book> test(5);
	test.setHash(HashFunc);
	for (int i = 0; i < 5; ++i)
	{
		test.Insert(ISBN[i], BOOKS[i]);
	}
	for (int i = 0; i < 5; ++i)
	{
		if (BOOKS[i].m_title != test[ISBN[i]].m_title)
		{
			passed = false;
		}
	}
	cout << "insert test ";
	return passed;
}
bool test_delete()
{
	bool passed = false;
	HashTable<string, Book> test(5);
	test.setHash(HashFunc);
	for (int i = 0; i < 5; ++i)
	{
		test.Insert(ISBN[i], BOOKS[i]);
	}
	for (int i = 0; i < 5; ++i)
	{
		test.Delete(ISBN[i]);
	}
	try
	{
		test.Delete(ISBN[0]);
	}
	catch (Exception a)
	{
		passed = true;
	}
	if (!test.is_Empty())
	{
		passed = false;
	}
	cout << "delete test ";
	return passed;
}
bool test_purge()
{
	bool passed = true;
	HashTable<string, Book> test(5);
	test.setHash(HashFunc);
	for (int i = 0; i < 5; ++i)
	{
		test.Insert(ISBN[i], BOOKS[i]);
	}
	test.Purge();
	if (!test.is_Empty())
	{
		passed = false;
	}
	cout << "purge test ";
	return passed;
}
bool test_sethash()
{
	bool passed = true;
	HashTable<string, Book> test(5);
	test.setHash(HashFunc);
	for (int i = 0; i < 5; ++i)
	{
		test.Insert(ISBN[i], BOOKS[i]);
	}
	test.setHash(HashFunc2);
	for (int i = 0; i < 5; ++i)
	{
		if (BOOKS[i].m_title != test[ISBN[i]].m_title)
		{
			passed = false;
		}
	}
	test.setHash(nullptr);
	if (!test.is_Empty())
	{
		passed = false;
	}
	cout << "sethash test ";
	return passed;
}
bool test_setbuckets()
{
	bool passed = true;
	HashTable<string, Book> test(5);
	test.setHash(HashFunc);
	for (int i = 0; i < 5; ++i)
	{
		test.Insert(ISBN[i], BOOKS[i]);
	}
	test.setBuckets(2);
	for (int i = 0; i < 5; ++i)
	{
		if (BOOKS[i].m_title != test[ISBN[i]].m_title)
		{
			passed = false;
		}
	}
	cout << "setbucket test ";
	return passed;
}
bool test_subscript()
{
	bool passed = true;
	HashTable<string, Book> test(5);
	test.setHash(HashFunc);
	for (int i = 0; i < 5; ++i)
	{
		test.Insert(ISBN[i], BOOKS[i]);
	}
	for (int i = 0; i < 5; ++i)
	{
		if (BOOKS[i].m_title != test[ISBN[i]].m_title)
		{
			passed = false;
		}
	}
	cout << "subscript test ";
	return passed;
}
bool test_traverse()
{
	bool passed = true;
	HashTable<string, Book> test(5);
	test.setHash(HashFunc);
	for (int i = 0; i < 5; ++i)
	{
		test.Insert(ISBN[i], BOOKS[i]);
	}
	test.Traverse(Display);
	if (traversal.size() != 5)
	{
		passed = false;
	}
	traversal.clear();
	cout << "traverse test ";
	return passed;
}
bool test_display()
{
	bool passed = true;
	HashTable<string, Book> test(5);
	test.setHash(HashFunc);
	for (int i = 0; i < 5; ++i)
	{
		test.Insert(ISBN[i], BOOKS[i]);
	}
	test.Display(ISBN[0],Display);
	if (traversal.front().m_title != BOOKS[0].m_title)
	{
		passed = false;
	}
	traversal.clear();
	cout << "display test ";
	return passed;
}
bool test_getbuckets()
{
	bool passed = true;
	HashTable<string, Book> test(5);
	if (test.getBuckets() != 5)
	{
		passed = false;
	}
	test.setBuckets(10);
	if (test.getBuckets() != 10)
	{
		passed = false;
	} 
	cout << "getbuckets test ";
	return passed;
}
bool test_isempty()
{
	bool passed = true;
	HashTable<string, Book> test(5);
	test.setHash(HashFunc);
	if (!test.is_Empty())
	{
		passed = false;
	}
	test.Insert(ISBN[0], BOOKS[0]);
	if (test.is_Empty())
	{
		passed = false;
	}
	cout << "isempty test ";
	return passed;
}
int HashFunc(string data)
{
	int total = 0;
	for (int i = 0; i < static_cast<int>(data.size()); ++i)
	{
		total += static_cast<int>(data[i]);
	}
	return total;
}

int HashFunc2(string data)
{
	int total = 1; // starts at 1 instead of 0 to have different bucket values
	for (int i = 0; i < static_cast<int>(data.size()); ++i)
	{
		total += static_cast<int>(data[i]);
	}
	return total;
}

void Display(Book data)
{
	traversal.push_back(data);
	//cout << data.m_title << endl;
}

bool operator == (const Book& a, const Book& b)
{
	bool same = false;
	if (a.m_author == b.m_author && a.m_title == b.m_title && a.m_pages == b.m_pages)
	{
		same = true;
	}
	return same;
}