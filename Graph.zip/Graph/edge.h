#pragma once
/*****************************************
* Author: Kobi Conn
* Filename: edge.h
* Date Created: 5/10/22
* Modifications: 5/15/22 added documentation for functions
*****************************************/
#include <iostream>
#include "exception.h"

template <typename V, typename E>
class Vertex;

/*****************************************
* Class: Edge
*
* Purpose:  This class holds the data between 2 vertices including : which vertex it is pointing at(m_dest),
*			how much distance(m_weight) is between each object, and what other data type is provided(m_data)
*
* Manager functions:
*		Edge ( )
*			Default values for Edge are: m_data(), m_weight(0), m_dest(nullptr)
*		~Edge ( )
*		Edge (const Edge<V,E> & copy)
*		operator = (const Edge<V,E> & rhs)
*		Edge (Edge<V,E> && copy)
*			constructs an Edge, moving the data from copy. it then resets copy to its default state
*		operator = (Edge<V,E> && rhs)
*			if it is not self reference, it moves data in rhs to current object, and resets rhs to default state
*		Edge(E data, Vertex<V, E>* dest, int weight)
*			3 arg ctor for Edge. values are set to input parameters
* Methods:
*		Bool operator ==(const Edge<V,E>& rhs) const
*			returns true if rhs and current object have same data values, else returns false
*		Bool operator !=(const Edge<V,E>& rhs) const
*			returns false if rhs and current object have same data values, else returns true
*****************************************/
template<typename V, typename E>
class Edge
{
	template<typename V, typename E>
	friend class Graph;
public:
	Edge();
	~Edge();
	Edge(const Edge<V,E>& copy);
	Edge(Edge<V,E>&& copy) noexcept;
	Edge<V,E>& operator =(const Edge<V,E>& rhs);
	Edge<V,E>& operator =(Edge<V,E>&& rhs)noexcept;

	Edge(E data, Vertex<V, E>* dest, int weight);
	bool operator==(const Edge<V,E>& rhs) const;
	bool operator!=(const Edge<V, E>& rhs) const;
private:
	E m_data;
	Vertex<V, E>* m_dest;
	int m_weight;
};


/*****************************************
* Purpose:	Instantiate a default Edge<V,E> object
* Precondition:
* Postcondition:
*		m_data()
*		m_dest(nullptr)
*		m_weight(0)
*****************************************/
template<typename V, typename E>
Edge<V, E>::Edge() : m_data(), m_dest(nullptr), m_weight(0)
{

}


/*****************************************
* Purpose:	reset Edge<V,E> object to default state
* Precondition:
* Postcondition:
*		data members of current object are reset to default state
*****************************************/
template<typename V, typename E>
Edge<V, E>::~Edge()
{
	m_dest = nullptr;
	m_weight = 0;
	m_data = E();
}


/*****************************************
* Purpose:	Instantiate an Edge<V,E> object with input copy
* Precondition:
* Postcondition:
*		current object is instantiated with copies of data in copy
*****************************************/
template<typename V, typename E>
Edge<V, E>::Edge(const Edge<V,E>& copy) : m_data(copy.m_data), m_dest(copy.m_dest), m_weight(copy.m_weight)
{

}


/*****************************************
* Purpose:	Instantiate an Edge<V,E> object with input copy, moving data out of input
* Precondition:
* Postcondition:
*		current object is instantiated with data in copy moved.
*		copy's data is reset to default
*****************************************/
template<typename V, typename E>
Edge<V, E>::Edge(Edge<V, E>&& copy) noexcept : m_data(std::move(copy.m_data)), m_dest(std::move(copy.m_dest)), m_weight(copy.m_weight)
{
	copy.m_dest = nullptr;
	copy.m_data = E();
	copy.m_weight = 0;
}


/*****************************************
* Purpose:	current object gets copy of data in rhs
* Precondition:
* Postcondition:
*		if self assignment, does nothing
*		data in rhs is copied into current object
*		return *this for function chaining
*****************************************/
template<typename V, typename E>
Edge<V, E>& Edge<V, E>::operator =(const Edge<V, E>& rhs)
{
	if (this != &rhs)
	{
		m_data = rhs.m_data;
		m_dest = rhs.m_dest;
		m_weight = rhs.m_weight;
	}
	return *this;
}


/*****************************************
* Purpose:	current object gets data moved from rhs
* Precondition:
* Postcondition:
*		if self assignment, does nothing
*		data in rhs is moved into current object
*		rhs gets reset to default state
*		return *this for function chaining
*****************************************/
template<typename V, typename E>
Edge<V, E>& Edge<V, E>::operator =(Edge<V, E>&& rhs) noexcept
{
	if (this != &rhs)
	{
		m_data = std::move(rhs.m_data);
		rhs.m_data = E();
		m_dest = rhs.m_dest;
		rhs.m_dest = nullptr;
		m_weight = rhs.m_weight;
		rhs.m_weight = 0;
	}
	return *this;
}


/*****************************************
* Purpose:	Instantiate an Edge<V,E> object with input parameters
* Precondition:
* Postcondition:
*		if weight is negative, throws exception
*		m_data(data)
*		m_dest(dest)
*		m_weight(weight)
*****************************************/
template<typename V, typename E>
Edge<V, E>::Edge(E data, Vertex<V, E>* dest, int weight) : m_data(data), m_dest(dest), m_weight(weight)
{
	if (m_weight < 0)
	{
		throw Exception("cannot have negative edge weight");
	}
}


/*****************************************
* Purpose:	compares 2 Edge objects to see if they are the same
* Precondition:
* Postcondition:
*		returns true if they are the same, false if they aren't
*****************************************/
template<typename V, typename E>
bool Edge<V, E>::operator==(const Edge<V, E>& rhs) const
{
	bool same = false;
	if (rhs.m_data == m_data && rhs.m_weight == m_weight && rhs.m_dest == m_dest)
	{
		same = true;
	}
	return same;
}


/*****************************************
* Purpose:	compares 2 Edge objects to see if they aren't the same
* Precondition:
* Postcondition:
*		returns false if they are the same, true if they aren't
*****************************************/
template<typename V, typename E>
bool Edge<V, E>::operator!=(const Edge<V, E>& rhs) const
{
	return !(this == rhs);
}