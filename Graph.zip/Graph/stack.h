#pragma once
/*****************************************
* Author: Kobi Conn
* Filename: stack.h
* Date Created: 4/10/22
* Modifications: 4/12/22 added documentation for functions
*****************************************/
#include "list.h"

/*****************************************
* Class: Stack
*
* Purpose: This class holds an array of data in a first in last out (FILO) architecture. it is templated so that it can hold any piece of data
*
* Manager functions:
*		Stack ( )
*			Default values for Stack are: m_stack(), num_elements(0)
*		~Stack ( )
*		Stack (const Stack<T> & copy)
*		operator = (const Stack<T> & rhs)
*		Stack (Stack<T> && copy)
*			constructs an Stack, moving the data from copy. it then resets copy to its default state
*		operator = (Stack<T> && rhs)
*			if it is not self reference, it deallocates memory that m_array is pointing at and takes the data from rhs. resets rhs to default state
*
* Methods:
*		Push(T data)
*			Put input data into the top of the stack as a new node
*		Pop()
*			Take the data from the last element in stack and return it by value. delete last node in stack
*		Peek()
*			if list is empty, throws error. else, returns data in top element of the array
*		getNumElements()
*			Returns num of elements currently in stack
*		isEmpty()
*			Returns true if m_stack has no data entered, else returns true
*****************************************/
template<typename T>
class Stack
{
public:
	Stack();
	~Stack();
	Stack(const Stack<T>& copy);
	Stack(Stack<T>&& copy) noexcept;
	Stack<T>& operator =(const Stack<T>& rhs);
	Stack<T>& operator =(Stack<T>&& rhs) noexcept;

	void Push(T data);
	T Pop();
	T Peek() const;
	int getNumElements() const;
	bool isEmpty() const;



private:
	List<T> m_stack;
	int num_elements;
};


/*****************************************
* Purpose:	Instantiate a default Stack<T> object
* Precondition:
* Postcondition:
*****************************************/
template<typename T>
Stack<T>::Stack() : m_stack(), num_elements(0)
{

}


/*****************************************
* Purpose:	Reset current object to default state
* Precondition:
* Postcondition:
*			m_stack gets reset to nullptr
*			size = 0
*			top = -1
*****************************************/
template<typename T>
Stack<T>::~Stack()
{
	m_stack.Purge();
	num_elements = 0;
}


/*****************************************
* Purpose: Copy data from copy into current Stack<T> object
*
* Precondition:
*
* Postcondition:
*		both the current object and copy hold copies of the same data
*****************************************/
template<typename T>
Stack<T>::Stack(const Stack<T>& copy) : m_stack(copy.m_stack), num_elements(copy.num_elements)
{

}


/*****************************************
* Purpose: Move the data from copy into the current Stack<T> through instantiation
*
* Precondition:
*
* Postcondition:
*		all data in copy is moved into current object
*		copy gets reset to default state
*****************************************/
template<typename T>
Stack<T>::Stack(Stack<T>&& copy) noexcept : m_stack(std::move(copy.m_stack)), num_elements(std::move(copy.num_elements))
{
	copy.m_stack.Purge();
	copy.num_elements = 0;
}


/*****************************************
* Purpose: copy all data in one Stack object into the current one through assignment
*
* Precondition:
* Postcondition:
*		if self assignment, does nothing
*		parameters copied from rhs
*		return *this for function chaining
*****************************************/
template<typename T>
Stack<T>& Stack<T>::operator =(const Stack<T>& rhs)
{
	if (this != &rhs)
	{
		m_stack = rhs.m_stack;
		num_elements = rhs.num_elements;
	}
	return *this;
}


/*****************************************
* Purpose: move the contents of one array into another
*
* Precondition:
* Postcondition:
*		if self assingment, does nothing
*		parameters copied from rhs
*		resets rhs' data to default state
*		Returns *this for function chaining
*****************************************/
template<typename T>
Stack<T>& Stack<T>::operator =(Stack<T>&& rhs) noexcept
{
	if (this != &rhs)
	{
		m_stack = rhs.m_stack;
		num_elements = rhs.num_elements;
		rhs.num_elements = 0;
		rhs.m_stack.Purge();
	}
	return *this;
}


/*****************************************
* Purpose:	Adds data to Stack<T> array at top of stack
* Precondition:
* Postcondition:
*		else move num_elements up and set data to top of stack
*****************************************/
template<typename T>
void Stack<T>::Push(T data)
{
	m_stack.Append(data);
	num_elements++;
}


/*****************************************
* Purpose:	remove data from top of stack and return it
* Precondition:
* Postcondition:
*		if there is nothing to pop, throws underflow exception
*		else decrement num_elements and return old top's data
*****************************************/
template<typename T>
T Stack<T>::Pop()
{
	if (m_stack.isEmpty())
	{
		throw Exception("Cannot Pop an empty stack");
	}
	num_elements--;
	return m_stack.Pop();
}


/*****************************************
* Purpose:	shows data at the top of the stack, but doesn't remove it
* Precondition:
* Postcondition:
*		if stack is empty, throw exception
*		return data at current top of stack
*****************************************/
template<typename T>
T Stack<T>::Peek() const
{
	if (m_stack.isEmpty())
	{
		throw Exception("Cannot peek at empty stack");
	}
	return m_stack.Last();
}


/*****************************************
* Purpose:	show amount of elements currently filled with data in stack
* Precondition:
* Postcondition:
*		returns num_elements
*****************************************/
template<typename T>
int Stack<T>::getNumElements() const
{
	return num_elements;
}


/*****************************************
* Purpose:	tells whether the stack is currently empty or not
* Precondition:
* Postcondition:
*		returns true if the stack is empty, and false if there is data in stack
*****************************************/
template<typename T>
bool Stack<T>::isEmpty() const
{
	bool empty = false;
	if (num_elements == 0)
	{
		empty = true;
	}
	return empty;
}