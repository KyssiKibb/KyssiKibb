#pragma once
/*****************************************
* Author: Kobi Conn
* Filename: vertex.h
* Date Created: 5/10/22
* Modifications: 5/15/22 added documentation for functions
*****************************************/

#include <iostream>
#include <list>
using std::list;
template<typename V, typename E>
class Edge;

/*****************************************
* Class: Vertex
*
* Purpose:  This class holds the vertex data, including : whether it has been processed(m_processed)[used for traversals to make sure you don't touch each vertex more than once],
*			all of the edges going from current vertex to different vertices(m_edges), and what other data type is provided(m_data)
*
* Manager functions:
*		Vertex ( )
*			Default values for Vertex are: m_data(), m_weight(0), m_dest(nullptr)
*		~Vertex ( )
*		Vertex (const Vertex<V,E> & copy)
*		operator = (const Vertex<V,E> & rhs)
*		Vertex (Vertex<V,E> && copy)
*			constructs an Vertex, moving the data from copy. it then resets copy to its default state
*		operator = (Vertex<V,E> && rhs)
*			if it is not self reference, it moves data in rhs to current object, and resets rhs to default state
*		Vertex(V data)
*			1 arg ctor for Vertex. m_data is set to input parameter
* Methods:
*		void AddEdge (E data, Vertex<V, E>* dest, int weight)
*			adds edge data into m_edges
*		Bool operator ==(const Vertex<V,E>& rhs) const
*			returns true if rhs and current object have same data values, else returns false
*		Bool operator !=(const Vertex<V,E>& rhs) const
*			returns false if rhs and current object have same data values, else returns true
*****************************************/
template <typename V, typename E>
class Vertex
{
	template<typename V, typename E>
	friend class Graph;
public:
	Vertex();
	~Vertex();
	Vertex(const Vertex<V,E>& copy);
	Vertex(Vertex<V,E>&& copy) noexcept;
	Vertex<V,E>& operator =(const Vertex<V,E>& rhs);
	Vertex<V,E>& operator =(Vertex<V,E>&& rhs) noexcept;
	Vertex(V data);

	void AddEdge(E data, Vertex<V, E>* dest, int weight);

	bool operator ==(const Vertex<V, E>& rhs)const;
	bool operator !=(const Vertex<V, E>& rhs)const;
private:
	V m_data;
	list<Edge<V, E>> m_edges;
	bool m_processed;
};


/*****************************************
* Purpose:	instantiates Default Vertex
* Precondition:
* Postcondition:
*		m_data()
*		m_processed(false)
*		m_edges()
*****************************************/
template <typename V, typename E>
Vertex<V, E>::Vertex() : m_data(), m_edges(), m_processed(false)
{

}


/*****************************************
* Purpose:	Vertex is reset to default values
* Precondition:
* Postcondition:
*		current object is in default state
*****************************************/
template <typename V, typename E>
Vertex<V, E>::~Vertex()
{
	m_data = V();
	m_edges.clear();
	m_processed = false;
}


/*****************************************
* Purpose:	instantiates Vertex by copying data in copy
* Precondition:
* Postcondition:
*		both copy and current object have copies of the same data
*****************************************/
template <typename V, typename E>
Vertex<V, E>::Vertex(const Vertex<V, E>& copy) : m_data(copy.m_data), m_edges(copy.m_edges), m_processed(copy.m_processed)
{

}


/*****************************************
* Purpose:	instantiates Vertex by moving data from copy
* Precondition:
* Postcondition:
*		data in copy is moved into current object
*		copy gets reset to default state
*****************************************/
template <typename V, typename E>
Vertex<V, E>::Vertex(Vertex<V, E>&& copy) noexcept: m_data(std::move(copy.m_data)), m_edges(std::move(copy.m_edges)), m_processed(std::move(copy.m_processed))
{
	copy.m_data = V();
	copy.m_processed = false;
	copy.m_edges.clear();
}


/*****************************************
* Purpose:	instantiates Vertex by moving data from copy
* Precondition:
* Postcondition:
*		if self assignment, does nothing
*		data in rhs is copied into current object
*		returns *this for function chaining
*****************************************/
template <typename V, typename E>
Vertex<V, E>& Vertex<V, E>::operator=(const Vertex<V, E>& rhs)
{
	if (this != &rhs)
	{
		m_data = rhs.m_data;
		m_edges = rhs.m_edges;
		m_processed = rhs.m_processed;
	}
	return *this;
}


/*****************************************
* Purpose:	instantiates Vertex by moving data from copy
* Precondition:
* Postcondition:
*		if self assignment, does nothing
*		data in rhs is moved into current object
*		rhs is reset to default state
*		returns *this for function chaining
*****************************************/
template <typename V, typename E>
Vertex<V, E>& Vertex<V, E>::operator=(Vertex<V, E>&& rhs) noexcept
{
	if (this != &rhs)
	{
		m_data = std::move(rhs.m_data);
		m_edges = std::move(rhs.m_edges);
		m_processed = std::move(rhs.m_processed);
		rhs.m_processed = false;
	}
	return *this;
}


/*****************************************
* Purpose:	instantiates Vertex with input data
* Precondition:
* Postcondition:
*		m_data(data)
*		m_processed(false)
*		m_edges()
*****************************************/
template <typename V, typename E>
Vertex<V, E>::Vertex(V data) : m_data(data), m_processed(false), m_edges()
{

}


/*****************************************
* Purpose:	adds Edge containing input data to list of edges(m_edges)
* Precondition:
*		consumer calls InsertEdge function in graph
* Postcondition:
*		m_edges has a new edge with input data parameters
*****************************************/
template <typename V, typename E>
void Vertex<V, E>::AddEdge(E data, Vertex<V, E>* dest, int weight)
{
	Edge<V, E> edge(data, dest, weight);
	m_edges.push_back(edge);
}


/*****************************************
* Purpose:	compares 2 Vertex objects to see if they are the same
* Precondition:
* Postcondition:
*		returns true if they are the same, false if they aren't
*****************************************/
template <typename V, typename E>
bool Vertex<V, E>::operator ==(const Vertex<V, E>& rhs)const
{
	bool same = false;
	if (rhs.m_data == m_data && rhs.m_processed == m_processed && m_edges == rhs.m_edges)
	{
		same = true;
	}
	return same;
}


/*****************************************
* Purpose:	compares 2 Vertex objects to see if they aren't the same
* Precondition:
* Postcondition:
*		returns false if they are the same, true if they aren't
*****************************************/
template <typename V, typename E>
bool Vertex<V, E>::operator !=(const Vertex<V, E>& rhs)const
{
	return !(this == rhs);
}