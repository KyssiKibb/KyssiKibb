/*****************************************
* Author: Kobi Conn
* Filename: main.cpp
* Date Created: 5/12/22
* Modifications:
*****************************************/
/*****************************************
*
* Lab/Assignment: List Based Graph
*
* Overview:
*	This program will test all of the functions in the templated
*	Graph class
*
* Input:
*	There is no inputs
*
* Output:
*	Displays whether the test for any of the functions passes or fails in console.
*	Output will be in the form : X function test passed/failed
*****************************************/
#define _CRTDBG_MAP_ALLOC
typedef bool(*FunctionPointer)();  // Define a funtion pointer type
#include <string>
using std::string;
#include <iostream>
using std::cout;
using std::cin;
using std::endl;
#include<utility>
using std::pair;
using std::get;
#include <crtdbg.h>
#include "graph.h"
// Strings to test
const char* NAMES[] = { "Alpha", "Beta", "Gamma", "Delta", "Epsilon", "Zeta",
"Eta", "Theta", "Iota", "Kappa", "Lambda", "Mu", "Nu",
"Xi", "Omicron" };
const int NUM_NAMES = 15;
// Test function declaration
bool test_default_ctor();
bool test_copy_ctor();
bool test_move_ctor();
bool test_copy_assignment();
bool test_move_assignment();
bool test_isempty();
bool test_insert_vertex();
bool test_insert_edge();
bool test_insert_edge2();
bool test_insert_edge3();
bool test_insert_edge4();
bool test_insert_edge5();
bool test_delete_vertex();
bool test_delete_edge();
bool test_delete_edge2();
bool test_purge();
bool test_getedge();
bool test_getvertices();
bool test_depthfirst();
bool test_breadthfirst();
bool test_getnumvertices();
bool test_getnumedges();
bool test_visit();


FunctionPointer test_functions[] =
{
	test_default_ctor
	,test_copy_ctor
	,test_move_ctor
	,test_copy_assignment
	,test_move_assignment
	,test_isempty
	,test_insert_vertex
	,test_insert_edge
	,test_insert_edge2
	,test_insert_edge3
	,test_insert_edge4
	,test_insert_edge5
	,test_delete_vertex
	,test_delete_edge
	,test_delete_edge2
	,test_purge
	,test_getedge
	,test_getvertices
	,test_depthfirst
	,test_breadthfirst
	,test_getnumvertices
	,test_getnumedges
	,test_visit
};

void visit(string data);
Stack<string> traversalcheck;

int main()
{
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
	// Run the test functions
	for (FunctionPointer func : test_functions)
	{
		if (func())
		{
			cout << "passed\n";
		}
		else
		{
			cout << "***** failed *****\n";
		}
	}
	cout << "\nPress Any Key to Exit";

	cin.get();
	return 0;
}
bool test_default_ctor()
{
	bool passed = true;
	Graph<string, int> test;
	if (!test.isEmpty())
	{
		passed = false;
	}
	cout << "default ctor test ";
	return passed;
}

bool test_copy_ctor()
{
	bool passed = true;
	Graph<string, int> test;
	test.InsertVertex(NAMES[0]);
	Graph<string, int> test2(test);
	if (test2.isEmpty())
	{
		passed = false;
	}
	if (test.isEmpty())
	{
		passed = false;
	}
	cout << "copy ctor test ";
	return passed;
}
bool test_move_ctor()
{
	bool passed = true;
	Graph<string, int> test;
	test.InsertVertex(NAMES[0]);
	Graph<string, int> test2(std::move(test));
	if (!test.isEmpty())
	{
		passed = false;
	}
	if (test2.isEmpty())
	{
		passed = false;
	}
	cout << "move ctor test ";
	return passed;
}
bool test_copy_assignment()
{
	bool passed = true;
	Graph<string, int> test;
	test.InsertVertex(NAMES[0]);
	Graph<string, int> test2;
	test2 = test;
	test2 = test2; // testing self assignment deleting info
	if (test.isEmpty())
	{
		passed = false;
	}
	if (test2.isEmpty())
	{
		passed = false;
	}
	cout << "copy assignment test ";
	return passed;
}
bool test_move_assignment()
{
	bool passed = true;
	Graph<string, int> test;
	test.InsertVertex(NAMES[0]);
	Graph<string, int> test2;
	test2 = std::move(test);
	test2 = std::move(test2); //testing self assignment
	if (!test.isEmpty())
	{
		passed = false;
	}
	if (test2.isEmpty())
	{
		passed = false;
	}
	cout << "move assignment test ";
	return passed;
}

bool test_isempty()
{
	bool passed = true;
	Graph<string, int> test;
	if (!test.isEmpty())
	{
		passed = false;
	}
	test.InsertVertex(NAMES[0]);
	if (test.isEmpty())
	{
		passed = false;
	}
	cout << "isEmpty test ";
	return passed;
}
bool test_insert_vertex()
{
	bool passed = false;
	Graph<string, int> test;
	test.InsertVertex(NAMES[0]);
	try
	{
		test.InsertVertex(NAMES[0]);
	}
	catch(Exception a)
	{
		passed = true;
	}
	for (int i = 1; i < NUM_NAMES; ++i)
	{
		test.InsertVertex(NAMES[i]);
	}
	if (test.isEmpty())
	{
		passed = false;
	}
	cout << "InsertVertex test ";
	return passed;
}
bool test_insert_edge()
{
	bool passed = false;
	Graph<string,int> test;
	for (int i = 0; i < NUM_NAMES; ++i)
	{
		test.InsertVertex(NAMES[i]);
	}
	try
	{
		test.InsertEdge(NAMES[0], "abcdefg",55,-10);
	}
	catch (Exception a)
	{
		passed = true;
	}
	cout << "InsertEdge test 1 ";
	return passed;
}
bool test_insert_edge2()
{
	bool passed = false;
	Graph<string, int> test;
	for (int i = 0; i < NUM_NAMES; ++i)
	{
		test.InsertVertex(NAMES[i]);
	}
	try
	{
		test.InsertEdge(NAMES[0], "abcdefg", 55, 10);
	}
	catch (Exception a)
	{
		passed = true;
	}
	cout << "InsertEdge test 2 ";
	return passed;
}
bool test_insert_edge3()
{
	bool passed = false;
	Graph<string, int> test;
	for (int i = 0; i < NUM_NAMES; ++i)
	{
		test.InsertVertex(NAMES[i]);
	}
	try
	{
		test.InsertEdge("ashjfla", NAMES[1], 55, 10);
	}
	catch (Exception a)
	{
		passed = true;
	}
	cout << "InsertEdge test 3 ";
	return passed;
}
bool test_insert_edge4()
{
	bool passed = false;
	Graph<string, int> test;
	for (int i = 0; i < NUM_NAMES; ++i)
	{
		test.InsertVertex(NAMES[i]);
	}
	test.InsertEdge(NAMES[0], NAMES[1], 51, 10);
	try
	{
		test.InsertEdge(NAMES[0], NAMES[1], 51, 10);
	}
	catch (Exception a)
	{
		passed = true;
	}

	cout << "InsertEdge test 4 ";
	return passed;
}
bool test_insert_edge5()
{
	bool passed = false;
	Graph<string, int> test;
	for (int i = 0; i < NUM_NAMES; ++i)
	{
		test.InsertVertex(NAMES[i]);
	}
	try
	{
		test.InsertEdge(NAMES[1], NAMES[1], 55, 10);
	}
	catch (Exception a)
	{
		passed = true;
	}
	for (int i = 1; i < NUM_NAMES; ++i)
	{
		test.InsertEdge(NAMES[0], NAMES[i], i + 50, i + 5);
	}
	if (test.getVertices(NAMES[0]).Pop() != NAMES[NUM_NAMES - 1])
	{
		passed = false;
	}
	cout << "InsertEdge test 5 ";
	return passed;
}
bool test_delete_vertex()
{
	bool passed = false;
	Graph<string,int> test;
	for (int i = 0; i < NUM_NAMES; ++i)
	{
		test.InsertVertex(NAMES[i]);
	}
	try
	{
		test.DeleteVertex("asdfgsdgf");
	}
	catch (Exception a)
	{
		passed = true;
	}
	test.DeleteVertex(NAMES[1]);
	test.DeleteVertex(NAMES[NUM_NAMES - 1]);
	test.DeleteVertex(NAMES[0]);
	if (test.getNumVertices() != 12)
	{
		passed = false;
	}
	cout << "DeleteVertex test ";
	return passed;
}
bool test_delete_edge()
{
	bool passed = false;
	Graph<string,int> test;
	for (int i = 0; i < NUM_NAMES; ++i)
	{
		test.InsertVertex(NAMES[i]);
	}
	try
	{
		test.DeleteEdge("asdfgsdgf", NAMES[0], 20);
	}
	catch (Exception a)
	{
		passed = true;
	}
	cout << "DeleteEdge test 1 ";
	return passed;
}
bool test_delete_edge2()
{
	bool passed = false;
	Graph<string, int> test;
	for (int i = 0; i < NUM_NAMES; ++i)
	{
		test.InsertVertex(NAMES[i]);
	}
	try
	{
		test.DeleteEdge(NAMES[0], "asdfgsdgf" ,20);
	}
	catch (Exception a)
	{
		passed = true;
	}
	for (int i = 1; i < NUM_NAMES; ++i)
	{
		test.InsertEdge(NAMES[0], NAMES[i], i + 50, i + 5);
	}
	test.DeleteEdge(NAMES[0], NAMES[2], 52); //delete edge in middle of m_edges
	test.DeleteEdge(NAMES[0], NAMES[NUM_NAMES-1], 50+(NUM_NAMES-1)); //delete edge at end of m_edges
	test.DeleteEdge(NAMES[0], NAMES[1], 51); // delete edge at beginning of m_edges
	test.DeleteEdge(NAMES[0], NAMES[1], 51); // delete edge that doesn't exist
	if (test.getNumEdges(NAMES[0]) != 11)
	{
		passed = false;
	}
	cout << "DeleteEdge test 2 ";
	return passed;
}
bool test_purge()
{
	bool passed = true;
	Graph<string,int> test;
	for (int i = 0; i < NUM_NAMES; ++i)
	{
		test.InsertVertex(NAMES[i]);
	}
	for (int i = 1; i < NUM_NAMES; ++i)
	{
		test.InsertEdge(NAMES[0], NAMES[i], i + 50, i + 5);
	}
	test.Purge();
	if (!test.isEmpty())
	{
		passed = false;
	}
	cout << "Purge test ";
	return passed;
}
bool test_getedge()
{
	bool passed = true;
	Graph<string,int> test;
	for (int i = 0; i < NUM_NAMES; ++i)
	{
		test.InsertVertex(NAMES[i]);
	}
	for (int i = 1; i < NUM_NAMES; ++i)
	{
		test.InsertEdge(NAMES[0], NAMES[i], i + 50, i + 5);
	}
	if (get<0>(test.getEdge(NAMES[0], NAMES[1])) != 51)
	{
		passed = false;
	}
	cout << "GetEdge test ";
	return passed;
}
bool test_getvertices()
{
	bool passed = false;
	Graph<string,int> test;
	for (int i = 0; i < NUM_NAMES; ++i)
	{
		test.InsertVertex(NAMES[i]);
	}
	for (int i = 1; i < NUM_NAMES; ++i)
	{
		test.InsertEdge(NAMES[0], NAMES[i], i + 50, i + 5);
	}
	try
	{
		test.getVertices("Adafsgsf");
	}
	catch(Exception a)
	{
		passed = true;
	}
	if (test.getVertices(NAMES[0]).Pop() != NAMES[NUM_NAMES - 1])
	{
		passed = false;
	}
	cout << "GetVertices test ";
	return passed;
}
bool test_depthfirst()
{
	bool passed = true;
	Graph<string,int> test;
	for (int i = 0; i < NUM_NAMES; ++i)
	{
		test.InsertVertex(NAMES[i]);
	}
	for (int i = 0; i < (NUM_NAMES-1); ++i)
	{
		test.InsertEdge(NAMES[i], NAMES[i+1], i + 50, i + 5);
	}
	test.InsertEdge(NAMES[0], NAMES[2], 51, 6);
	test.InsertEdge(NAMES[0], NAMES[3], 52, 7);
	test.InsertEdge(NAMES[1], NAMES[0], 50, 5);
	test.InsertEdge(NAMES[1], NAMES[2], 52, 7);
	test.InsertEdge(NAMES[1], NAMES[3], 53, 8);
	test.InsertEdge(NAMES[2], NAMES[0], 50, 5);
	test.InsertEdge(NAMES[2], NAMES[1], 51, 6);
	test.InsertEdge(NAMES[2], NAMES[3], 53, 8);
	test.InsertEdge(NAMES[3], NAMES[0], 50, 5);
	test.InsertEdge(NAMES[3], NAMES[1], 51, 6);
	test.InsertEdge(NAMES[3], NAMES[2], 52, 7);
	while (!traversalcheck.isEmpty())
	{
		traversalcheck.Pop();
	}
	test.DepthFirst(visit);
	if (traversalcheck.Pop() != NAMES[1])
	{
		passed = false;
	}
	if (traversalcheck.Pop() != NAMES[2])
	{
		passed = false;
	}
	if (traversalcheck.Pop() != NAMES[14])
	{
		passed = false;
	}
	cout << "DepthFirst test ";
	return passed;
}
bool test_breadthfirst()
{
	bool passed = true;
	Graph<string,int> test;
	for (int i = 0; i < NUM_NAMES; ++i)
	{
		test.InsertVertex(NAMES[i]);
	}
	for (int i = 0; i < (NUM_NAMES - 1); ++i)
	{
		test.InsertEdge(NAMES[i], NAMES[i + 1], i + 50, i + 5);
	}
	test.InsertEdge(NAMES[0], NAMES[2], 51, 6);
	test.InsertEdge(NAMES[0], NAMES[3], 52, 7);
	test.InsertEdge(NAMES[1], NAMES[0], 50, 5);
	test.InsertEdge(NAMES[1], NAMES[2], 52, 7);
	test.InsertEdge(NAMES[1], NAMES[3], 53, 8);
	test.InsertEdge(NAMES[2], NAMES[0], 50, 5);
	test.InsertEdge(NAMES[2], NAMES[1], 51, 6);
	test.InsertEdge(NAMES[2], NAMES[3], 53, 8);
	test.InsertEdge(NAMES[3], NAMES[0], 50, 5);
	test.InsertEdge(NAMES[3], NAMES[1], 51, 6);
	test.InsertEdge(NAMES[3], NAMES[2], 52, 7);
	while (!traversalcheck.isEmpty())
	{
		traversalcheck.Pop();
	}
	test.BreadthFirst(visit);
	if (traversalcheck.Pop() != NAMES[14])
	{
		passed = false;
	}
	if (traversalcheck.Pop() != NAMES[13])
	{
		passed = false;
	}
	if (traversalcheck.Pop() != NAMES[12])
	{
		passed = false;
	}
	cout << "BreadthFirst test ";
	return passed;
}
bool test_getnumvertices()
{
	bool passed = true;
	Graph<string, int> test;
	for (int i = 0; i < NUM_NAMES; ++i)
	{
		test.InsertVertex(NAMES[i]);
	}
	for (int i = 1; i < NUM_NAMES; ++i)
	{
		test.InsertEdge(NAMES[0], NAMES[i], i + 50, i + 5);
	}
	if (test.getNumVertices() != 15)
	{
		passed = false;
	}
	cout << "getNumVertices test ";
	return passed;
}
bool test_getnumedges()
{
	bool passed = false;
	Graph<string, int> test;
	for (int i = 0; i < NUM_NAMES; ++i)
	{
		test.InsertVertex(NAMES[i]);
	}
	for (int i = 1; i < NUM_NAMES; ++i)
	{
		test.InsertEdge(NAMES[0], NAMES[i], i + 50, i + 5);
	}
	try
	{
		test.getNumEdges("Adafsgsf");
	}
	catch (Exception a)
	{
		passed = true;
	}
	if (test.getNumEdges(NAMES[0]) != 14)
	{
		passed = false;
	}
	cout << "getNumEdges test ";
	return passed;
}
bool test_visit()
{
	bool passed = false;
	Graph<string, int> test;
	for (int i = 0; i < NUM_NAMES; ++i)
	{
		test.InsertVertex(NAMES[i]);
	}
	try
	{
		test.visit("Adafsgsf",visit);
	}
	catch (Exception a)
	{
		passed = true;
	}
	while (!traversalcheck.isEmpty())
	{
		traversalcheck.Pop();
	}
	test.visit(NAMES[0],visit);
	if (traversalcheck.Pop() != NAMES[0])
	{
		passed = false;
	}
	cout << "visit test ";
	return passed;
}

void visit(string data)
{
	traversalcheck.Push(data);
}