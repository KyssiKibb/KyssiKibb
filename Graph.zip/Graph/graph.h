#pragma once
/*****************************************
* Author: Kobi Conn
* Filename: graph.h
* Date Created: 5/10/22
* Modifications: 5/15/22 added documentation for functions
*****************************************/

#include <iostream>
#include<utility>
#include <list>
using std::list;
using std::pair;
#include "vertex.h"
#include "edge.h"
#include "stack.h"
#include "queue.h"

/*****************************************
* Class: Graph
*
* Purpose:  This class holds a list of vertices, where each vertex holds edges that go between the different vertices.
*			mirrors the structure of things like plane routes, cities with roads between them, etc.
*
* Manager functions:
*		Graph ( )
*			Default values for Graph are: m_vertices()
*		~Graph ( )
*		Graph (const Graph<V,E> & copy)
*		operator = (const Graph<V,E> & rhs)
*		Graph (Graph<V,E> && copy)
*			constructs a Graph, moving the data from copy. it then resets copy to its default state
*		operator = (Graph<V,E> && rhs)
*			if it is not self reference, it moves data in rhs to current object, and resets rhs to default state
* Methods:
*		void InsertVertex(V vertex)
*			Insert input vertex into m_vertices if it is not a copy of a vertex already in m_vertices
*		void InsertEdge(V source, V dest, E data, int weight)
*			finds source vertex and adds edge between it and dest vertex using input data and weight as data members of new edge
*		void DeleteEdge(V source, V dest, E data)
*			Deletes Edge between source and destination vertex matching E data
*		void DeleteVertex(V vertex)
*			Deletes all Edges pointing to vertex, and then deletes vertex from m_vertices
*		bool isEmpty() const
*			returns true if m_vertices is empty, and false if not
*		void Purge()
*			Resets Graph to default state
*		pair<E,int> getEdge(V source, V dest)
*			returns pair containing Edge data and weight between source and destination
*		Stack<V> getVertices(V source)
*			returns stack containing all vertices that are directly connected to source vertex
*		void DepthFirst(void (*visit)(V data))
*			visits all nodes in DepthFirst fashion, calling visit on them
*		void BreadthFirst(void (*visit)(V data))
*			visits all nodes in BreadthFirst fashion, calling visit on them
*		int getNumVertices() const
*			returns size of m_vertices
*		void visit(V vertex, void(*visit)(V data))
*			goes to vertex specified and calls user input function on it
*		int getNumEdges(V vertex)
*			returns total amount of edges that given vertex contains
*****************************************/
template<typename V, typename E>
class Graph
{
public:
	Graph();
	~Graph();
	Graph(const Graph<V,E>& copy);
	Graph(Graph<V,E>&& copy)noexcept;
	Graph<V,E>& operator =(const Graph<V,E>& rhs);
	Graph<V,E>& operator =(Graph<V,E>&& rhs)noexcept;

	void InsertVertex(V vertex);
	void InsertEdge(V source, V dest, E data, int weight);
	void DeleteEdge(V source, V dest, E data);
	void DeleteVertex(V vertex);
	bool isEmpty() const;
	void Purge();
	pair<E,int> getEdge(V source, V dest) const;
	Stack<V> getVertices(V source);
	void DepthFirst(void (*visit)(V data));
	void BreadthFirst(void (*visit)(V data));
	int getNumVertices() const;
	void visit(V vertex, void(*visit)(V data));
	int getNumEdges(V vertex) const;
private:
	list<Vertex<V, E>> m_vertices;
};


/*****************************************
* Purpose:	instantiates Default Graph
* Precondition:
* Postcondition:
*		m_vertices()
*****************************************/
template<typename V, typename E>
Graph<V, E>::Graph() : m_vertices()
{

}


/*****************************************
* Purpose:	Resets graph to default state
* Precondition:
* Postcondition:
*		m_vertices is cleared
*****************************************/
template<typename V, typename E>
Graph<V, E>::~Graph()
{
	m_vertices.clear();
}


/*****************************************
* Purpose:	instantiates Graph with data copied from input
* Precondition:
* Postcondition:
*		current objects get copy of data in input
*****************************************/
template<typename V, typename E>
Graph<V, E>::Graph(const Graph<V, E>& copy) : m_vertices(copy.m_vertices)
{

}


/*****************************************
* Purpose:	instantiates Graph with data copied from input
* Precondition:
* Postcondition:
*		data in copy gets moved to current object
*		copy gets reset to default state
*****************************************/
template<typename V, typename E>
Graph<V, E>::Graph(Graph<V, E>&& copy)noexcept : m_vertices(std::move(copy.m_vertices))
{
	copy.m_vertices.clear();
}


/*****************************************
* Purpose:	current Graph gets copy of data in rhs
* Precondition:
* Postcondition:
*		if self assignment, does nothing
*		copies data from rhs into current object
*		returns *this for function chaining
*****************************************/
template<typename V, typename E>
Graph<V, E>& Graph<V, E>::operator =(const Graph<V, E>& rhs)
{
	if (this != &rhs)
	{
		m_vertices = rhs.m_vertices;
	}
	return *this;
}


/*****************************************
* Purpose:	current Graph gets copy of data in rhs
* Precondition:
* Postcondition:
*		if self assignment, does nothing
*		moves data from rhs into current object
*		resets rhs to default state
*		returns *this for function chaining
*****************************************/
template<typename V, typename E>
Graph<V, E>& Graph<V, E>::operator =(Graph<V, E>&& rhs)noexcept
{
	if (this != &rhs)
	{
		m_vertices = std::move(rhs.m_vertices);
		rhs.m_vertices.clear();
	}
	return *this;
}


/*****************************************
* Purpose:	inserts vertex into graph if it is not a duplicate
* Precondition:
* Postcondition:
*		if duplicate, throws exception
*		adds vertex to back of m_vertices
*****************************************/
template<typename V, typename E>
void Graph<V, E>::InsertVertex(V vertex)
{
	bool duplicate = false;
	for (auto&& i = m_vertices.begin(); i != m_vertices.end() && duplicate != true; ++i)
	{
		if ((*i).m_data == vertex)
		{
			duplicate = true;
		}
	}
	if (duplicate == true)
	{
		throw Exception("Vertex with same signature already exists");
	}
	else
	{
		Vertex<V, E> newvertex(vertex);
		m_vertices.push_back(newvertex);
	}
}


/*****************************************
* Purpose:	inserts vertex into graph if it is not a duplicate
* Precondition:
* Postcondition:
*		if weight is negative, throws exception
*		if source is not found in m_vertices, throws exception
*		if dest is not found in m_vertices, throws exception
*		if data is a copy of an edge already in that vertices' edges, throws exception
*		if both vertices are the same, throws exception
*		adds edge in source's m_edges with input data, weight, and dest
*****************************************/
template<typename V, typename E>
void Graph<V, E>::InsertEdge(V source, V dest, E data, int weight)
{
	if (weight < 0)
	{
		throw Exception("Weight cannot be negative");
	}
	if (source == dest)
	{
		throw Exception("Cannot make edge between same vertex");
	}
	bool found = false;
	for (auto&& i = m_vertices.begin(); i != m_vertices.end() && found != true; ++i)
	{
		if ((*i).m_data == source)
		{
			for (auto&& j = m_vertices.begin(); j != m_vertices.end() && found != true; ++j)
			{
				if ((*j).m_data == dest)
				{
					for (auto&& x : (*i).m_edges)
					{
						if (x.m_data == data)
						{
							throw Exception("Cannot add same edge between vertices");
						}
					}
					(*i).AddEdge(data, &(*j), weight);
					found = true;
				}
			}
			if (found == false)
			{
				throw Exception("Dest not found");
			}
			found = true;
		}

	}
	if (found == false)
	{
		throw Exception("Source not found");
	}

}


/*****************************************
* Purpose:	inserts vertex into graph if it is not a duplicate
* Precondition:
* Postcondition:
*		if source is not found in m_vertices, throws exception
*		if dest is not found in m_vertices, throws exception
*		deletes edges in source's m_edges with same data, weight, and dest
*****************************************/
template<typename V, typename E>
void Graph<V, E>::DeleteEdge(V source, V dest, E data)
{
	bool found = false;
	for (auto&& i = m_vertices.begin(); i != m_vertices.end() && found != true; ++i)
	{
		if ((*i).m_data == dest)
		{
			found = true;
		}
	}
	if (found == true)
	{
		found = false;
		for (auto&& i = m_vertices.begin(); i != m_vertices.end() && found != true; ++i)
		{
			if ((*i).m_data == source) // found the source
			{
				for (auto&& j = (*i).m_edges.begin(); j != (*i).m_edges.end(); ++j) // list of edges
				{
					if ((*j).m_data == data && (*j).m_dest->m_data == dest)
					{
						if ((*j) == (*i).m_edges.back())
						{
							auto temp = --j;
							j++;
							(*i).m_edges.remove(*j);
							j = temp;
						}
						else
						{
							auto temp = ++j;
							--j;
							(*i).m_edges.remove(*j);
							j = temp;
						}
					}
				}
				found = true;
			}

		}
		if (found == false)
		{
			throw Exception("Source not found");
		}
	}
	else
	{
		throw Exception("Dest not found");
	}
}


/*****************************************
* Purpose:	inserts vertex into graph if it is not a duplicate
* Precondition:
* Postcondition:
*		if vertex is not found in m_vertices, throws exception
*		loops through all vertices, deleting edges that point to vertex to delete
*		deletes vertex from m_vertices
*****************************************/
template<typename V, typename E>
void Graph<V, E>::DeleteVertex(V vertex)
{
	bool found = false;
	Vertex<V, E>* vertex_to_delete = nullptr;
	for (auto&& i = m_vertices.begin(); i != m_vertices.end() && found != true; ++i)
	{
		if ((*i).m_data == vertex)
		{
			found = true;
			vertex_to_delete = &(*i);
		}
	}
	if (found == true)
	{
		for (auto&& i = m_vertices.begin(); i != m_vertices.end(); ++i)
		{
			for (auto&& j = (*i).m_edges.begin(); j != (*i).m_edges.end(); ++j) // goes through list of edges for each vertex deleting edges that go to input vertex
			{
				if ((*j).m_dest->m_data == vertex)
				{
					if ((*j) == (*i).m_edges.back())
					{
						auto temp = --j;
						j++;
						(*i).m_edges.remove(*j);
						j = temp;
					}
					else
					{
						auto temp = ++j;
						--j;
						(*i).m_edges.remove(*j);
						j = temp;
					}
				}
			}
		}
		m_vertices.remove(*vertex_to_delete);
	}
	else
	{
		throw Exception("Vertex not found");
	}
}


/*****************************************
* Purpose:	check if graph is empty or not
* Precondition:
* Postcondition:
*		returns true if the graph is empty, and false if it has data
*****************************************/
template<typename V, typename E>
bool Graph<V, E>::isEmpty() const
{
	return m_vertices.empty();
}


/*****************************************
* Purpose:	Resets graph to default state
* Precondition:
* Postcondition:
*		m_vertices is cleared
*****************************************/
template<typename V, typename E>
void Graph<V, E>::Purge()
{
	m_vertices.clear();
}


/*****************************************
* Purpose:	allows us to access edge data and weight of edge between 2 vertices
* Precondition:
* Postcondition:
*		if no edge is found between the vertices, throws error
*		returns pair with edge data and weight of specific edge
*****************************************/
template<typename V, typename E>
pair<E, int> Graph<V, E>::getEdge(V source, V dest) const
{
	bool found = false;
	pair<E, int> data;
	for (auto&& i = m_vertices.begin(); i != m_vertices.end() && found != true; ++i)
	{
		if ((*i).m_data == source)
		{
			for (auto&& j = (*i).m_edges.begin(); j != (*i).m_edges.end() && found != true; ++j)
			{
				if ((*j).m_dest->m_data == dest)
				{
					data = std::make_pair((*j).m_data, (*j).m_weight);
					found = true;
				}
			}
		}
	}
	if (found == false)
	{
		throw Exception("Edge between vertices not found");
	}
	return data;
}


/*****************************************
* Purpose:	shows all vertices that are connected to source vertex
* Precondition:
* Postcondition:
*		if vertex is not found in m_vertices, throws error
*		returns stack with all vertices that are connected to source vertex
*****************************************/
template<typename V, typename E>
Stack<V> Graph<V, E>::getVertices(V source)
{
	bool found = false;
	Stack<V> temp;
	for (auto&& i = m_vertices.begin(); i != m_vertices.end() && found != true; ++i)
	{
		if ((*i).m_data == source)
		{
			found = true;
			for (auto&& j : (*i).m_edges)
			{
				if (j.m_dest->m_processed == false)
				{
					temp.Push(j.m_dest->m_data);
					j.m_dest->m_processed = true;
				}
			}
		}
	}
	for (auto&& i : m_vertices)
	{
		i.m_processed = false;
	}
	if (found == false)
	{
		throw Exception("Vertex not found");
	}
	return temp;
}


/*****************************************
* Purpose:	does depth-first traversal on all vertices connected to the first vertex in m_vertices (if they aren't connected to any vertices connected to m_vertices.front() they won't show)
* Precondition:
* Postcondition:
*		visit is called on all vertices that have some path from the first vertex in m_vertices
*****************************************/
template<typename V, typename E>
void Graph<V, E>::DepthFirst(void (*visit)(V data))
{
	Stack<Vertex<V, E>*> stack;
	Vertex<V, E>* temp = nullptr;
	stack.Push(&m_vertices.front());
	m_vertices.front().m_processed = true;
	while (!stack.isEmpty())
	{
		temp = stack.Pop();
		visit(temp->m_data);
		temp->m_processed = true;
		for (auto&& i : temp->m_edges)
		{
			if (i.m_dest->m_processed == false)
			{
				stack.Push(i.m_dest);
				i.m_dest->m_processed = true;
			}
		}
	}
	for (auto&& i : m_vertices)
	{
		i.m_processed = false;
	}
}


/*****************************************
* Purpose:	does breadth-first traversal on all vertices connected to the first vertex in m_vertices (if they aren't connected to any vertices connected to m_vertices.front() they won't show)
* Precondition:
* Postcondition:
*		visit is called on all vertices that have some path from the first vertex in m_vertices
*****************************************/
template<typename V, typename E>
void Graph<V, E>::BreadthFirst(void (*visit)(V data))
{
	Queue<Vertex<V, E>*> queue;
	Vertex<V, E>* temp = nullptr;
	queue.Enqueue(&m_vertices.front());
	m_vertices.front().m_processed = true;
	while (!queue.isEmpty())
	{
		temp = queue.Dequeue();
		visit(temp->m_data);
		for (auto&& i : temp->m_edges)
		{
			if (i.m_dest->m_processed == false)
			{
				queue.Enqueue(i.m_dest);
				i.m_dest->m_processed = true;
			}
		}
	}
	for (auto&& i : m_vertices)
	{
		i.m_processed = false;
	}
}


/*****************************************
* Purpose:	tells consumer amount of vertices in m_vertices
* Precondition:
* Postcondition:
*		returns m_vertices.size()
*****************************************/
template<typename V, typename E>
int Graph<V, E>::getNumVertices() const
{
	return m_vertices.size();
}


/*****************************************
* Purpose:	visits input vertex, using input function on it
* Precondition:
* Postcondition:
*		visit is called on vertex matching input
*****************************************/
template<typename V, typename E>
void Graph<V, E>::visit(V vertex, void(*visit)(V data))
{
	bool found = false;
	for (auto&& i = m_vertices.begin(); i != m_vertices.end() && found != true; ++i)
	{
		if ((*i).m_data == vertex)
		{
			visit((*i).m_data);
			found = true;
		}
	}
	if (found == false)
	{
		throw Exception("Vertex not found");
	}
}


/*****************************************
* Purpose:	tells consumer amount of edges in input vertex
* Precondition:
* Postcondition:
*		returns number of edges in vertex
*****************************************/
template<typename V, typename E>
int Graph<V, E>::getNumEdges(V vertex) const
{
	bool found = false;
	int num_edges = 0;
	for (auto&& i = m_vertices.begin(); i != m_vertices.end() && found != true; ++i)
	{
		if ((*i).m_data == vertex)
		{
			num_edges = (*i).m_edges.size();
			found = true;
		}
	}
	if (found == false)
	{
		throw Exception("Vertex not found");
	}
	return num_edges;
}