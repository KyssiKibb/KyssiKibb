#pragma once
/*****************************************
* Author: Kobi Conn
* Filename: node.h
* Date Created: 3/29/22
* Modifications:
*****************************************/

template<typename T> //forward declaration of List class (where in the class documentation do you put friends? that seems like a very important detail and it isn't shown in the example.
class List;


/*****************************************
* Class: Node
*
* Purpose: This class created nodes that will store data for our Doubly Linked List class
*
* Manager functions:
*		Node ( )
*			The default for m_next and m_previous is nullptr, and T gets their default constructor evoked
*		Node (T data)
*			m_next and m_previous get defaulted to nullptr, and T gets initialized with the data that is passed into the constructor
*		~Node ( )
*			Resets values of node back to default state (does not deallocate any memory)
*		Node (const Node<T> & copy)
*			Created a copy of a Node object by passing in a const ref version of Node.
*			does not take data, but does do a shallow copy of pointers
*		Node (Node<T> && copy)
*			Takes data in Node object and moves it into new instantiation.
*			sets old values to defaults to sever ties and prevent deleting same address.
*		operator = (const Node<T> & rhs)
*			Copies all data from Node<T> object into current object. checks for self assignment.
*			If not self assignment: deletes old data and copies data from rhs. always returns *this for function chaining
*		operator = (Node<T> && rhs)
*			Takes all data from Node<T> object and places it into current object. checks for self assignment.
*			If not self assignment: deletes old data, takes data from rhs, and sets rhs to default state. always returns *this for function chaining.
*
* Methods:
*		Purge ( )
*			Resets Node<T> object to default state. m_next and m_previous go to nullptr, and T gets set to its default state
*
*****************************************/
template<typename T>
class Node
{
	friend class List<T>;
public:
	Node();
	~Node();
	Node(const Node<T>& copy);
	Node(Node<T>&& copy) noexcept;
	Node& operator =(const Node<T>& rhs);
	Node& operator =(Node<T>&& rhs) noexcept;

	Node(T data);
	void Purge();

private:
	T m_data;
	Node<T>* m_next;
	Node<T>* m_previous;
};

/*****************************************
* Purpose: Instantiates a default version of Node<T>
*
* Precondition:
*
* Postcondition:
*		default constructs m_data
*		sets m_next and m_previous to nullptr
*****************************************/
template<typename T>
Node<T>::Node() : m_data(), m_next(nullptr), m_previous(nullptr)
{ }

/*****************************************
* Purpose: This function resets a Node<T> object back to its default state
*
* Precondition:
*
* Postcondition:
*		Resets Node<T> to default values
*****************************************/
template<typename T>
Node<T>::~Node()
{
	Purge();
}


/*****************************************
* Purpose: Creates a Node<T> object by copying another Node<T>
*
* Precondition:
*
* Postcondition:
*		instantiates Node<T> with copy of copies' data
*****************************************/
template<typename T>
Node<T>::Node(const Node<T>& copy) : m_data(copy.m_data), m_next(copy.m_next), m_previous(copy.m_previous)
{

}


/*****************************************
* Purpose: Creates a Node<T> object and moves data from other Node<T> object into it
*
* Precondition:
*
* Postcondition:
*		takes copies data and sets copies' data to default to sever ties to original data
*****************************************/
template<typename T>
Node<T>::Node(Node<T>&& copy) noexcept : m_data(std::move(copy.m_data)), m_next(copy.m_next), m_previous(copy.m_previous)
{
	copy.Purge();
}


/*****************************************
* Purpose: copies data from a Node<T> into current object
*
* Precondition:
*		Not self assignment
*
* Postcondition:
*		sets m_data to copy of rhs.m_data
*		Returns *this for function chaining
*****************************************/
template<typename T>
Node<T>& Node<T>::operator =(const Node<T>& rhs)
{
	if (this != &rhs)
	{
		m_data = rhs.m_data;
	}
	return *this;
}


/*****************************************
* Purpose: Moves data from Node<T> to current object
*
* Precondition:
*		Not self assignment
*
* Postcondition:
*		takes data from rhs and resets rhs to default state
*****************************************/
template<typename T>
Node<T>& Node<T>::operator =(Node<T>&& rhs) noexcept
{
	if (this != &rhs)
	{
		m_data = std::move(rhs.m_data);
		m_next = rhs.m_next;
		m_previous = rhs.m_previous;
		rhs.Purge();
	}
	return *this;
}



/*****************************************
* Purpose: This function instantiates a Node<T> object with m_data set to T data
*
* Precondition:
*
* Postcondition:
*		New Node<T> object with m_data set to T data
*****************************************/
template<typename T>
Node<T>::Node(T data) : m_data(data), m_next(nullptr), m_previous(nullptr)
{

}


/*****************************************
* Purpose: This function resets a Node<T> object back to its default state
*
* Precondition:
*
* Postcondition:
*		Modifies Node<T> to default values
*****************************************/
template<typename T>
void Node<T>::Purge()
{
	m_data = T();
	m_next = nullptr;
	m_previous = nullptr;
}
