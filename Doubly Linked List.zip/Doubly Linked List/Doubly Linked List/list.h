#pragma once
/*****************************************
* Author: Kobi Conn
* Filename: list.h
* Date Created: 3/29/22
* Modifications: 4/1/22 finished writing Extract, insertBefore, InsertAfter, PrintForwards, PrintBackwards.
*****************************************/
#include <iostream>
using std::cout;
using std::endl;

#include "node.h"
#include "exception.h"


/*****************************************
* Class: List
*
* Purpose: This class holds pointers to Node<T> objects that contain any type of data that we want. automatically resizes itself and manipulates data
*
* Manager functions:
*		List ( )
*			The default for m_head and m_tail is nullptr
*		~List ( )
*			Deletes all allocated memory in the List<T> and resets m_head and m_tail to nullptr
*		List (const List<T> & copy)
*			Creates a copy of a List<T> object by passing in a const ref version of another List<T>.
*			goes through all nodes doing deep copy
*		List (List<T> && copy)
*			Takes m_head and m_tail from copy
*			sets copies' m_head and m_tail to nullptr to sever ties and prevent deleting same address.
*		operator = (const List<T> & rhs)
*			Copies all data from rhs List<T> object into current object. checks for self assignment.
*			If not self assignment: deletes old data and copies data from rhs. always returns *this for function chaining
*		operator = (List<T> && rhs)
*			Takes pointers from List<T> object and places it into current object. checks for self assignment.
*			If not self assignment: deletes old data, takes data from rhs, and sets rhs to default state. always returns *this for function chaining.
*
* Methods:
*		isEmpty ( )
*			checks to see if there are any nodes in the List
*		First ( )
*			Returns a const ref to the data in the first element of List
*		Last ( )
*			Returns a const ref to the data in the last element of List
*		Prepend ( )
*			Adds a Node to the front of the List
*		Append ( )
*			Adds a Node to the end of the List
*		Purge ( )
*			Deallocates all memory in List and resets Head and Tail to nullptr
*		Extract (T data)
*			Remove a Node from the list based on input T data
*		InsertAfter (T new_item, T existing_item)
*			Inserts a Node with new_item after the Node with existing_item
*		InsertBefore (T new_item, T existing_item)
*			Inserts a Node with new_item before Node with existing_item
*		getHead ( )
*			Returns Head pointer (ONLY FOR TESTING)
*		getTail ( )
*			Returns Tail pointer (ONLY FOR TESTING)
*		PrintForwards ( ) 
*			Prints every Node's T m_data from front to back (ONLY FOR TESTING)
*		PrintBackwards ( )
*			Prints every Node's T m_data from back to front (ONLY FOR TESTING)
*
*****************************************/
template<typename T>
class List
{
public:
	List();
	~List();
	List(const List<T> & copy);
	List(List<T> && copy) noexcept;
	List<T>& operator =(const List<T> & rhs);
	List<T>& operator =(List<T> && rhs) noexcept;



	bool isEmpty() const;
	const T& First() const;
	const T& Last() const;
	void Prepend(T data);
	void Append(T data);
	void Purge();
	void Extract(T data);
	void InsertAfter(T new_item, T existing_item);
	void InsertBefore(T new_item, T existing_item);
	Node<T>* getHead() const; // testing purposes only
	Node<T>* getTail() const; // testing purposes only
	void PrintForwards() const; // testing purposes only
	void PrintBackwards() const; // testing purposes only








private:
	Node<T>* m_head;
	Node<T>* m_tail;
};


/*****************************************
* Purpose: instantiate a List<T> object into a known good state
*
* Precondition:
*
* Postcondition:
*		constructs empty list with data members m_head and m_tail set to nullptr
*****************************************/
template<typename T>
List<T>::List() : m_head(nullptr), m_tail(nullptr)
{

}


/*****************************************
* Purpose: Reset List<T> to default state
*
* Precondition:
*
* Postcondition:
*		deallocates all memory in List<T> object's nodes and sets m_head and m_tail back to nullptr
*****************************************/
template<typename T>
List<T>::~List()
{
	Purge();
}


/*****************************************
* Purpose: instantiate a List<T> object with another List<T> object
*
* Precondition:
*
* Postcondition:
*		creates a deep copy of all nodes from copy into current List<T>
*****************************************/
template<typename T>
List<T>::List(const List<T>& copy)
{
	Node<T>* travel = copy.m_head;
	Node<T>* nn = nullptr;
	while (travel != nullptr)
	{
		Append(travel->m_data);
		travel = travel->m_next;
	}
}


/*****************************************
* Purpose: move the data from an instance of List<T> into a new instance of List<T>
*
* Precondition:
*
* Postcondition:
*		takes pointers from copy and sets copy tail and head to nullptr
*****************************************/
template<typename T>
List<T>::List(List<T>&& copy) noexcept : m_head(copy.m_head), m_tail(copy.m_tail)
{
	copy.m_head = nullptr;
	copy.m_tail = nullptr;
}


/*****************************************
* Purpose: create a List<T> with data copied from rhs
*
* Precondition:
*		Not self assignment
*
* Postcondition:
*		Returns *this for function chaining
*		Creates a deep copy of rhs
*****************************************/
template<typename T>
List<T>& List<T>::operator =(const List<T>& rhs)
{
	if (this != &rhs)
	{
		Purge();
		Node<T>* travel = rhs.m_head;
		Node<T>* nn = nullptr;
		while (travel != nullptr)
		{
			Append(travel->m_data);
			travel = travel->m_next;
		}
	}
	return *this;
}


/*****************************************
* Purpose: Move data from one list into another
*
* Precondition:
*		Not self Assignment
*
* Postcondition:
*		Deletes old data in List<T>
*		Moves pointers from rhs to lhs
*		Returns *this for function chaining
*****************************************/
template<typename T>
List<T>& List<T>::operator =(List<T>&& rhs) noexcept
{
	if (this != &rhs)
	{
		Purge();
		m_head = rhs.m_head;
		m_tail = rhs.m_tail;
		rhs.m_head = nullptr;
		rhs.m_tail = nullptr;
	}
	return *this;
}






/*****************************************
* Purpose: Return true or false based on if there is a Node<T> object in list
*
* Precondition:
*		List<T> object has been instantiated
*
* Postcondition:
*		Returns false if m_head is not nullptr (not empty)
*		Returns true if m_head is nullptr (empty)
*****************************************/
template<typename T>
bool List<T>::isEmpty() const
{
	bool empty = true;
	if (m_head != nullptr)
		empty = false;
	return empty;
}


/*****************************************
* Purpose: Returns const ref to data from the first element of the List<T> object
*
* Precondition:
*		There is a Node<T> object in the List<T> object
*
* Postcondition:
*		Returns const & to data in first element (m_head's data)
*****************************************/
template<typename T>
const T& List<T>::First() const
{
	if (m_head == nullptr)
	{
		throw Exception("there is no Data in List.");
	}
	return m_head->m_data;
}


/*****************************************
* Purpose: Returns const ref to data from the last element of the List<T> object
*
* Precondition:
*		There is a Node<T> object in the List<T> object
*		
*
* Postcondition:
*		Returns const & to data in last element (m_tail's data)
*****************************************/
template<typename T>
const T& List<T>::Last() const
{
	if (m_tail == nullptr)
	{
		throw Exception("there is no Data in List");
	}
	return m_tail->m_data;
}


/*****************************************
* Purpose: Creates a new Node<T> object using data passed in and adds the node to the beginning of the list
*
* Precondition:
*		Passed in data of type T
*
*
* Postcondition:
*		Adds new Node<T> object to the list, linking the new Node<T> object to beginning of list, and changing m_head to new address. if array is empty, also sets m_tail value.
*****************************************/
template<typename T>
void List<T>::Prepend(T data)
{
	Node<T>* nn = new Node<T>(data);
	if (m_head == nullptr)
	{
		m_head = nn;
		m_tail = nn;
	}
	else
	{
		nn->m_next = m_head;
		m_head->m_previous = nn;
		m_head = nn;
	}
}


/*****************************************
* Purpose: Creates a new Node<T> object using data passed in and adds the node to the end of the list
*
* Precondition:
*		Passed in data of type T
*
*
* Postcondition:
*		Adds new Node<T> object to the list, linking the new Node<T> object to the end of List<T> and changing m_tail to new address. if array is empty, also sets m_head value.
*****************************************/
template<typename T>
void List<T>::Append(T data)
{
	Node<T>* nn = new Node<T>(data);
	if (m_tail == nullptr)
	{
		m_head = nn;
		m_tail = nn;
	}
	else
	{
		nn->m_previous = m_tail;
		m_tail->m_next = nn;
		m_tail = nn;
	}
}


/*****************************************
* Purpose: Deletes all Node<T> objects in List<T> object and resets it to its default state
*
* Precondition:
*
*
* Postcondition:
*		List<T> object is now empty, with head and tail pointing at nullptr
*****************************************/
template<typename T>
void List<T>::Purge()
{
	Node<T>* travel = nullptr;
	while (m_head != nullptr)
	{
		travel = m_head;
		m_head = m_head->m_next;
		delete travel;
	}
	m_tail = nullptr;
}


/*****************************************
* Purpose: Removes Node<T> object from list based on input data
*
* Precondition:
*		m_head is not nullptr
*		input data is in the List<T>
*
*
* Postcondition:
*		removes T data Node<T>, shrinking the size of the List<T>
*****************************************/
template<typename T>
void List<T>::Extract(T data)
{
	if (m_head != nullptr)
	{
		Node<T>* travel = m_head;
		while (travel != nullptr && travel->m_data != data)
		{
			travel = travel->m_next;
		}
		if (travel != nullptr)
		{
			if (travel == m_head)
			{
				if (m_head == m_tail)
				{
					m_head = nullptr;
					m_tail = nullptr;
					delete travel;
					travel = nullptr;
				}
				else
				{

					m_head = m_head->m_next;
					m_head->m_previous = nullptr;
					delete travel;
					travel = nullptr;
				}
			}
			else if (travel == m_tail)
			{
				m_tail = m_tail->m_previous;
				if(m_tail != nullptr)
					m_tail->m_next = nullptr;
				delete travel;
				travel = nullptr;
			}
			else
			{
				travel->m_previous->m_next = travel->m_next;
				travel->m_next->m_previous = travel->m_previous;
				delete travel;
				travel = nullptr;
			}
		}
		else
		{
			throw Exception("Data not found in Linked List");
		}
	}
	else
	{
		throw Exception("Linked List has no data to extract");
	}
}


/*****************************************
* Purpose: Inserts a Node<T> with data of T new_data after an existing item in the List<T>
*
* Precondition:
*		m_head is not nullptr
*		T existing_item is in the List<T>
*
*
* Postcondition:
*		Adds new Node<T> object to the list after the Node<T> object containing T existing_item
*****************************************/
template<typename T>
void List<T>::InsertAfter(T new_item, T existing_item)
{
	if (m_head != nullptr)
	{
		Node<T>* travel = m_head;
		Node<T>* nn = nullptr;
		while (travel != nullptr && travel->m_data != existing_item)
		{
			travel = travel->m_next;
		}
		if (travel != nullptr)
		{

			if (travel == m_tail)
			{
				nn = new Node<T>(new_item);
				travel->m_next = nn;
				nn->m_previous = travel;
				m_tail = nn;
			}
			else
			{
				nn = new Node<T>(new_item);
				travel->m_next->m_previous = nn;
				nn->m_next = travel->m_next;
				nn->m_previous = travel;
				travel->m_next = nn;
			}
		}
		else
		{
			throw Exception("Data not found in Linked List");
		}
	}
	else
	{
		throw Exception("Linked List has no elements to insert before or after");
	}
}


/*****************************************
* Purpose: Inserts a Node<T> with input data (new_data) before an existing item in the List<T>
*
* Precondition:
*		m_head is not nullptr
*		T existing_item is in the List<T>
*
*
* Postcondition:
*		Adds new Node<T> object to the list before the Node<T> object containing T existing_item
*****************************************/
template<typename T>
void List<T>::InsertBefore(T new_item, T existing_item)
{
	if (m_head != nullptr)
	{
		Node<T>* travel = m_head;
		Node<T>* nn = nullptr;
		while (travel != nullptr && travel->m_data != existing_item)
		{
			travel = travel->m_next;
		}
		if (travel != nullptr)
		{
			if (travel == m_head)
			{
				nn = new Node<T>(new_item);
				nn->m_next = travel;
				travel->m_previous = nn;
				m_head = nn;
			}
			else
			{
				nn = new Node<T>(new_item);
				nn->m_next = travel;
				nn->m_previous = travel->m_previous;
				travel->m_previous->m_next = nn;
				travel->m_previous = nn;
			}
		}
		else
		{
			throw Exception("Data not found in Linked List");
		}
	}
	else
	{
		throw Exception("Linked List has no elements to insert before or after");
	}
}


/*****************************************
* Purpose: test whether or not Head is properly being updated (FOR TESTING ONLY)
*
* Precondition:
*		List<T> object has been instantiated
*
* Postcondition:
*		Returns a Node<T>* to m_head
*****************************************/
template<typename T>
Node<T>* List<T>::getHead() const
{
	return m_head;
}


/*****************************************
* Purpose: test whether or not Head is properly being updated (FOR TESTING ONLY)
*
* Precondition:
*		List<T> object has been instantiated
*
* Postcondition:
*		Returns a Node<T>* to m_tail
*****************************************/
template<typename T>
Node<T>* List<T>::getTail() const
{
	return m_tail;
}



/*****************************************
* Purpose: Traverses List<T> object forwards printing all T data
*
* Precondition:
*
*
* Postcondition:
*		prints all data in List<T> forwards
*****************************************/
template<typename T>
void List<T>::PrintForwards() const
{
	Node<T>* travel = m_head;
	while (travel != nullptr)
	{
		cout << travel->m_data << endl;
		travel = travel->m_next;
	}
}


/*****************************************
* Purpose: Traverses backwards through List<T> object, printing all T data
*
* Precondition:
*
*
* Postcondition:
*		prints all data in List<T> backwards
*****************************************/
template<typename T>
void List<T>::PrintBackwards() const
{
	Node<T>* travel = m_tail;
	while (travel != nullptr)
	{
		cout << travel->m_data << endl;
		travel = travel->m_previous;
	}
}
