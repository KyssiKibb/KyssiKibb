/*****************************************
* Author: Kobi Conn
* Filename: main.cpp
* Date Created: 3/29/22
* Modifications: 4/1/22 deleted everything to copy the test code you had
*****************************************/


//when i emailed asking you said i only needed the file block. i didn't want to keep the test cases in here because that would just be plagiarism if i added my stuff to the top and pretended it was mine.
//i had my own tests but i got rid of them to copy paste your test cases in here.
//i also noticed that the testing you have on there doesn't actually testing for print forwards and print backwards. 
//is that because the words (TESTING ONLY) literally meant that you weren't going to use them or are they meant to be tested by your file to show integrity?
//also the function definitions do not specify which should be const.
//i'm assuming that's because you want us to know const correctness for ourselves but clarification would be nice.

//for the function headers, i don't think i did them very well. i understand the purpose one and precondition, but postcondition is kinda just repeating purpose for 90% of them.
//when i was initially learning documentation i did it with general purpose and then a block of pseudocode instead.
//However, the scoresheet says that you have to follow the style guide. i mostly am just curious how i did with your style and what i should change to make it better. Thanks in advance



int main()
{
	return 0;
}