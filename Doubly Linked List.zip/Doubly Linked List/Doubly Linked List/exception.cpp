/*****************************************
* Author: Kobi Conn
* Filename: exception.cpp
* Date Created: 4/1/22
* Modifications:
*****************************************/

#include <iostream>
using std::endl;
using std::ostream;

#include "exception.h"


/*****************************************
* Purpose: instantiate an Exception object into a known good state, where m_msg is nullptr
*
* Precondition:
*		you are instantiating an Exception object with no input parameters
*
* Postcondition:
*		constructs Exception with m_msg being nullptr
*****************************************/
Exception::Exception(): m_msg(nullptr)
{

}


/*****************************************
* Purpose: Resets Exception object into default state
*
* Precondition:
*
* Postcondition:
*		Deletes allocated memory and sets m_msg back to nullptr
*****************************************/
Exception::~Exception()
{
	delete[] m_msg;
	m_msg = nullptr;
}


/*****************************************
* Purpose: instantiates an Exception object using msg as the value for m_msg
*
* Precondition:
*
* Postcondition:
*		constructs empty list with data members m_head and m_tail set to nullptr
*****************************************/
Exception::Exception(const char* msg) : m_msg(nullptr)
{
	if (msg != nullptr)
	{
		m_msg = new char[strlen(msg) + 1];
		strncpy_s(m_msg, strlen(msg) + 1, msg, strlen(msg) + 1);
	}
}


/*****************************************
* Purpose: instantiate an Exception object using another Exception object
*
* Precondition:
*
* Postcondition:
*		constructs new Exception object with a deep copy of m_msg
*****************************************/
Exception::Exception(const Exception& copy) : m_msg(nullptr)
{
	if (copy.m_msg != nullptr)
	{
		m_msg = new char[strlen(copy.m_msg) + 1];
		strncpy_s(m_msg, strlen(copy.m_msg) + 1, copy.m_msg, strlen(copy.m_msg) + 1);
	}
}


/*****************************************
* Purpose: instantiates an Exception object, taking the data from another Exception object
*
* Precondition:
*
* Postcondition:
*		shallow copies m_msg and sets copy.m_msg to nullptr
*****************************************/
Exception::Exception(Exception&& copy) noexcept: m_msg(copy.m_msg)
{
	copy.m_msg = nullptr;
}


/*****************************************
* Purpose: copies Exception object through assignment
*
* Precondition:
*		It is not self assignment
*
* Postcondition:
*		both Exception objects hold different copies of the same m_msg
*****************************************/
Exception& Exception::operator =(const Exception& rhs)
{
	if (this != &rhs)
	{
		delete[] m_msg;
		m_msg = nullptr;
		if (rhs.m_msg != nullptr)
		{
			m_msg = new char[strlen(rhs.m_msg) + 1];
			strncpy_s(m_msg, strlen(rhs.m_msg) + 1, rhs.m_msg, strlen(rhs.m_msg) + 1);
		}
	}
	return *this;
}


/*****************************************
* Purpose: moves m_msg from rhs into lhs
*
* Precondition:
*		It is not self assignment
*
* Postcondition:
*		deallocates lhs' previously pointed to data and moves data from rhs to lhs, setting rhs.m_msg to nullptr to sever the tie
*****************************************/
Exception& Exception::operator =(Exception&& rhs) noexcept
{
	if (this != &rhs)
	{
		delete[] m_msg;
		m_msg = rhs.m_msg;
		rhs.m_msg = nullptr;
	}
	return *this;
}


/*****************************************
* Purpose: Return the char* in m_msg
*
* Precondition:
*
* Postcondition:
*		returns m_msg in form of const char*
*****************************************/
const char* Exception::getMessage() const
{
	return m_msg;
}


/*****************************************
* Purpose: changes current m_msg to a copy of what is pointed to in msg
*
* Precondition:
*
* Postcondition:
*		m_msg holds a copy of msg
*****************************************/
void Exception::setMessage(const char* msg)
{
	delete[] m_msg;
	m_msg = nullptr;
	if (msg != nullptr)
	{
		m_msg = new char[strlen(msg) + 1];
		strncpy_s(m_msg, strlen(msg) + 1, msg, strlen(msg) + 1);
	}

}


/*****************************************
* Purpose: allows you to use << operator to display m_msg
*
* Precondition:
*
* Postcondition:
*		displays m_msg and returns ostream by ref for function chaining
*****************************************/
ostream& operator<<(ostream& stream, const Exception& except)
{
	stream << except.getMessage() << endl;
	return stream;
}