/*****************************************
* Author: Kobi Conn
* Filename: main.cpp
* Date Created: 4/10/22
* Modifications:
*****************************************/
/*****************************************
* 
* Lab/Assignment: List Based Stack
* 
* Overview:
*	This program will test all of the functions in the templated
*	Stack class with both primitive and complex types.
* 
* Input:
*	There is no inputs
* 
* Output:
*	Displays whether the test for any of the functions passes or fails in console.
*	Output will be in the form : X function test passed/failed
*****************************************/
#define _CRTDBG_MAP_ALLOC
typedef bool(*FunctionPointer)();  // Define a funtion pointer type
#include <string>
using std::string;
#include <iostream>
using std::cout;
using std::cin;
#include <crtdbg.h>
#include "stack.h"
// Strings to test
const char* NAMES[] = { "Kyle", "Brit", "seth", "Alex", "Josh", "Kian",
"Kate", "Terry", "Ann", "Elaine", "Stephanie", "Wanda", "Oscar",
"Oliver", "Tobey" };
const int NUM_NAMES = 15;
// Test function declaration
bool test_default_ctor();
bool test_copy_ctor();
bool test_move_ctor();
bool test_copy_assignment();
bool test_move_assignment();
bool test_push();
bool test_pop();
bool test_peek();
bool test_getnumelements();
bool test_isempty();
//
// Complex tests
bool test_default_ctor_complex();
bool test_copy_ctor_complex();
bool test_move_ctor_complex();
bool test_copy_assignment_complex();
bool test_move_assignment_complex();
bool test_push_complex();
bool test_pop_complex();
bool test_peek_complex();
bool test_getnumelements_complex();
bool test_isempty_complex();

FunctionPointer test_functions[] =
{
	test_default_ctor
	,test_copy_ctor
	,test_move_ctor
	,test_copy_assignment
	,test_move_assignment
	,test_push
	,test_pop
	,test_peek
	,test_getnumelements
	,test_isempty
	,test_default_ctor_complex
	,test_copy_ctor_complex
	,test_move_ctor_complex
	,test_copy_assignment_complex
	,test_move_assignment_complex
	,test_push_complex
	,test_pop_complex
	,test_peek_complex
	,test_getnumelements_complex
	,test_isempty_complex
};

int main()
{
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
	// Run the test functions
	for (FunctionPointer func : test_functions)
	{
		if (func())
		{
			cout << "passed\n";
		}
		else
		{
			cout << "***** failed *****\n";
		}
	}
	cout << "\nPress Any Key to Exit";

	cin.get();
	return 0;
}
bool test_default_ctor()
{
	bool passed = true;
	Stack<int> test;
	if (test.getNumElements() != 0)
	{
		passed = false;
	}
	cout << "default ctor test ";
	return passed;
}
bool test_copy_ctor()
{
	bool passed = true;
	Stack<int> test;
	test.Push(5);
	Stack<int> test2(test);
	if (test2.Pop() != 5)
	{
		passed = false;
	}
	cout << "copy ctor test ";
	return passed;
}
bool test_move_ctor()
{
	bool passed = false;
	Stack<int> test;
	test.Push(5);
	Stack<int> test2(std::move(test));
	try
	{
		test.Pop();
	}
	catch (Exception a)
	{
		passed = true;
	}
	if (test2.Pop() != 5)
	{
		passed = false;
	}
	cout << "move ctor test ";
	return passed;
}
bool test_copy_assignment()
{
	bool passed = true;
	Stack<int> test;
	test.Push(5);
	Stack<int> test2;
	test2 = test;
	test2 = test2; // testing self assignment deleting info
	if (test2.Pop() != 5)
	{
		passed = false;
	}
	if (test.Pop() != 5) //doesn't get rid of old data
	{
		passed = false;
	}
	cout << "copy assignment test ";
	return passed;
}
bool test_move_assignment()
{
	bool passed = false;
	Stack<int> test;
	test.Push(5);
	Stack<int> test2;
	test2 = std::move(test);
	try
	{
		test.Pop();
	}
	catch (Exception a)
	{
		passed = true;
	}
	test2 = std::move(test2); //testing self assignment
	if (test2.Pop() != 5)
	{
		passed = false;
	}
	cout << "move assignment test ";
	return passed;
}
bool test_push()
{
	bool passed = true;
	Stack<int> test;
	for (int i = 0; i < 5; ++i)
	{
		test.Push(i);
	}
	if (test.Pop() != 4) // data integrity on pushes
	{
		passed = false;
	}
	cout << "Push test ";
	return passed;
}
bool test_pop()
{
	bool passed = false;
	Stack<int> test;
	try
	{
		test.Pop(); //pop on an empty stack
	}
	catch (Exception a)
	{
		passed = true;
	}
	test.Push(10);
	if (test.getNumElements() != 1)
	{
		passed = false;
	}
	if (test.Pop() != 10)
	{
		passed = false;
	}
	cout << "Pop test ";
	return passed;
}
bool test_peek()
{
	bool passed = false;
	Stack<int> test;
	try
	{
		test.Peek();
	}
	catch (Exception a)
	{
		passed = true;
	}
	test.Push(10);
	if (test.Peek() != 10)
	{
		passed = false;
	}
	cout << "Peek test ";
	return passed;
}
bool test_getnumelements()
{
	bool passed = true;
	Stack<int> test;
	if (test.getNumElements() != 0)
	{
		passed = false;
	}
	test.Push(10);
	if (test.getNumElements() != 1)
	{
		passed = false;
	}
	test.Push(10);
	test.Push(10);
	test.Push(10);
	test.Push(10);
	if (test.getNumElements() != 5)
	{
		passed = false;
	}
	cout << "getNumElements test ";
	return passed;
}
bool test_isempty()
{
	bool passed = true;
	Stack<int> test;
	if (test.isEmpty() != true)
	{
		passed = false;
	}
	test.Push(10);
	if (test.isEmpty() != false)
	{
		passed = false;
	}
	cout << "isEmpty test ";
	return passed;
}

bool test_default_ctor_complex()
{
	bool passed = true;
	Stack<string> test;
	if (test.getNumElements() != 0)
	{
		passed = false;
	}
	cout << "default ctor test complex ";
	return passed;
}
bool test_copy_ctor_complex()
{
	bool passed = true;
	Stack<string> test;
	test.Push(NAMES[0]);
	Stack<string> test2(test);
	if (test2.Pop() != NAMES[0])
	{
		passed = false;
	}
	if (test.Pop() != NAMES[0])
	{
		passed = false;
	}
	cout << "copy ctor test complex ";
	return passed;
}
bool test_move_ctor_complex()
{
	bool passed = false;
	Stack<string> test;
	test.Push(NAMES[0]);
	Stack<string> test2(std::move(test));
	try
	{
		test.Pop();
	}
	catch (Exception a)
	{
		passed = true;
	}
	if (test2.getNumElements() != 1)
	{
		passed = false;
	}
	if (test2.Pop() != NAMES[0])
	{
		passed = false;
	}
	cout << "move ctor test complex ";
	return passed;
}
bool test_copy_assignment_complex()
{
	bool passed = true;
	Stack<string> test;
	test.Push(NAMES[0]);
	Stack<string> test2;
	test2.Push(NAMES[1]);
	test2 = test2; // testing self assignment
	if (test2.Pop() != NAMES[1])
	{
		passed = false;
	}
	test2 = test;
	if (test2.Pop() != NAMES[0])
	{
		passed = false;
	}
	if (test.Pop() != NAMES[0])
	{
		passed = false;
	}
	cout << "copy assignment test complex ";
	return passed;
}
bool test_move_assignment_complex()
{
	bool passed = false;
	Stack<string> test;
	test.Push(NAMES[0]);
	Stack<string> test2;
	test2 = std::move(test);
	try
	{
		test.Pop(); //testing if resets other data
	}
	catch (Exception a)
	{
		passed = true;
	}
	test2 = std::move(test2); //testing self assignment
	if (test2.getNumElements() != 1)
	{
		passed = false;
	}
	if (test2.Pop() != NAMES[0])
	{
		passed = false;
	}
	cout << "move assignment test complex ";
	return passed;
}
bool test_push_complex()
{
	bool passed = true;
	Stack<string> test;
	for (int i = 0; i < 5; ++i)
	{
		test.Push(NAMES[i]);
	}
	if (test.Pop() != NAMES[4]) // data integrity on pushes
	{
		passed = false;
	}
	cout << "Push test complex ";
	return passed;
}
bool test_pop_complex()
{
	bool passed = false;
	Stack<string> test;
	try
	{
		test.Pop(); //pop on an empty stack
	}
	catch (Exception a)
	{
		passed = true;
	}
	test.Push(NAMES[0]);
	if (test.getNumElements() != 1)
	{
		passed = false;
	}
	if (test.Pop() != NAMES[0])
	{
		passed = false;
	}
	cout << "Pop test complex ";
	return passed;
}
bool test_peek_complex()
{
	bool passed = false;
	Stack<string> test;
	try
	{
		test.Peek();
	}
	catch (Exception a)
	{
		passed = true;
	}
	test.Push(NAMES[0]);
	if (test.Peek() != NAMES[0])
	{
		passed = false;
	}
	cout << "Peek test complex ";
	return passed;
}
bool test_getnumelements_complex()
{
	bool passed = true;
	Stack<string> test;
	test.Push(NAMES[0]);
	if (test.getNumElements() != 1)
	{
		passed = false;
	}
	cout << "getNumElements test complex ";
	return passed;
}
bool test_isempty_complex()
{
	bool passed = true;
	Stack<string> test;
	if (test.isEmpty() != true)
	{
		passed = false;
	}
	test.Push(NAMES[0]);
	if (test.isEmpty() != false)
	{
		passed = false;
	}
	cout << "isEmpty test complex ";
	return passed;
}
