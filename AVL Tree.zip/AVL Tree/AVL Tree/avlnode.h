#pragma once
/*****************************************
* Author: Kobi Conn
* Filename: avlnode.h
* Date Created: 4/18/22
* Modifications:	4/18/22 used node class for linked list as basis and changed naming conventions
*****************************************/

template<typename T> //forward declaration of List class (where in the class documentation do you put friends? that seems like a very important detail and it isn't shown in the example.
class AVLTree;


/*****************************************
* Class: AVLNode
*
* Purpose: This class created nodes that will store data for our Doubly Linked List class
*
* Manager functions:
*		AVLNode ( )
*			The default for m_right and m_left is nullptr, and T gets their default constructor evoked
*		AVLNode (T data)
*			m_right and m_left get defaulted to nullptr, and T gets initialized with the data that is passed into the constructor
*		~AVLNode ( )
*			Resets values of node back to default state (does not deallocate any memory)
*		AVLNode (const AVLNode<T> & copy)
*			Created a copy of a AVLNode object by passing in a const ref version of AVLNode.
*			does not take data, but does do a shallow copy of pointers
*		AVLNode (AVLNode<T> && copy)
*			Takes data in AVLNode object and moves it into new instantiation.
*			sets old values to defaults to sever ties and prevent deleting same address.
*		operator = (const AVLNode<T> & rhs)
*			Copies all data from AVLNode<T> object into current object. checks for self assignment.
*			If not self assignment: deletes old data and copies data from rhs. always returns *this for function chaining
*		operator = (AVLNode<T> && rhs)
*			Takes all data from AVLNode<T> object and places it into current object. checks for self assignment.
*			If not self assignment: deletes old data, takes data from rhs, and sets rhs to default state. always returns *this for function chaining.
*
* Methods:
*		Purge ( )
*			Resets AVLNode<T> object to default state. m_right and m_left go to nullptr, and T gets set to its default state
*		getData ( )
*			Returns m_data by value (for testing purposes)
*****************************************/
template<typename T>
class AVLNode
{
	friend class AVLTree<T>;
public:
	AVLNode();
	~AVLNode();
	AVLNode(const AVLNode<T>& copy);
	AVLNode(AVLNode<T>&& copy) noexcept;
	AVLNode<T>& operator =(const AVLNode<T>& rhs);
	AVLNode<T>& operator =(AVLNode<T>&& rhs) noexcept;

	AVLNode(T data);
	void Purge();
	T getData() const;

private:
	T m_data;
	AVLNode<T>* m_left;
	AVLNode<T>* m_right;
};

/*****************************************
* Purpose: Instantiates a default version of AVLNode<T>
*
* Precondition:
*
* Postcondition:
*		default constructs m_data
*		sets m_right and m_left to nullptr
*****************************************/
template<typename T>
AVLNode<T>::AVLNode() : m_data(), m_right(nullptr), m_left(nullptr)
{ }

/*****************************************
* Purpose: This function resets a AVLNode<T> object back to its default state
*
* Precondition:
*
* Postcondition:
*		Resets AVLNode<T> to default values
*****************************************/
template<typename T>
AVLNode<T>::~AVLNode()
{
	Purge();
}


/*****************************************
* Purpose: Creates a AVLNode<T> object by copying another AVLNode<T>
*
* Precondition:
*
* Postcondition:
*		instantiates AVLNode<T> with copy of copies' data
*****************************************/
template<typename T>
AVLNode<T>::AVLNode(const AVLNode<T>& copy) : m_data(copy.m_data), m_right(copy.m_right), m_left(copy.m_left)
{

}


/*****************************************
* Purpose: Creates a AVLNode<T> object and moves data from other AVLNode<T> object into it
*
* Precondition:
*
* Postcondition:
*		takes copies data and sets copies' data to default to sever ties to original data
*****************************************/
template<typename T>
AVLNode<T>::AVLNode(AVLNode<T>&& copy) noexcept : m_data(std::move(copy.m_data)), m_right(copy.m_right), m_left(copy.m_left)
{
	copy.Purge();
}


/*****************************************
* Purpose: copies data from a AVLNode<T> into current object
*
* Precondition:
*		Not self assignment
*
* Postcondition:
*		sets m_data to copy of rhs.m_data
*		Returns *this for function chaining
*****************************************/
template<typename T>
AVLNode<T>& AVLNode<T>::operator =(const AVLNode<T>& rhs)
{
	if (this != &rhs)
	{
		m_left = rhs.m_left;
		m_data = rhs.m_data;
		m_right = rhs.m_right;
	}
	return *this;
}


/*****************************************
* Purpose: Moves data from AVLNode<T> to current object
*
* Precondition:
*		Not self assignment
*
* Postcondition:
*		takes data from rhs and resets rhs to default state
*****************************************/
template<typename T>
AVLNode<T>& AVLNode<T>::operator =(AVLNode<T>&& rhs) noexcept
{
	if (this != &rhs)
	{
		m_data = std::move(rhs.m_data);
		m_right = rhs.m_right;
		m_left = rhs.m_left;
		rhs.Purge();
	}
	return *this;
}



/*****************************************
* Purpose: This function instantiates a AVLNode<T> object with m_data set to T data
*
* Precondition:
*
* Postcondition:
*		New AVLNode<T> object with m_data set to T data
*****************************************/
template<typename T>
AVLNode<T>::AVLNode(T data) : m_data(data), m_right(nullptr), m_left(nullptr)
{

}


/*****************************************
* Purpose: This function resets a AVLNode<T> object back to its default state
*
* Precondition:
*
* Postcondition:
*		Modifies AVLNode<T> to default values
*****************************************/
template<typename T>
void AVLNode<T>::Purge()
{
	m_data = T();
	m_right = nullptr;
	m_left = nullptr;
}


/*****************************************
* Purpose: This function returns m_data by value
*
* Precondition:
*
* Postcondition:
*		returns m_data by value
*****************************************/
template<typename T>
T AVLNode<T>::getData() const
{
	return m_data;
}


