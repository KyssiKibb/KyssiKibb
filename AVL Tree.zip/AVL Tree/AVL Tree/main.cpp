/*****************************************
* Author: Kobi Conn
* Filename: main.cpp
* Date Created: 4/22/22
* Modifications:
*****************************************/
/*****************************************
*
* Lab/Assignment: AVL Tree
*
* Overview:
*	This program will test all of the functions in the templated
*	AVLTree class with both primitive and complex types.
*
* Input:
*	There is no inputs
*
* Output:
*	Displays whether the test for any of the functions passes or fails in console.
*	Output will be in the form : X function test passed/failed
*****************************************/
#define _CRTDBG_MAP_ALLOC
typedef bool(*FunctionPointer)();  // Define a funtion pointer type
#include <string>
using std::string;
#include <iostream>
using std::cout;
using std::cin;
#include <crtdbg.h>
#include "avltree.h"
#include "list.h"
// Strings to test
const char* NAMES[] = { "Kyle", "Brit", "seth", "Alex", "Josh", "Kian",
"Kate", "Terry", "Ann", "Elaine", "Stephanie", "Wanda", "Oscar",
"Oliver", "Tobey","Axel" };
const int NUM_NAMES = 16;
// Test function declaration
bool test_default_ctor();
bool test_copy_ctor();
bool test_move_ctor();
bool test_copy_assignment();
bool test_move_assignment();
bool test_insert();
bool test_delete();
bool test_purge();
bool test_height();
bool test_inorder();
bool test_preorder();
bool test_postorder();
bool test_breadthfirst();

//
// Complex tests
bool test_default_ctor_complex();
bool test_copy_ctor_complex();
bool test_move_ctor_complex();
bool test_copy_assignment_complex();
bool test_move_assignment_complex();
bool test_insert_complex();
bool test_delete_complex();
bool test_purge_complex();
bool test_height_complex();
bool test_inorder_complex();
bool test_preorder_complex();
bool test_postorder_complex();
bool test_breadthfirst_complex();

void Display(int data);
void Display(string data);


FunctionPointer test_functions[] =
{
	test_default_ctor
	,test_copy_ctor
	,test_move_ctor
	,test_copy_assignment
	,test_move_assignment
	,test_insert
	,test_delete
	,test_purge
	,test_height
	,test_inorder
	,test_preorder
	,test_postorder
	,test_breadthfirst
	,test_default_ctor_complex
	,test_copy_ctor_complex
	,test_move_ctor_complex
	,test_copy_assignment_complex
	,test_move_assignment_complex
	,test_insert_complex
	,test_delete_complex
	,test_purge_complex
	,test_height_complex
	,test_inorder_complex
	,test_preorder_complex
	,test_postorder_complex
	,test_breadthfirst_complex
};

List<int> primitivelist;
List<string> complexlist;

int main()
{
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
	// Run the test functions
	for (FunctionPointer func : test_functions)
	{
		if (func())
		{
			cout << "passed\n";
		}
		else
		{
			cout << "***** failed *****\n";
		}
	}
	cout << "\nPress Any Key to Exit";

	cin.get();
	return 0;
}

bool test_default_ctor()
{
	bool passed = true;
	AVLTree<int> test;
	if (test.GetRoot() != nullptr)
	{
		passed = false;
	}
	cout << "default ctor test ";
	return passed;
}
bool test_copy_ctor()
{
	bool passed = true;
	AVLTree<int> test;
	test.Insert(5);
	test.Insert(2);
	test.Insert(4);
	test.Insert(3);
	test.Insert(1);
	test.Insert(8);
	test.Insert(6);
	AVLTree<int> test2(test);
	if (test.GetRoot()->getData() != 4)
	{
		passed = false;
	}
	if (test2.GetRoot()->getData() != 4)
	{
		passed = false;
	}
	cout << "copy ctor test ";
	return passed;
}
bool test_move_ctor()
{
	bool passed = false;
	AVLTree<int> test;
	test.Insert(5);
	AVLTree<int> test2(std::move(test));
	try
	{
		test.Delete(5);
	}
	catch (Exception a)
	{
		passed = true;
	}
	test2.Delete(5);
	if (test2.GetRoot() != nullptr)
	{
		passed = false;
	}
	cout << "move ctor test ";
	return passed;
}
bool test_copy_assignment()
{
	bool passed = true;
	AVLTree<int> test;
	test.Insert(5);
	test.Insert(2);
	test.Insert(4);
	test.Insert(3);
	test.Insert(1);
	test.Insert(8);
	test.Insert(6);
	AVLTree<int> test2;
	test2 = test;
	test2 = test2; //self assignment not ruin data
	if (test2.GetRoot()->getData() != 4)
	{
		passed = false;
	}
	cout << "copy assignment test ";
	return passed;
}
bool test_move_assignment()
{
	bool passed = true;
	AVLTree<int> test;
	test.Insert(5);
	AVLTree<int> test2;
	test2 = std::move(test);
	test2 = std::move(test2); //self assignment not ruin data
	if (test.GetRoot() != nullptr)
	{
		passed = false;
	}
	if (test2.GetRoot()->getData() != 5)
	{
		passed = false;
	}
	cout << "move assignment test ";
	return passed;
}
bool test_insert()
{
	bool passed = true;
	AVLTree<int> test;
	test.Insert(3);
	test.Insert(10);
	test.Insert(15); //rr
	test.Insert(5);
	test.Insert(17);
	test.Insert(16); //rl
	test.Insert(8);
	test.Insert(2);
	test.Insert(0);
	test.Insert(1); //lr
	test.Insert(14);
	test.Insert(13); //ll
	test.Insert(4);
	test.Insert(6);
	test.Insert(7);
	test.Insert(9);
	test.Insert(11);
	test.Insert(12);

	if (test.GetRoot()->getData() != 10)
	{
		passed = false;
	}
	primitivelist.Purge();
	test.inOrder(Display);
	for (int i = 0; i < 18; ++i)
	{
		if (primitivelist.Pop() != i)
		{
			passed = false;
		}
	}
	cout << "insert test ";
	return passed;
}
bool test_delete()
{
	bool passed = false;
	AVLTree<int> test;
	try
	{
		test.Delete(5);
	}
	catch (Exception a)
	{
		passed = true;
	}
	test.Insert(10);
	test.Insert(0);
	test.Insert(20);
	test.Insert(30);
	test.Delete(0);//rr
	test.Insert(0);
	test.Delete(30);//ll
	test.Insert(15);
	test.Insert(25);
	test.Insert(1);
	test.Insert(17);
	test.Delete(1);//lr
	test.Insert(23);
	test.Delete(0);//rl
	test.Delete(23);
	test.Delete(17);
	test.Insert(0);
	test.Insert(5);
	for (int i = 0; i < 6; ++i)
	{
		test.Delete(5*i);
	}
	if (test.GetRoot() != nullptr)
	{
		passed = false;
	}
	cout << "delete test ";
	return passed;
}
bool test_height()
{
	bool passed = true;
	AVLTree<int> test;
	test.Insert(5);
	if (test.Height() != 0)
	{
		passed = false;
	}
	test.Insert(2);
	test.Insert(4);
	test.Insert(3);
	test.Insert(1);
	test.Insert(8);
	test.Insert(6);
	test.Insert(0);
	if (test.Height() != 3)
	{
		passed = false;
	}
	cout << "height test ";
	return passed;
}

bool test_purge()
{
	bool passed = true;
	AVLTree<int> test;
	for (int i = 0; i < 5; ++i)
	{
		test.Insert(i);
	}
	test.Purge();
	if (test.GetRoot() != nullptr)
	{
		passed = false;
	}
	cout << "purge test ";
	return passed;
}
bool test_inorder()
{
	bool passed = true;
	AVLTree<int> test;
	test.Insert(2);
	test.Insert(4);
	test.Insert(3);
	test.Insert(1);
	test.Insert(8);
	test.Insert(6);
	test.Insert(0);
	primitivelist.Purge();
	test.inOrder(Display); // should be 0,1,2,3,4,6,8
	if (primitivelist.Pop() != 0)
	{
		passed = false;
	}
	if (primitivelist.Pop() != 1)
	{
		passed = false;
	}
	if (primitivelist.Pop() != 2)
	{
		passed = false;
	}
	if (primitivelist.Pop() != 3)
	{
		passed = false;
	}
	if (primitivelist.Pop() != 4)
	{
		passed = false;
	}
	if (primitivelist.Pop() != 6)
	{
		passed = false;
	}
	if (primitivelist.Pop() != 8)
	{
		passed = false;
	}
	primitivelist.Purge(); // just in case
	cout << "inorder traversal test ";
	return passed;
}
bool test_preorder()
{
	bool passed = true;
	AVLTree<int> test;
	test.Insert(2);
	test.Insert(4);
	test.Insert(3);
	test.Insert(1);
	test.Insert(8);
	test.Insert(6);
	test.Insert(0);
	test.PreOrder(Display); // should be 2,1,0,4,3,8,6
	if (primitivelist.Pop() != 3)
	{
		passed = false;
	}
	if (primitivelist.Pop() != 1)
	{
		passed = false;
	}
	if (primitivelist.Pop() != 0)
	{
		passed = false;
	}
	if (primitivelist.Pop() != 2)
	{
		passed = false;
	}
	if (primitivelist.Pop() != 6)
	{
		passed = false;
	}
	if (primitivelist.Pop() != 4)
	{
		passed = false;
	}
	if (primitivelist.Pop() != 8)
	{
		passed = false;
	}
	primitivelist.Purge();
	cout << "preorder traversal test ";
	return passed;
}
bool test_postorder()
{
	bool passed = true;
	AVLTree<int> test;
	test.Insert(2);
	test.Insert(4);
	test.Insert(3);
	test.Insert(1);
	test.Insert(8);
	test.Insert(6);
	test.Insert(0);
	primitivelist.Purge();
	test.PostOrder(Display); // should be 0,1,3,6,8,4,2
	if (primitivelist.Pop() != 0)
	{
		passed = false;
	}
	if (primitivelist.Pop() != 2)
	{
		passed = false;
	}
	if (primitivelist.Pop() != 1)
	{
		passed = false;
	}
	if (primitivelist.Pop() != 4)
	{
		passed = false;
	}
	if (primitivelist.Pop() != 8)
	{
		passed = false;
	}
	if (primitivelist.Pop() != 6)
	{
		passed = false;
	}
	if (primitivelist.Pop() != 3)
	{
		passed = false;
	}
	cout << "postorder traversal test ";
	return passed;
}
bool test_breadthfirst()
{
	bool passed = true;
	AVLTree<int> test;
	test.Insert(2);
	test.Insert(4);
	test.Insert(3);
	test.Insert(1);
	test.Insert(8);
	test.Insert(6);
	test.Insert(0);
	primitivelist.Purge();
	test.BreadthFirst(Display);
	if (primitivelist.Pop() != 3)
	{
		passed = false;
	}
	if (primitivelist.Pop() != 1)
	{
		passed = false;
	}
	if (primitivelist.Pop() != 6)
	{
		passed = false;
	}
	if (primitivelist.Pop() != 0)
	{
		passed = false;
	}
	if (primitivelist.Pop() != 2)
	{
		passed = false;
	}
	if (primitivelist.Pop() != 4)
	{
		passed = false;
	}
	if (primitivelist.Pop() != 8)
	{
		passed = false;
	}
	cout << "breadthfirst traversal test ";
	return passed;
}
bool test_default_ctor_complex()
{
	bool passed = true;
	AVLTree<string> test;
	if (test.GetRoot() != nullptr)
	{
		passed = false;
	}
	cout << "default ctor test complex ";
	return passed;
}
bool test_copy_ctor_complex()
{
	bool passed = true;
	AVLTree<string> test;
	for (int i = 0; i < 6; ++i)
	{
		test.Insert(NAMES[i]);
	}
	AVLTree<string> test2(test);
	if (test.GetRoot()->getData() != NAMES[4])
	{
		passed = false;
	}
	if (test2.GetRoot()->getData() != NAMES[4])
	{
		passed = false;
	}
	cout << "copy ctor test complex ";
	return passed;
}
bool test_move_ctor_complex()
{
	bool passed = false;
	AVLTree<string> test;
	test.Insert(NAMES[0]);
	AVLTree<string> test2(std::move(test));
	try
	{
		test.Delete(NAMES[0]);
	}
	catch (Exception a)
	{
		passed = true;
	}
	test2.Delete(NAMES[0]);
	if (test2.GetRoot() != nullptr)
	{
		passed = false;
	}
	cout << "move ctor test complex ";
	return passed;
}
bool test_copy_assignment_complex()
{
	bool passed = true;
	AVLTree<string> test;
	for (int i = 0; i < 6; ++i)
	{
		test.Insert(NAMES[i]);
	}
	AVLTree<string> test2;
	test2 = test;
	test2 = test2; //self assignment not ruin data
	if (test2.GetRoot()->getData() != NAMES[4])
	{
		passed = false;
	}
	cout << "copy assignment test complex ";
	return passed;
}
bool test_move_assignment_complex()
{
	bool passed = true;
	AVLTree<string> test;
	test.Insert(NAMES[0]);
	AVLTree<string> test2;
	test2 = std::move(test);
	test2 = std::move(test2); //self assignment not ruin data
	if (test.GetRoot() != nullptr)
	{
		passed = false;
	}
	if (test2.GetRoot()->getData() != NAMES[0])
	{
		passed = false;
	}
	cout << "move assignment test complex ";
	return passed;
}
bool test_insert_complex()
{
	bool passed = true;
	AVLTree<string> test;
	test.Insert(NAMES[0]);
	test.Insert(NAMES[1]);
	test.Insert(NAMES[3]);//ll
	test.Insert(NAMES[4]);
	test.Insert(NAMES[5]);//rl
	test.Insert(NAMES[2]);//rr
	test.Insert(NAMES[8]);
	test.Insert(NAMES[15]);//lr
	complexlist.Purge();
	test.inOrder(Display);
	if (complexlist.Pop() != NAMES[3])
	{
		passed = false;
	}
	if (complexlist.Pop() != NAMES[8])
	{
		passed = false;
	}
	if (complexlist.Pop() != NAMES[15])
	{
		passed = false;
	}
	if (complexlist.Pop() != NAMES[1])
	{
		passed = false;
	}
	if (complexlist.Pop() != NAMES[4])
	{
		passed = false;
	}
	if (complexlist.Pop() != NAMES[5])
	{
		passed = false;
	}
	if (complexlist.Pop() != NAMES[0])
	{
		passed = false;
	}
	if (complexlist.Pop() != NAMES[2])
	{
		passed = false;
	}
	cout << "insert test complex ";
	return passed;
}
bool test_delete_complex()
{
	bool passed = false;
	AVLTree<string> test;
	try
	{
		test.Delete(NAMES[0]);
	}
	catch (Exception a)
	{
		passed = true;
	}
	for (int i = 0; i < 4; ++i)
	{
		test.Insert(NAMES[i]);
	}
	test.Delete(NAMES[2]);//ll
	test.Insert(NAMES[2]);
	test.Delete(NAMES[3]);//rr
	test.Insert(NAMES[4]);
	test.Delete(NAMES[2]);//lr
	test.Insert(NAMES[5]);
	test.Delete(NAMES[1]);//rl
	test.Delete(NAMES[5]);
	test.Delete(NAMES[0]);
	test.Delete(NAMES[4]);
	if (test.GetRoot() != nullptr)
	{
		passed = false;
	}
	cout << "delete test complex ";
	return passed;
}
bool test_height_complex()
{
	bool passed = true;
	AVLTree<string> test;
	test.Insert(NAMES[0]);
	if (test.Height() != 0)
	{
		passed = false;
	}
	for (int i = 1; i < 6; ++i)
	{
		test.Insert(NAMES[i]);
	}
	if (test.Height() != 2)
	{
		passed = false;
	}
	cout << "height test complex ";
	return passed;
}
bool test_purge_complex()
{
	bool passed = true;
	AVLTree<string> test;
	for (int i = 0; i < 6; ++i)
	{
		test.Insert(NAMES[i]);
	}
	test.Purge();
	if (test.GetRoot() != nullptr)
	{
		passed = false;
	}
	cout << "purge test complex ";
	return passed;
}
bool test_inorder_complex()
{
	bool passed = true;
	AVLTree<string> test;
	for (int i = 0; i < 6; ++i)
	{
		test.Insert(NAMES[i]);
	}
	complexlist.Purge();
	test.inOrder(Display);
	if (complexlist.Pop() != NAMES[3])
	{
		passed = false;
	}
	if (complexlist.Pop() != NAMES[1])
	{
		passed = false;
	}
	if (complexlist.Pop() != NAMES[4])
	{
		passed = false;
	}
	if (complexlist.Pop() != NAMES[5])
	{
		passed = false;
	}
	if (complexlist.Pop() != NAMES[0])
	{
		passed = false;
	}
	if (complexlist.Pop() != NAMES[2])
	{
		passed = false;
	}
	cout << "inorder traversal test complex ";
	return passed;
}
bool test_preorder_complex()
{
	bool passed = true;
	AVLTree<string> test;
	for (int i = 0; i < 6; ++i)
	{
		test.Insert(NAMES[i]);
	}
	complexlist.Purge();
	test.PreOrder(Display);
	if (complexlist.Pop() != NAMES[4])
	{
		passed = false;
	}
	if (complexlist.Pop() != NAMES[1])
	{
		passed = false;
	}
	if (complexlist.Pop() != NAMES[3])
	{
		passed = false;
	}
	if (complexlist.Pop() != NAMES[0])
	{
		passed = false;
	}
	if (complexlist.Pop() != NAMES[5])
	{
		passed = false;
	}
	if (complexlist.Pop() != NAMES[2])
	{
		passed = false;
	}
	cout << "preorder traversal test complex ";
	return passed;
}
bool test_postorder_complex()
{
	bool passed = true;
	AVLTree<string> test;
	for (int i = 0; i < 6; ++i)
	{
		test.Insert(NAMES[i]);
	}
	complexlist.Purge();
	test.PostOrder(Display);
	if (complexlist.Pop() != NAMES[3])
	{
		passed = false;
	}
	if (complexlist.Pop() != NAMES[1])
	{
		passed = false;
	}
	if (complexlist.Pop() != NAMES[5])
	{
		passed = false;
	}
	if (complexlist.Pop() != NAMES[2])
	{
		passed = false;
	}
	if (complexlist.Pop() != NAMES[0])
	{
		passed = false;
	}
	if (complexlist.Pop() != NAMES[4])
	{
		passed = false;
	}
	cout << "postorder traversal test complex ";
	return passed;
}
bool test_breadthfirst_complex()
{
	bool passed = true;
	AVLTree<string> test;
	for (int i = 0; i < 6; ++i)
	{
		test.Insert(NAMES[i]);
	}
	complexlist.Purge();
	test.BreadthFirst(Display);
	if (complexlist.Pop() != NAMES[4])
	{
		passed = false;
	}
	if (complexlist.Pop() != NAMES[1])
	{
		passed = false;
	}
	if (complexlist.Pop() != NAMES[0])
	{
		passed = false;
	}
	if (complexlist.Pop() != NAMES[3])
	{
		passed = false;
	}
	if (complexlist.Pop() != NAMES[5])
	{
		passed = false;
	}
	if (complexlist.Pop() != NAMES[2])
	{
		passed = false;
	}
	cout << "breadthfirst traversal test complex ";
	return passed;
}
void Display(int data)
{
	//cout << data << endl;
	primitivelist.Prepend(data);
}
void Display(string data)
{
	//cout << data << endl;
	complexlist.Prepend(data);
}
