#pragma once
/*****************************************
* Author: Kobi Conn
* Filename: exception.h
* Date Created: 4/1/22
* Modifications:
*****************************************/

#include<iostream>
using std::ostream;

/*****************************************
* Class: Exception
*
* Purpose: This class holds pointers to Node<T> objects that contain any type of data that we want. automatically resizes itself and manipulates data
*
* Manager functions:
*		Exception ( )
*			The default for m_msg is nullptr
*		Exception (const char * msg)
*			instantiates Exception where m_msg gets set to a copy of msg
*		~Exception ( )
*			Deletes all allocated memory in the Exception<T> and resets m_msg to nullptr
*		Exception (const Exception<T> & copy)
*			Creates a copy of a Exception<T> object by passing in a const ref version of another Exception<T>.
*			copies m_msg through a deep copy
*		Exception (Exception<T> && copy)
*			Takes m_msg from copy
*			sets copies' m_msg to nullptr to sever ties and prevent deleting same address.
*		operator = (const Exception<T> & rhs)
*			Copies m_msg from rhs Exception<T> object into current object. checks for self assignment.
*			If not self assignment: deletes old data and copies data from rhs. always returns *this for function chaining
*		operator = (Exception<T> && rhs)
*			Takes m_msg from Exception<T> object and places it into current object. checks for self assignment.
*			If not self assignment: deletes old data, takes data from rhs, and sets rhs to default state. always returns *this for function chaining.
*
* Methods:
*		getMessage ( )
*			Returns const char* of m_msg
*		setMessage (const char* msg)
*			Changes m_msg to msg by deleting old data and creating a copy of msg
*		ostream& operator << (ostream& stream, const Exception& except)
*			Allows use of << operator to output m_msg. returns ref for function chaining
*****************************************/
class Exception
{
public:
	Exception();
	~Exception();
	Exception(const char* msg);
	Exception(const Exception& copy);
	Exception(Exception&& copy) noexcept;
	Exception& operator =(const Exception& rhs);
	Exception& operator =(Exception&& rhs) noexcept;
	const char* getMessage() const;
	void setMessage(const char* msg);
private:
	char* m_msg;
};

ostream& operator<<(ostream& stream, const Exception& except);
