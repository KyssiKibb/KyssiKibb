#pragma once
/*****************************************
* Author: Kobi Conn
* Filename: queue.h
* Date Created: 4/12/22
* Modifications:
*****************************************/

#include "list.h"
#include "exception.h"

/*****************************************
* Class: Queue
*
* Purpose: This class holds an array of data in a first in first out (FIFO) architecture. it is templated so that it can hold any piece of data
*
* Manager functions:
*		Queue ( )
*			Default values for Queue are: m_queue(), m_size(0)
*		~Queue ( )
*		Queue (const Queue<T> & copy)
*		operator = (const Queue<T> & rhs)
*		Queue (Queue<T> && copy)
*			constructs an Queue, moving the data from copy. it then resets copy to its default state
*		operator = (Queue<T> && rhs)
*			if it is not self reference, it deallocates memory that m_array is pointing at and takes the data from rhs. resets rhs to default state
*
* Methods:
*		Push(T data)
*			Put input data into the top of the stack as a new node
*		Pop()
*			Take the data from the last element in stack and return it by value. delete last node in stack
*		Peek()
*			if list is empty, throws error. else, returns data in top element of the array
*		getsize()
*			Returns num of elements currently in stack
*		isEmpty()
*			Returns true if m_stack has no data entered, else returns true
*****************************************/
template<typename T>
class Queue
{
public:
	Queue();
	~Queue();
	Queue(const Queue<T>& copy);
	Queue(Queue<T>&& copy) noexcept;
	Queue<T>& operator =(const Queue<T>& rhs);
	Queue<T>& operator =(Queue<T>&& rhs) noexcept;

	void Enqueue(T data);
	T Dequeue();
	T Peek() const;
	int getSize() const;
	bool isEmpty() const;

private:
	List<T> m_queue;
	int m_size;
};



/*****************************************
* Purpose:	Instantiate a default Queue<T> object
* Precondition:
* Postcondition:
*		m_queue()
*		m_size = 0
*****************************************/
template<typename T>
Queue<T>::Queue() : m_queue(), m_size(0)
{

}


/*****************************************
* Purpose:	Reset current object to default state
* Precondition:
* Postcondition:
*			m_queue gets reset to nullptr
*			size = 0
*****************************************/
template<typename T>
Queue<T>::~Queue()
{
	m_queue.Purge();
	m_size = 0;
}


/*****************************************
* Purpose: Copy data from copy into current Queue<T> object
*
* Precondition:
*
* Postcondition:
*		both the current object and input parameter hold copies of the same data
*****************************************/
template<typename T>
Queue<T>::Queue(const Queue<T>& copy) : m_queue(copy.m_queue), m_size(copy.m_size)
{

}


/*****************************************
* Purpose: Move the data from copy into the current Queue<T> through instantiation
*
* Precondition:
*
* Postcondition:
*		all data in copy is moved into current object
*		copy gets reset to default state
*****************************************/
template<typename T>
Queue<T>::Queue(Queue<T>&& copy) noexcept : m_queue(std::move(copy.m_queue)), m_size(std::move(copy.m_size))
{
	copy.m_queue.Purge();
	copy.m_size = 0;
}


/*****************************************
* Purpose: copy all data in one Queue object into the current one through assignment
*
* Precondition:
* Postcondition:
*		if self assignment, does nothing
*		parameters copied from rhs
*		return *this for function chaining
*****************************************/
template<typename T>
Queue<T>& Queue<T>::operator =(const Queue<T>& rhs)
{
	if (this != &rhs)
	{
		m_queue = rhs.m_queue;
		m_size = rhs.m_size;
	}
	return *this;
}


/*****************************************
* Purpose: move the contents of one array into another
*
* Precondition:
* Postcondition:
*		if self assingment, does nothing
*		parameters copied from rhs
*		resets rhs' data to default state
*		Returns *this for function chaining
*****************************************/
template<typename T>
Queue<T>& Queue<T>::operator =(Queue<T>&& rhs) noexcept
{
	if (this != &rhs)
	{
		m_queue = rhs.m_queue;
		m_size = rhs.m_size;
		rhs.m_size = 0;
		rhs.m_queue.Purge();
	}
	return *this;
}


/*****************************************
* Purpose:	Adds data to Queue<T> array at top of queue
* Precondition:
* Postcondition:
*		else increment m_size and set data to top of queue
*****************************************/
template<typename T>
void Queue<T>::Enqueue(T data)
{
	m_queue.Prepend(data);
	m_size++;
}


/*****************************************
* Purpose:	remove data from top of queue and return it
* Precondition:
* Postcondition:
*		if there is nothing to pop, throws underflow exception
*		else decrement m_size and return old top's data
*****************************************/
template<typename T>
T Queue<T>::Dequeue()
{
	if (m_queue.isEmpty())
	{
		throw Exception("Cannot Dequeue an empty queue");
	}
	m_size--;
	return m_queue.Pop();
}


/*****************************************
* Purpose:	shows data at the top of the queue, but doesn't remove it
* Precondition:
* Postcondition:
*		if queue is empty, throws exception
*		return data at current top of queue
*****************************************/
template<typename T>
T Queue<T>::Peek() const
{
	if (m_queue.isEmpty())
	{
		throw Exception("Cannot peek at empty queue");
	}
	return m_queue.Last();
}


/*****************************************
* Purpose:	show amount of elements currently filled with data in queue
* Precondition:
* Postcondition:
*		returns m_size
*****************************************/
template<typename T>
int Queue<T>::getSize() const
{
	return m_size;
}


/*****************************************
* Purpose:	tells whether the queue is currently empty or not
* Precondition:
* Postcondition:
*		returns true if the queue is empty, and false if there is data in queue
*****************************************/
template<typename T>
bool Queue<T>::isEmpty() const
{
	bool empty = false;
	if (m_size == 0)
	{
		empty = true;
	}
	return empty;
}

