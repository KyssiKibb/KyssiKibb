#pragma once
/*****************************************
* Author: Kobi Conn
* Filename: stack.h
* Date Created: 4/10/22
* Modifications:
*****************************************/

#include "array.h"

/*****************************************
* Class: Stack
*
* Purpose: This class holds an array of data in a first in last out (FILO) architecture. it is templated so that it can hold any piece of data
*
* Manager functions:
*		Stack ( )
*			Default values for Stack are: m_stack(), num_elements(0)
*		~Stack ( )
*		Stack (const Stack<T> & copy)
*		operator = (const Stack<T> & rhs)
*		Stack (Stack<T> && copy)
*			constructs an Stack, moving the data from copy. it then resets copy to its default state
*		operator = (Stack<T> && rhs)
*			if it is not self reference, it deallocates memory that m_array is pointing at and takes the data from rhs. resets rhs to default state
*
* Methods:
*		Push(T data)
*			Put input data into the top of the stack as a new node
*		Pop()
*			Take the data from the last element in stack and return it by value. delete last node in stack
*		Peek()
*			if list is empty, throws error. else, returns data in top element of the array
*		getNumElements()
*			Returns num of elements currently in stack
*		getSize()
*			Returns num of elements allocated to stack
*		setSize()
*			changes num of elements of stack to new value. keeps old data integrity if size permits
*		isEmpty()
*			Returns true if m_stack has no data entered, else returns true
*		isFull()
*			Returns true if m_stack is fully populated with data, else returns false
*****************************************/
template<typename T>
class Stack
{
public:
	Stack();
	~Stack();
	Stack(const Stack<T> &copy);
	Stack(Stack<T> &&copy) noexcept;
	Stack<T>& operator =(const Stack<T> &rhs);
	Stack<T>& operator =(Stack<T> &&rhs) noexcept;
	Stack(int size);

	void Push(T data);
	T Pop();
	T Peek() const;
	int getNumElements() const;
	int getSize() const;
	void setSize(int new_size);
	bool isEmpty() const;
	bool isFull() const;



private:
	Array<T> m_stack;
	int m_size;
	int m_top;
};


/*****************************************
* Purpose:	Instantiate a default Stack<T> object
* Precondition:
* Postcondition:
*****************************************/
template<typename T>
Stack<T>::Stack() : m_stack(), m_size(0), m_top(-1)
{

}


/*****************************************
* Purpose:	Reset current object to default state
* Precondition:
* Postcondition:
*			m_stack gets reset to nullptr
*			size = 0
*			top = -1
*****************************************/
template<typename T>
Stack<T>::~Stack()
{
	m_stack.SetLength(0);
	m_size = 0;
	m_top = -1;
}


/*****************************************
* Purpose: Copy data from copy into current Stack<T> object
*
* Precondition:
*
* Postcondition:
*		both the current object and copy hold copies of the same data
*****************************************/
template<typename T>
Stack<T>::Stack(const Stack<T>& copy) : m_stack(copy.m_stack), m_size(copy.m_size), m_top(copy.m_top)
{

}


/*****************************************
* Purpose: Move the data from copy into the current Stack<T> through instantiation
*
* Precondition:
*
* Postcondition:
*		all data in copy is moved into current object
*		copy gets reset to default state
*****************************************/
template<typename T>
Stack<T>::Stack(Stack<T>&& copy) noexcept: m_stack(std::move(copy.m_stack)), m_size(std::move(copy.m_size)), m_top(std::move(copy.m_top))
{
	copy.m_stack.SetLength(0);
	copy.m_size = 0;
	copy.m_top = -1;
}


/*****************************************
* Purpose: copy all data in one Stack object into the current one through assignment
*
* Precondition:
* Postcondition:
*		if self assignment, does nothing
*		parameters copied from rhs
*		return *this for function chaining
*****************************************/
template<typename T>
Stack<T>& Stack<T>::operator =(const Stack<T>& rhs)
{
	if (this != &rhs)
	{
		m_stack = rhs.m_stack;
		m_size = rhs.m_size;
		m_top = rhs.m_top;
	}
	return *this;
}


/*****************************************
* Purpose: move the contents of one array into another
*
* Precondition:
* Postcondition:
*		if self assingment, does nothing
*		parameters copied from rhs
*		resets rhs' data to default state
*		Returns *this for function chaining
*****************************************/
template<typename T>
Stack<T>& Stack<T>::operator =(Stack<T>&& rhs) noexcept
{
	if (this != &rhs)
	{
		m_stack = rhs.m_stack;
		m_size = rhs.m_size;
		m_top = rhs.m_top;
		rhs.m_top = -1;
		rhs.m_size = 0;
		rhs.m_stack.SetLength(0);
	}
	return *this;
}


/*****************************************
* Purpose:	Instantiate a Stack<T> object with size already set
* Precondition:
* Postcondition:
*		if size is negative, throws exception
*		sets size of array, top of array, and allocates based on size
*****************************************/
template<typename T>
Stack<T>::Stack(int size) : m_stack(), m_size(size), m_top(-1)
{
	if (size < 0)
	{
		throw Exception("Cannot have negative stack size");
	}
	else
	{
		m_stack.SetLength(size);
	}
}


/*****************************************
* Purpose:	Adds data to Stack<T> array at top of stack
* Precondition:
* Postcondition:
*		if stack is full, throw overflow exception
*		else move m_top up and set data to top of current stack
*****************************************/
template<typename T>
void Stack<T>::Push(T data)
{
	m_top++;
	if (m_top >= m_size)
	{
		m_top--;
		throw Exception("Overflow Error");
	}
	else
	{
		m_stack[m_top] = data;
	}
}


/*****************************************
* Purpose:	remove data from top of stack and return it
* Precondition:
* Postcondition:
*		if there is nothing to pop, throws underflow exception
*		else decrement top and return old top's data
*****************************************/
template<typename T>
T Stack<T>::Pop()
{
	if (m_top == -1)
	{
		throw Exception("Underflow Error");
	}
	else
	{
		m_top--;
	}
	return m_stack[m_top + 1];
}


/*****************************************
* Purpose:	shows data at the top of the stack, but doesn't remove it
* Precondition:
* Postcondition:
*		if stack is empty, throw exception
*		return data at current top of stack
*****************************************/
template<typename T>
T Stack<T>::Peek() const
{
	if (m_top == -1)
	{
		throw Exception("Peeking at empty stack");
	}
	return m_stack[m_top];
}


/*****************************************
* Purpose:	show amount of elements currently filled with data in stack
* Precondition:
* Postcondition:
*		returns top + 1 because top is 0 based
*****************************************/
template<typename T>
int Stack<T>::getNumElements() const
{
	return (m_top+1); //+1 because top is 0 based
}


/*****************************************
* Purpose:	show maximum size of current stack
* Precondition:
* Postcondition:
*		returns m_size
*****************************************/
template<typename T>
int Stack<T>::getSize() const
{
	return m_size;
}


/*****************************************
* Purpose:	change size to what is input, keeping data integrity
* Precondition:
* Postcondition:
*		if input size is negative, throws exception
*		changes size of array depending on input, keeping old data integrity
*****************************************/
template<typename T>
void Stack<T>::setSize(int size)
{
	if (size >= 0)
	{
		m_stack.SetLength(size);
		if(size < m_size) //if array gets smaller
		{
			if (m_top >= size) //if current top of stack is above new size, resize to top of new stack
			{
				m_top = size - 1;
			}
		}
		m_size = size;
	}
	else
	{
		throw Exception("Cannot have stack of negative size");
	}
}


/*****************************************
* Purpose:	tells whether the stack is currently empty or not
* Precondition:
* Postcondition:
*		returns true if the stack is empty, and false if there is data in stack
*****************************************/
template<typename T>
bool Stack<T>::isEmpty() const
{
	bool empty = true;
	if (m_top > -1)
	{
		empty = false;
	}
	return empty;
}


/*****************************************
* Purpose:	tells whether the stack is currently full or not
* Precondition:
* Postcondition:
*		returns true if the stack is full, and false if the stack is empty
*****************************************/
template<typename T>
bool Stack<T>::isFull() const
{
	bool full = false;
	if (m_top == (m_size - 1)) //because it's zero based we subtract 1
	{
		full = true;
	}
		return full;
}