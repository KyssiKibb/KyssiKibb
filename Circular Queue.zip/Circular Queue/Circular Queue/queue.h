#pragma once
/*****************************************
* Author: Kobi Conn
* Filename: queue.h
* Date Created: 4/12/22
* Modifications:
*****************************************/

#include "array.h"
#include "exception.h"

/*****************************************
* Class: Queue
*
* Purpose: This class holds an array of data in a first in first out (FIFO) architecture. it is templated so that it can hold any piece of data
*
* Manager functions:
*		Queue ( )
*			Default values for Queue are: m_queue(), m_size(0), m_head(-1), m_tail(-1)
*		Queue (int size)
*			instantiates queue with size of array set to input
*		~Queue ( )
*		Queue (const Queue<T> & copy)
*		operator = (const Queue<T> & rhs)
*		Queue (Queue<T> && copy)
*			constructs an Queue, moving the data from copy. it then resets copy to its default state
*		operator = (Queue<T> && rhs)
*			if it is not self reference, it deallocates memory that m_array is pointing at and takes the data from rhs. resets rhs to default state
*
* Methods:
*		Enqueue(T data)
*			Put input data into the top of the stack as a new node
*		Dequeue()
*			Take the data from the last element in stack and return it by value. delete last node in stack
*		Peek()
*			if list is empty, throws error. else, returns data in top element of the array
*		getSize()
*			Returns num of elements currently in stack
*		setSize(int size)
*			changes size of circular queue while maintaining data currently in queue. throws exception for negative size
*		isEmpty()
*			Returns true if queue is empty, else returns true
*		ifFull ()
*			returns true if queue is full, and false if not
*****************************************/
template<typename T>
class Queue
{
public:
	Queue();
	~Queue();
	Queue(const Queue<T>& copy);
	Queue(Queue<T>&& copy) noexcept;
	Queue<T>& operator =(const Queue<T>& rhs);
	Queue<T>& operator =(Queue<T>&& rhs) noexcept;
	Queue(int size);

	void Enqueue(T data);
	T Dequeue();
	T Peek() const;
	int getSize() const;
	void setSize(int size);
	bool isEmpty() const;
	bool isFull() const;

private:
	Array<T> m_queue;
	int m_size;
	int m_head;
	int m_tail;
};



/*****************************************
* Purpose:	Instantiate a default Queue<T> object
* Precondition:
* Postcondition:
*		m_queue()
*		m_size = 0
*		m_head = -1
*		m_tail = -1
*****************************************/
template<typename T>
Queue<T>::Queue() : m_queue(), m_size(0), m_head(-1), m_tail(-1)
{

}


/*****************************************
* Purpose:	Reset current object to default state
* Precondition:
* Postcondition:
*			m_queue gets reset to 0 length
*			size = 0
*			m_head = -1
*			m_tail -1
*****************************************/
template<typename T>
Queue<T>::~Queue()
{
	m_queue.SetLength(0);
	m_size = 0;
	m_head = -1;
	m_tail = -1;
}


/*****************************************
* Purpose: Copy data from copy into current Queue<T> object
*
* Precondition:
*
* Postcondition:
*		both the current object and input parameter hold copies of the same data
*****************************************/
template<typename T>
Queue<T>::Queue(const Queue<T>& copy) : m_queue(copy.m_queue), m_size(copy.m_size), m_head(copy.m_head), m_tail(copy.m_tail)
{

}


/*****************************************
* Purpose: Move the data from copy into the current Queue<T> through instantiation
*
* Precondition:
*
* Postcondition:
*		all data in copy is moved into current object
*		copy gets reset to default state
*****************************************/
template<typename T>
Queue<T>::Queue(Queue<T>&& copy) noexcept : m_queue(std::move(copy.m_queue)), m_size(std::move(copy.m_size)), m_head(std::move(m_head)), m_tail(std::move(m_tail)) 
{
	copy.m_queue.SetLength(0);
	copy.m_size = 0;
	copy.m_head = -1;
	copy.m_tail = -1;
}


/*****************************************
* Purpose: copy all data in one Queue object into the current one through assignment
*
* Precondition:
* Postcondition:
*		if self assignment, does nothing
*		parameters copied from rhs
*		return *this for function chaining
*****************************************/
template<typename T>
Queue<T>& Queue<T>::operator =(const Queue<T>& rhs)
{
	if (this != &rhs)
	{
		m_queue = rhs.m_queue;
		m_size = rhs.m_size;
		m_head = rhs.m_head;
		m_tail = rhs.m_tail;
	}
	return *this;
}


/*****************************************
* Purpose: move the contents of one array into another
*
* Precondition:
* Postcondition:
*		if self assingment, does nothing
*		parameters copied from rhs
*		resets rhs' data to default state
*		Returns *this for function chaining
*****************************************/
template<typename T>
Queue<T>& Queue<T>::operator =(Queue<T>&& rhs) noexcept
{
	if (this != &rhs)
	{
		m_queue = std::move(rhs.m_queue);
		m_size = rhs.m_size;
		m_head = rhs.m_head;
		m_tail = rhs.m_tail;
		rhs.m_size = 0;
		rhs.m_queue.SetLength(0);
		rhs.m_head = -1;
		rhs.m_tail = -1;
	}
	return *this;
}


/*****************************************
* Purpose:	Instantiate a Queue<T> object with size set to input
* Precondition:
* Postcondition:
*		m_queue()
*		m_size = size
*		m_head(-1)
*		m_tail(-1)
*		sets queue length in body if size is not negative
*****************************************/
template<typename T>
Queue<T>::Queue(int size) : m_queue(), m_size(size), m_head(-1), m_tail(-1)
{
	if (size < 0)
	{
		throw Exception("Cannot set negative length");
	}
	m_queue.SetLength(size);
}


/*****************************************
* Purpose:	Adds data to Queue<T> array at top of queue
* Precondition:
* Postcondition:
*		if queue is empty, sets head and tail to 0 then inputs data into queue
*		else increment m_tail and set data to queue[m_tail]
*		if queue is full, throws exception
*		if size is 0, throws exception
*		if size is 0, throws exception
*****************************************/
template<typename T>
void Queue<T>::Enqueue(T data)
{
	if (m_size > 0)
	{
		if (m_head == -1)
		{
			m_head = 0;
			m_tail = 0;
			m_queue[0] = data;
		}
		else
		{
			if (!isFull())
			{
				m_tail = (m_tail + 1) % m_size;
				m_queue[m_tail] = data;
			}
			else
			{
				throw Exception("Cannot Enqueue full queue");
			}
		}
	}
	else
	{
		throw Exception("Cannot Enqueue on queue with 0 size");
	}
}


/*****************************************
* Purpose:	remove data from top of queue and return it
* Precondition:
* Postcondition:
*		if there is nothing to pop, throws underflow exception
*		else increments m_head and returns old head data
*****************************************/
template<typename T>
T Queue<T>::Dequeue()
{
	int m_previous = m_head;
	if (isEmpty())
	{
		throw Exception("Cannot Dequeue an empty queue");
	}
	else
	{
		if (m_head == m_tail) // there is only 1 item in queue
		{
			m_head = -1;
			m_tail = -1;
		}
		else
		{
			m_head = (m_head + 1) % m_size;
		}

	}
	return m_queue[m_previous];
}


/*****************************************
* Purpose:	shows data at the top of the queue, but doesn't remove it
* Precondition:
* Postcondition:
*		if queue is empty, throws exception
*		return data at current top of queue
*****************************************/
template<typename T>
T Queue<T>::Peek() const
{
	if (isEmpty())
	{
		throw Exception("Cannot peek at empty queue");
	}
	return m_queue[m_tail];
}


/*****************************************
* Purpose:	show amount of elements currently filled with data in queue
* Precondition:
* Postcondition:
*		returns m_size
*****************************************/
template<typename T>
int Queue<T>::getSize() const
{
	return m_size;
}


/*****************************************
* Purpose:	show amount of elements currently filled with data in queue
* Precondition:
* Postcondition:
*		size of array is changed to new size, keeping data integrity
*		if input size is negative, throws exception
*****************************************/
template<typename T>
void Queue<T>::setSize(int size)
{
	if (size < 0)
	{
		throw Exception("Cannot set size to negative length");
	}
	else if (size == 0)
	{
		m_queue.SetLength(size);
		m_size = 0;
		m_head = -1;
		m_tail = -1;
	}
	else
	{
		if (m_head == -1)
		{
			m_queue.SetLength(size);
			m_size = size;
		}
		else //there is data in the queue
		{
			Array<T> temp(size);
			int copy_data = 0; //amount of data in queue
			if (m_head <= m_tail) // if tail hasn't looped around behind head
			{
				copy_data = m_tail - m_head +1; //+1 because answer will be 0 based
			}
			else // if tail has looped behind head
			{
				copy_data = (m_size - m_head) + (m_tail + 1); //+1 because tail would be 0 based answer
			}
			int i = 0;
			for (; i < copy_data && i < size; ++i)
			{
				temp[i] = m_queue[(m_head + i) % m_size];
			}

			m_tail = i - 1; // there is never a case where i = 0 so this will always work. the -1 is because the for loop will bring i to 1 past the data we copied
			m_head = 0;
			m_size = size;
			m_queue = temp;
		}
	}
}


/*****************************************
* Purpose:	tells whether the queue is currently empty or not
* Precondition:
* Postcondition:
*		returns true if the queue is empty, and false if there is data in queue
*****************************************/
template<typename T>
bool Queue<T>::isEmpty() const
{
	bool empty = false;
	if (m_head == -1)
	{
		empty = true;
	}
	return empty;
}


/*****************************************
* Purpose:	tells whether the queue is currently full or not
* Precondition:
* Postcondition:
*		returns true if the queue is full, and false if not
*****************************************/
template<typename T>
bool Queue<T>::isFull() const
{
	bool full = false;
	if (((m_tail + 1) % m_size) == m_head)
	{
		full = true;
	}
	return full;
}