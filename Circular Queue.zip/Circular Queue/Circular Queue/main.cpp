/*****************************************
* Author: Kobi Conn
* Filename: main.cpp
* Date Created: 4/12/22
* Modifications:
*****************************************/
/*****************************************
*
* Lab/Assignment: Circular Queue
*
* Overview:
*	This program will test all of the functions in the templated
*	Queue class with both primitive and complex types.
*
* Input:
*	There is no inputs
*
* Output:
*	Displays whether the test for any of the functions passes or fails in console.
*	Output will be in the form : X function test passed/failed
*****************************************/
#define _CRTDBG_MAP_ALLOC
typedef bool(*FunctionPointer)();  // Define a funtion pointer type
#include <string>
using std::string;
#include <iostream>
using std::cout;
using std::cin;
#include <crtdbg.h>
#include "queue.h"
// Strings to test
const char* NAMES[] = { "Kyle", "Brit", "seth", "Alex", "Josh", "Kian",
"Kate", "Terry", "Ann", "Elaine", "Stephanie", "Wanda", "Oscar",
"Oliver", "Tobey" };
const int NUM_NAMES = 15;
// Test function declaration
bool test_default_ctor();
bool test_1arg_ctor();
bool test_copy_ctor();
bool test_move_ctor();
bool test_copy_assignment();
bool test_move_assignment();
bool test_enqueue();
bool test_dequeue();
bool test_peek();
bool test_getsize();
bool test_setsize();
bool test_isempty();
bool test_isfull();
//
// Complex tests
bool test_default_ctor_complex();
bool test_1arg_ctor_complex();
bool test_copy_ctor_complex();
bool test_move_ctor_complex();
bool test_copy_assignment_complex();
bool test_move_assignment_complex();
bool test_enqueue_complex();
bool test_dequeue_complex();
bool test_peek_complex();
bool test_getsize_complex();
bool test_setsize_complex();
bool test_isempty_complex();
bool test_isfull_complex();

FunctionPointer test_functions[] =
{
	test_default_ctor
	,test_1arg_ctor
	,test_copy_ctor
	,test_move_ctor
	,test_copy_assignment
	,test_move_assignment
	,test_enqueue
	,test_dequeue
	,test_peek
	,test_getsize
	,test_setsize
	,test_isempty
	,test_isfull
	,test_default_ctor_complex
	,test_1arg_ctor_complex
	,test_copy_ctor_complex
	,test_move_ctor_complex
	,test_copy_assignment_complex
	,test_move_assignment_complex
	,test_enqueue_complex
	,test_dequeue_complex
	,test_peek_complex
	,test_getsize_complex
	,test_setsize_complex
	,test_isempty_complex
	,test_isfull_complex
};

int main()
{
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
	// Run the test functions
	for (FunctionPointer func : test_functions)
	{
		if (func())
		{
			cout << "passed\n";
		}
		else
		{
			cout << "***** failed *****\n";
		}
	}
	cout << "\nPress Any Key to Exit";


	cin.get();
	return 0;
}
bool test_default_ctor()
{
	bool passed = true;
	Queue<int> test;
	if (!test.isEmpty()) //if it isn't empty
	{
		passed = false;
	}
	if(test.getSize() != 0)
	{
		passed = false;
	}
	cout << "default ctor test ";
	return passed;
}
bool test_1arg_ctor()
{
	bool passed = true;
	Queue<int> test(5);
	if (test.getSize() != 5)
	{
		passed = false;
	}
	cout << "1arg ctor test ";
	return passed;
}
bool test_copy_ctor()
{
	bool passed = true;
	Queue<int> test(5);
	test.Enqueue(10);
	Queue<int> test2(test);
	if (test.Dequeue() != 10)
	{
		passed = false;
	}
	if (test2.Dequeue() != 10)
	{
		passed = false;
	}
	if (test2.getSize() != 5)
	{
		passed = false;
	}
	cout << "copy ctor test ";
	return passed;
}
bool test_move_ctor()
{
	bool passed = false;
	Queue<int> test(5);
	test.Enqueue(10);
	Queue<int> test2(std::move(test));
	try
	{
		test.Dequeue();
	}
	catch (Exception a)
	{
		passed = true;
	}
	if (test2.Dequeue() != 10)
	{
		passed = false;
	}
	if (test2.getSize() != 5)
	{
		passed = false;
	}
	cout << "move ctor test ";
	return passed;
}
bool test_copy_assignment()
{
	bool passed = true;
	Queue<int> test(5);
	test.Enqueue(10);
	Queue<int> test2;
	test2 = test;
	test2 = test2; //self assignment not ruin data
	if (test2.Dequeue() != 10)
	{
		passed = false;
	}
	if (test2.getSize() != 5)
	{
		passed = false;
	}
	cout << "copy assignment test ";
	return passed;
}
bool test_move_assignment()
{
	bool passed = true;
	Queue<int> test(5);
	test.Enqueue(10);
	Queue<int> test2;
	test2 = std::move(test);
	test2 = std::move(test2); //self assignment not ruin data
	try
	{
		test.Dequeue();
	}
	catch (Exception a)
	{
		passed = true;
	}
	if (test2.Dequeue() != 10)
	{
		passed = false;
	}
	cout << "move assignment test ";
	return passed;
}
bool test_enqueue()
{
	bool passed = false;
	Queue<int> test(5);
	for (int i = 0; i < 5; ++i)
	{
		test.Enqueue(i);
	}
	try
	{
		test.Enqueue(5);
	}
	catch (Exception a)
	{
		passed = true;
	}
	if (test.Dequeue() != 0)
	{ 
		passed = false;
	}
	test.Enqueue(5);
	cout << "enqueue test ";
	return passed;
}
bool test_dequeue()
{
	bool passed = false;
	Queue<int> test(5);
	try
	{
		test.Dequeue();
	}
	catch (Exception a)
	{
		passed = true;
	}
	for (int i = 0; i < 5; ++i)
	{
		test.Enqueue(i);
	}
	for (int i = 0; i < 4; ++i)
	{
		if (test.Dequeue() != i)
		{
			passed = false;
		}
	}
	for (int i = 0; i < 15; ++i)
	{
		test.Enqueue(i);
		test.Dequeue();
	}
	test.Dequeue();
	if (!test.isEmpty())
	{
		passed = false;
	}
	cout << "dequeue test ";
	return passed;
}
bool test_peek()
{
	bool passed = false;
	Queue<int> test(5);
	try
	{
		test.Peek();
	}
	catch (Exception a)
	{
		passed = true;
	}
	test.Enqueue(5);
	if (test.Peek() != 5)
	{
		passed = false;
	}
	cout << "peek test ";
	return passed;
}
bool test_getsize()
{
	bool passed = true;
	Queue<int> test(5);
	if (test.getSize() != 5)
	{
		passed = false;
	}
	cout << "getsize test ";
	return passed;
}
bool test_setsize()
{
	bool passed = false;
	Queue<int> test(5);
	try
	{
		test.setSize(-5);
	}
	catch (Exception a)
	{
		passed = true;
	}
	test.setSize(7); // queue is empty
	if (test.getSize() != 7)
	{
		passed = false;
	}
	for (int i = 0; i < 7; ++i)
	{
		test.Enqueue(i);
	}
	test.setSize(5); // changing size when m_head <= m_tail and there's data
	for (int i = 0; i < 2; ++i)
	{
		if (test.Dequeue() != i)
		{
			passed = false;
		}
		test.Enqueue(10 + i);
	}
	test.setSize(10); // changing size when m_head > m_tail and there's data
	if (test.Dequeue() != 2)
	{
		passed = false;
	}
	cout << "setsize test ";
	return passed;
}
bool test_isempty()
{
	bool passed = true;
	Queue<int> test(5);
	if (test.isEmpty() != true)
	{
		passed = false;
	}
	test.Enqueue(5);
	if (test.isEmpty() != false)
	{
		passed = false;
	}
	cout << "isempty test ";
	return passed;
}
bool test_isfull()
{
	bool passed = true;
	Queue<int> test(1);
	if (test.isFull() != false)
	{
		passed = false;
	}
	test.Enqueue(5);
	if (test.isFull() != true)
	{
		passed = false;
	}
	cout << "isfull test ";
	return passed;
}

bool test_default_ctor_complex()
{
	bool passed = true;
	Queue<string> test;
	if (!test.isEmpty()) //if it isn't empty
	{
		passed = false;
	}
	if (test.getSize() != 0)
	{
		passed = false;
	}
	cout << "default ctor test complex ";
	return passed;
}
bool test_1arg_ctor_complex()
{
	bool passed = true;
	Queue<string> test(5);
	if (test.getSize() != 5)
	{
		passed = false;
	}
	cout << "1arg ctor test complex ";
	return passed;
}
bool test_copy_ctor_complex()
{
	bool passed = true;
	Queue<string> test(5);
	test.Enqueue(NAMES[0]);
	Queue<string> test2(test);
	if (test.Dequeue() != NAMES[0])
	{
		passed = false;
	}
	if (test2.Dequeue() != NAMES[0])
	{
		passed = false;
	}
	if (test2.getSize() != 5)
	{
		passed = false;
	}
	cout << "copy ctor test complex ";
	return passed;
}
bool test_move_ctor_complex()
{
	bool passed = false;
	Queue<string> test(5);
	test.Enqueue(NAMES[0]);
	Queue<string> test2(std::move(test));
	try
	{
		test.Dequeue();
	}
	catch (Exception a)
	{
		passed = true;
	}
	if (test2.Dequeue() != NAMES[0])
	{
		passed = false;
	}
	if (test2.getSize() != 5)
	{
		passed = false;
	}
	cout << "move ctor test complex ";
	return passed;
}
bool test_copy_assignment_complex()
{
	bool passed = true;
	Queue<string> test(5);
	test.Enqueue(NAMES[0]);
	Queue<string> test2;
	test2 = test;
	test2 = test2; //self assignment not ruin data
	if (test2.Dequeue() != NAMES[0])
	{
		passed = false;
	}
	if (test2.getSize() != 5)
	{
		passed = false;
	}
	cout << "copy assignment test complex ";
	return passed;
}
bool test_move_assignment_complex()
{
	bool passed = true;
	Queue<string> test(5);
	test.Enqueue(NAMES[0]);
	Queue<string> test2;
	test2 = std::move(test);
	test2 = std::move(test2); //self assignment not ruin data
	try
	{
		test.Dequeue();
	}
	catch (Exception a)
	{
		passed = true;
	}
	if (test2.Dequeue() != NAMES[0])
	{
		passed = false;
	}
	cout << "move assignment test complex ";
	return passed;
}
bool test_enqueue_complex()
{
	bool passed = false;
	Queue<string> test(5);
	for (int i = 0; i < 5; ++i)
	{
		test.Enqueue(NAMES[i]);
	}
	try
	{
		test.Enqueue(NAMES[5]);
	}
	catch (Exception a)
	{
		passed = true;
	}
	if (test.Dequeue() != NAMES[0])
	{
		passed = false;
	}
	test.Enqueue(NAMES[5]);
	cout << "enqueue test complex ";
	return passed;
}
bool test_dequeue_complex()
{
	bool passed = false;
	Queue<string> test(5);
	try
	{
		test.Dequeue();
	}
	catch (Exception a)
	{
		passed = true;
	}
	for (int i = 0; i < 5; ++i)
	{
		test.Enqueue(NAMES[i]);
	}
	for (int i = 0; i < 4; ++i)
	{
		if (test.Dequeue() != NAMES[i])
		{
			passed = false;
		}
	}
	for (int i = 0; i < 15; ++i)
	{
		test.Enqueue(NAMES[i % 5]);
		test.Dequeue();
	}
	test.Dequeue();
	if (!test.isEmpty())
	{
		passed = false;
	}
	cout << "dequeue test complex ";
	return passed;
}
bool test_peek_complex()
{
	bool passed = false;
	Queue<string> test(5);
	try
	{
		test.Peek();
	}
	catch (Exception a)
	{
		passed = true;
	}
	test.Enqueue(NAMES[0]);
	if (test.Peek() != NAMES[0])
	{
		passed = false;
	}
	cout << "peek test complex ";
	return passed;
}
bool test_getsize_complex()
{
	bool passed = true;
	Queue<string> test(5);
	if (test.getSize() != 5)
	{
		passed = false;
	}
	cout << "getsize test complex ";
	return passed;
}
bool test_setsize_complex()
{
	bool passed = false;
	Queue<string> test(5);
	try
	{
		test.setSize(-5);
	}
	catch (Exception a)
	{
		passed = true;
	}
	test.setSize(7); // queue is empty
	if (test.getSize() != 7)
	{
		passed = false;
	}
	for (int i = 0; i < 7; ++i)
	{
		test.Enqueue(NAMES[i]);
	}
	test.setSize(5); // changing size when m_head <= m_tail and there's data
	for (int i = 0; i < 2; ++i)
	{
		if (test.Dequeue() != NAMES[i])
		{
			passed = false;
		}
		test.Enqueue(NAMES[10 + i]);
	}
	test.setSize(10); // changing size when m_head > m_tail and there's data
	if (test.Dequeue() != NAMES[2])
	{
		passed = false;
	}
	cout << "setsize test complex ";
	return passed;
}
bool test_isempty_complex()
{
	bool passed = true;
	Queue<string> test(5);
	if (test.isEmpty() != true)
	{
		passed = false;
	}
	test.Enqueue(NAMES[0]);
	if (test.isEmpty() != false)
	{
		passed = false;
	}
	cout << "isempty test complex ";
	return passed;
}
bool test_isfull_complex()
{
	bool passed = true;
	Queue<string> test(1);
	if (test.isFull() != false)
	{
		passed = false;
	}
	test.Enqueue(NAMES[0]);
	if (test.isFull() != true)
	{
		passed = false;
	}
	cout << "isfull test complex ";
	return passed;
}