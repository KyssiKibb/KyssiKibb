#pragma once
/*****************************************
* Author: Kobi Conn
* Filename: bstree.h
* Date Created: 4/18/22
* Modifications:	4/20/22 added a lot of documentation
*****************************************/

#include "bsnode.h"
#include "exception.h"
#include "queue.h"

/*****************************************
* Class: BSTree
*
* Purpose: This class holds an array of data in a first in first out (FIFO) architecture. it is templated so that it can hold any piece of data
*
* Manager functions:
*		BSTree ( )
*			Default values for BSTree are: m_queue(), m_size(0)
*		~BSTree ( )
*		BSTree (const BSTree<T> & copy)
*		operator = (const BSTree<T> & rhs)
*		BSTree (BSTree<T> && copy)
*			constructs an BSTree, moving the data from copy. it then resets copy to its default state
*		operator = (BSTree<T> && rhs)
*			if it is not self reference, it deallocates memory that m_array is pointing at and takes the data from rhs. resets rhs to default state
*
* Methods:
*		Insert(T data)
*			Put Node with input data into BSTree
*		Delete(T data)
*			Delete node with data based on input
*		Purge ( )
*			Resets current object to default state
*		Height ( )
*			Returns height of BSTree (longest connection from the root to leaf)
*		inOrder (void(*visit)(T data))
*			Displays Tree in ascending value based on display function given
*		PreOrder (void(*visit)(T data))
*			Displays value in node before moving left and right based on display function given
*		PostOrder (void(*visit)(T data))
*			Displays value in node after traversing left and right using the Display function given
*		BreadthFirst (void(*visit)(T data))
*			Displays values in each level of tree before moving to the next level down
*		GetRoot ( ) 
*			Returns m_root (for testing purposes only)
*****************************************/
template<typename T>
class BSTree
{
public:
	BSTree();
	~BSTree();
	BSTree(const BSTree<T>& copy);
	BSTree(BSTree<T>&& copy) noexcept;
	BSTree<T> & operator =(const BSTree<T>& rhs);
	BSTree<T> & operator =(BSTree<T>&& rhs) noexcept;

	void Insert(T data);
	void Delete(T data);
	void Purge();
	int Height() const;
	void inOrder(void(*visit)(T data)) const;
	void PreOrder(void(*visit)(T data)) const;
	void PostOrder(void(*visit)(T data)) const;
	void BreadthFirst(void(*visit)(T data)) const;

	BSNode<T>* GetRoot(); // for testing purposes only

private:
	void inOrder(BSNode<T>* root, void(*visit)(T data)) const;
	void PreOrder(BSNode<T>* root, void(*visit)(T data)) const;
	void PostOrder(BSNode<T>* root, void(*visit)(T data)) const;
	void CopyRecursive(BSNode<T>*& root, BSNode<T>* copy);
	void DeleteFromTree(BSNode<T>*& root);
	void Purge(BSNode<T>*& root);
	int Height(BSNode<T>* root) const;

	BSNode<T>* m_root;
};


/*****************************************
* Purpose: Instantiates a default version of BSTree<T>
*
* Precondition:
*
* Postcondition:
*		Default value for m_root is nullptr
*****************************************/
template<typename T>
BSTree<T>::BSTree() : m_root(nullptr)
{

}


/*****************************************
* Purpose: Resets current object to default state
*
* Precondition:
*
* Postcondition:
*		Deallocates all data pointed to by m_root and m_root's nodes
*		resets m_root to nullptr
*****************************************/
template<typename T>
BSTree<T>::~BSTree()
{
	Purge();
}


/*****************************************
* Purpose: Instantiates BSTree<T> by copying data from input
*
* Precondition:
*
* Postcondition:
*		Copy of data from input is in current object
*****************************************/
template<typename T>
BSTree<T>::BSTree(const BSTree<T>& copy) : m_root(nullptr)
{
	if (nullptr != copy.m_root)
	{
		CopyRecursive(m_root, copy.m_root);
	}
}


/*****************************************
* Purpose: Instantiates BSTree<T> by moving data from input
*
* Precondition:
*
* Postcondition:
*		current object holds what copy was pointing at
*		copy gets set to nullptr to sever tie to data
*****************************************/
template<typename T>
BSTree<T>::BSTree(BSTree<T>&& copy) noexcept : m_root(copy.m_root)
{
	copy.m_root = nullptr;
}


/*****************************************
* Purpose: copies data from input
*
* Precondition:
*
* Postcondition:
*		if self assignment, does nothing
*		Copy of data from input is in current object
*		returns *this for function chaining
*****************************************/
template<typename T>
BSTree<T>& BSTree<T>::operator =(const BSTree<T>& rhs)
{
	if (this != &rhs)
	{
		CopyRecursive(m_root, rhs.m_root);
	}
	return *this;
}


/*****************************************
* Purpose: moves data from input
*
* Precondition:
*
* Postcondition:
*		if self assignment, does nothing
*		data from input is in current object
*		input gets set to nullptr to sever ties to data
*		returns *this for function chaining
*****************************************/
template<typename T>
BSTree<T>& BSTree<T>::operator =(BSTree<T>&& rhs) noexcept
{
	if (this != &rhs)
	{
		m_root = rhs.m_root;
		rhs.m_root = nullptr;
	}
	return *this;
}


/*****************************************
* Purpose: Inserts node filled with input data into current object
*
* Precondition:
*
* Postcondition:
*		if root is empty, allocates root with new node containing data
*		else, traverse to the correct location to place the node
*		allocate new node with data and insert it into correct spot on tree
*****************************************/
template<typename T>
void BSTree<T>::Insert(T data)
{
	if (nullptr == m_root)
	{
		m_root = new BSNode<T>(data);
	}
	else
	{
		BSNode<T>* travel = m_root;
		while (nullptr != travel) // could have a || end == true and end loop with bool instead of setting travel to nullptr manually
		{
			if (data < travel->m_data)
			{
				if (nullptr == travel->m_left)
				{
					travel->m_left = new BSNode<T>(data);
					travel = nullptr;
				}
				else
				{
					travel = travel->m_left;
				}
			}
			else
			{
				if (nullptr == travel->m_right)
				{
					travel->m_right = new BSNode<T>(data);
					travel = nullptr;
				}
				else
				{
					travel = travel->m_right;
				}
			}
		}
	}
}


/*****************************************
* Purpose: Inserts node filled with input data into current object
*
* Precondition:
*
* Postcondition:
*		if root is empty, throws exception
*		else, traverse to the correct node to delete
*		if correct node isn't found, throw exception
*		else, delete node based on if it has 0 children, 1 child, or 2 children
*****************************************/
template<typename T>
void BSTree<T>::Delete(T data)
{
	if (nullptr == m_root)
	{
		throw Exception("Cannot delete from empty Binary Search Tree");
	}
	else
	{
		BSNode<T>* previous = m_root;
		BSNode<T>* current = m_root;
		bool found = false;
		while (nullptr != current && false == found)
		{
			if (data == current->m_data)
			{
				found = true;
			}
			else
			{
				previous = current;
				if (data < current->m_data)
				{
					current = current->m_left;
				}
				else
				{
					current = current->m_right;
				}
			}
		}
		if (nullptr == current)
		{
			throw Exception("Data not found in Binary Search Tree");
		}
		else
		{
			if (current == m_root)
			{
				DeleteFromTree(m_root);
			}
			else if (previous->m_data > data)
			{
				DeleteFromTree(previous->m_left);
			}
			else
			{
				DeleteFromTree(previous->m_right);
			}
		}
	}
}


/*****************************************
* Purpose: Resets current object to default state (hides pointer from consumer)
*
* Precondition:
*
* Postcondition:
*		Deallocates all data pointed to by m_root and m_root's nodes
*		resets m_root to nullptr
*****************************************/
template<typename T>
void BSTree<T>::Purge()
{
	Purge(m_root);
}


/*****************************************
* Purpose: Let consumer know height of tree
*
* Precondition:
*
* Postcondition:
*		returns height of tree (there is a -1 because height is 0 based)
*****************************************/
template<typename T>
int BSTree<T>::Height() const
{
	return (Height(m_root)-1);
}


/*****************************************
* Purpose: show data in order from least to greatest
*
* Precondition:
*
* Postcondition:
*		Displays values of tree in order based on consumer Display function
*****************************************/
template<typename T>
void BSTree<T>::inOrder(void(*visit)(T data)) const
{
	inOrder(m_root, visit);
}


/*****************************************
* Purpose: show data in pre order fashion
*
* Precondition:
*
* Postcondition:
*		Displays values of tree in pre-order based on consumer Display function
*****************************************/
template<typename T>
void BSTree<T>::PreOrder(void(*visit)(T data)) const
{
	PreOrder(m_root, visit);
}


/*****************************************
* Purpose: show data in post order fashion
*
* Precondition:
*
* Postcondition:
*		Displays values of tree in post-order based on consumer Display function
*****************************************/
template<typename T>
void BSTree<T>::PostOrder(void(*visit)(T data)) const
{
	PostOrder(m_root, visit);
}


/*****************************************
* Purpose: show data in breadth order fashion
*
* Precondition:
*
* Postcondition:
*		Displays values of tree in breadth-order based on consumer Display function
*****************************************/
template<typename T>
void BSTree<T>::BreadthFirst(void(*visit)(T data)) const
{
	if(nullptr != m_root)
	{
		Queue<BSNode<T>*> queue;
		BSNode<T>* temp = nullptr;
		queue.Enqueue(m_root);
		while (!queue.isEmpty())
		{
			temp = queue.Dequeue();
			if (nullptr != temp->m_left)
			{
				queue.Enqueue(temp->m_left);
			}
			if (nullptr != temp->m_right)
			{
				queue.Enqueue(temp->m_right);
			}
			visit(temp->m_data);
		}
	}
}


/*****************************************
* Purpose: show data in order from least to greatest
*
* Precondition:
*		Consumer uses inOrder() function (this is to hide the pointer values from consumer)
* Postcondition:
*		Displays values of tree in order based on consumer Display function
*****************************************/
template<typename T>
void BSTree<T>::inOrder(BSNode<T>* root, void(*visit)(T data)) const
{
	if (nullptr != root)
	{
		inOrder(root->m_left, visit);
		visit(root->m_data);
		inOrder(root->m_right, visit);
	}
}


/*****************************************
* Purpose: show data in pre order fashion
*
* Precondition:
*		Consumer uses PreOrder() function (this is to hide the pointer values from consumer)
* Postcondition:
*		Displays values of tree in pre-order based on consumer Display function
*****************************************/
template<typename T>
void BSTree<T>::PreOrder(BSNode<T>* root, void(*visit)(T data)) const
{
	if (nullptr != root)
	{
		visit(root->m_data);
		PreOrder(root->m_left, visit);
		PreOrder(root->m_right, visit);
	}
}


/*****************************************
* Purpose: show data in post order fashion
*
* Precondition:
*		Consumer uses PostOrder() function (this is to hide the pointer values from consumer)
* Postcondition:
*		Displays values of tree in post-order based on consumer Display function
*****************************************/
template<typename T>
void BSTree<T>::PostOrder(BSNode<T>* root, void(*visit)(T data)) const
{
	if (nullptr != root)
	{
		PostOrder(root->m_left, visit);
		PostOrder(root->m_right, visit);
		visit(root->m_data);
	}
}


/*****************************************
* Purpose: Recursively copy each node from copy into root
*
* Precondition:
*		Consumer uses copy ctor or copy assignment
* Postcondition:
*		recursively copies all nodes from copy, leaving 2 trees with copies of same data in same structure
*****************************************/
template<typename T>
void BSTree<T>::CopyRecursive(BSNode<T>*& root, BSNode<T>* copy)
{
	if (nullptr != copy)
	{
		root = new BSNode<T>(copy->m_data);
		CopyRecursive(root->m_left, copy->m_left);
		CopyRecursive(root->m_right, copy->m_right);
	}
	else
	{
		root = nullptr;
	}
}


/*****************************************
* Purpose: Delete node from tree, keeping data integrity
*
* Precondition:
*		Consumer uses Delete(T data) function (this is to hide the pointer values from consumer and allow it to happen anywhere on the tree)
* Postcondition:
*		if input is nullptr, throws exception
*		else if input has no children, set it to nullptr(leaf node)
*		else if input has 1 child, link tree above root to what root is pointing to
*		else go to the rightmost left node after root, and swap them
*		deallocates whatever is pointed to by current
*****************************************/
template<typename T>
void BSTree<T>::DeleteFromTree(BSNode<T>*& root)
{
	BSNode<T>* current = root;
	if (nullptr == root)
	{
		throw Exception("Cannot delete empty node"); // i don't get why we have to have this here (i also may have misread this in the assignment)
	}
	else if (nullptr == root->m_left && nullptr == root->m_right)
	{
		root = nullptr;
	}
	else if (nullptr == root->m_left && nullptr != root->m_right)
	{
		root = root->m_right;
	}
	else if (nullptr != root->m_left && nullptr == root->m_right)
	{
		root = root->m_left;
	}
	else
	{
		BSNode<T>* previous = nullptr;
		current = current->m_left;
		while (nullptr != current->m_right)
		{
			previous = current;
			current = current->m_right;
		}
		root->m_data = current->m_data;
		if (nullptr == previous)
		{
			root->m_left = current->m_left;
		}
		else
		{
			previous->m_right = current->m_left;
		}
	}
	delete current;
	current = nullptr;
}


/*****************************************
* Purpose: Resets current object to default state
*
* Precondition:
*		Consumer calls Purge() function (this is to hide the pointer values from consumer)
* Postcondition:
*		Deallocates all data pointed to by root and root's nodes
*		resets root to nullptr
*****************************************/
template<typename T>
void BSTree<T>::Purge(BSNode<T> *& root)
{
	if (nullptr != root)
	{
		Purge(root->m_left);
		Purge(root->m_right);
		delete root;
		root = nullptr;
	}
}


/*****************************************
* Purpose: used to determine the height of the tree recursively
*
* Precondition:
*		Consumer called Height() function (this is to hide the pointer values from consumer)
* Postcondition:
*		returns height longer side of the tree (longest one determines height)
*****************************************/
template<typename T>
int BSTree<T>::Height(BSNode<T> * root) const
{
	int temp = 0;
	if (nullptr != root)
	{
		temp++;
		int templeft = Height(root->m_left);
		int tempright = Height(root->m_left);
		if (templeft < tempright)
		{
			temp += tempright;
		}
		else
		{
			temp += templeft;
		}
	}
	return temp;
}


/*****************************************
* Purpose: Returns m_root to test data integrity
*
* Precondition:
*
* Postcondition:
*		returns m_root
*****************************************/
template<typename T>
BSNode<T>* BSTree<T>::GetRoot()
{
	return m_root;
}