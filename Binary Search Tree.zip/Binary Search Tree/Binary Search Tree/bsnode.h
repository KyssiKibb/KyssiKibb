#pragma once
/*****************************************
* Author: Kobi Conn
* Filename: bsnode.h
* Date Created: 4/18/22
* Modifications:	4/18/22 used node class for linked list as basis and changed naming conventions
*****************************************/

template<typename T> //forward declaration of List class (where in the class documentation do you put friends? that seems like a very important detail and it isn't shown in the example.
class BSTree;


/*****************************************
* Class: BSNode
*
* Purpose: This class created nodes that will store data for our Doubly Linked List class
*
* Manager functions:
*		BSNode ( )
*			The default for m_right and m_left is nullptr, and T gets their default constructor evoked
*		BSNode (T data)
*			m_right and m_left get defaulted to nullptr, and T gets initialized with the data that is passed into the constructor
*		~BSNode ( )
*			Resets values of node back to default state (does not deallocate any memory)
*		BSNode (const BSNode<T> & copy)
*			Created a copy of a BSNode object by passing in a const ref version of BSNode.
*			does not take data, but does do a shallow copy of pointers
*		BSNode (BSNode<T> && copy)
*			Takes data in BSNode object and moves it into new instantiation.
*			sets old values to defaults to sever ties and prevent deleting same address.
*		operator = (const BSNode<T> & rhs)
*			Copies all data from BSNode<T> object into current object. checks for self assignment.
*			If not self assignment: deletes old data and copies data from rhs. always returns *this for function chaining
*		operator = (BSNode<T> && rhs)
*			Takes all data from BSNode<T> object and places it into current object. checks for self assignment.
*			If not self assignment: deletes old data, takes data from rhs, and sets rhs to default state. always returns *this for function chaining.
*
* Methods:
*		Purge ( )
*			Resets BSNode<T> object to default state. m_right and m_left go to nullptr, and T gets set to its default state
*		getData ( )
*			Returns m_data by value (for testing purposes)
*****************************************/
template<typename T>
class BSNode
{
	friend class BSTree<T>; 
public:
	BSNode();
	~BSNode();
	BSNode(const BSNode<T>& copy);
	BSNode(BSNode<T>&& copy) noexcept;
	BSNode<T>& operator =(const BSNode<T>& rhs);
	BSNode<T>& operator =(BSNode<T>&& rhs) noexcept;

	BSNode(T data);
	void Purge();
	T getData() const;

private:
	T m_data;
	BSNode<T>* m_left;
	BSNode<T>* m_right;
};

/*****************************************
* Purpose: Instantiates a default version of BSNode<T>
*
* Precondition:
*
* Postcondition:
*		default constructs m_data
*		sets m_right and m_left to nullptr
*****************************************/
template<typename T>
BSNode<T>::BSNode() : m_data(), m_right(nullptr), m_left(nullptr)
{ }

/*****************************************
* Purpose: This function resets a BSNode<T> object back to its default state
*
* Precondition:
*
* Postcondition:
*		Resets BSNode<T> to default values
*****************************************/
template<typename T>
BSNode<T>::~BSNode()
{
	Purge();
}


/*****************************************
* Purpose: Creates a BSNode<T> object by copying another BSNode<T>
*
* Precondition:
*
* Postcondition:
*		instantiates BSNode<T> with copy of copies' data
*****************************************/
template<typename T>
BSNode<T>::BSNode(const BSNode<T>& copy) : m_data(copy.m_data), m_right(copy.m_right), m_left(copy.m_left)
{

}


/*****************************************
* Purpose: Creates a BSNode<T> object and moves data from other BSNode<T> object into it
*
* Precondition:
*
* Postcondition:
*		takes copies data and sets copies' data to default to sever ties to original data
*****************************************/
template<typename T>
BSNode<T>::BSNode(BSNode<T>&& copy) noexcept : m_data(std::move(copy.m_data)), m_right(copy.m_right), m_left(copy.m_left)
{
	copy.Purge();
}


/*****************************************
* Purpose: copies data from a BSNode<T> into current object
*
* Precondition:
*		Not self assignment
*
* Postcondition:
*		sets m_data to copy of rhs.m_data
*		Returns *this for function chaining
*****************************************/
template<typename T>
BSNode<T>& BSNode<T>::operator =(const BSNode<T>& rhs)
{
	if (this != &rhs)
	{
		m_data = rhs.m_data;
	}
	return *this;
}


/*****************************************
* Purpose: Moves data from BSNode<T> to current object
*
* Precondition:
*		Not self assignment
*
* Postcondition:
*		takes data from rhs and resets rhs to default state
*****************************************/
template<typename T>
BSNode<T>& BSNode<T>::operator =(BSNode<T>&& rhs) noexcept
{
	if (this != &rhs)
	{
		m_data = std::move(rhs.m_data);
		m_right = rhs.m_right;
		m_left = rhs.m_left;
		rhs.Purge();
	}
	return *this;
}



/*****************************************
* Purpose: This function instantiates a BSNode<T> object with m_data set to T data
*
* Precondition:
*
* Postcondition:
*		New BSNode<T> object with m_data set to T data
*****************************************/
template<typename T>
BSNode<T>::BSNode(T data) : m_data(data), m_right(nullptr), m_left(nullptr)
{

}


/*****************************************
* Purpose: This function resets a BSNode<T> object back to its default state
*
* Precondition:
*
* Postcondition:
*		Modifies BSNode<T> to default values
*****************************************/
template<typename T>
void BSNode<T>::Purge()
{
	m_data = T();
	m_right = nullptr;
	m_left = nullptr;
}


/*****************************************
* Purpose: This function returns m_data by value
*
* Precondition:
*
* Postcondition:
*		returns m_data by value
*****************************************/
template<typename T>
T BSNode<T>::getData() const
{
	return m_data;
}

