#pragma once
/*****************************************
* Author: Kobi Conn
* Filename: row.h
* Date Created: 4/4/22
* Modifications:
*****************************************/

template <typename T>
class Array2D;


/*****************************************
* Class: Row
* 
* Purpose: this class is used to allow the Array2D class to be able to use the double subscript operator(Array2D<T> [][]) and reach the right element in the array
* 
* Manager Functions:
*		Row(const Array2D<T>& array2d, int row)
*			Creates row object using the row passed in to the 1st subscript operator and the this object
*		Row(const Row<T>& copy)
*		operator =(const Row<T>& rhs)
*		~Row()
* Methods:
*		T& operator[](int column)const
*			uses the second subscript operator to select and return the proper element in the Array2D<T> (works on const objects)
*****************************************/
template <typename T>
class Row
{
public:
	~Row();
	Row(const Array2D<T>& array2D, int row);
	Row(const Row<T> & copy);
	Row<T>& operator =(const Row<T>& rhs) = delete;
	Row(Row<T>&& copy);
	Row() = delete;
	Row<T>& operator =(Row<T>&& rhs) = delete;


	T& operator[] (int column) const;
private:
	const Array2D<T>& m_array2D;
	int m_row;
};


/*****************************************
* Purpose: Constructs Row object using input parameters
* 
* Precondition:
* 
* Postcondition:
*		Instantiates Row object with data ready to use subscript operator on
*****************************************/
template<typename T>
Row<T>::Row(const Array2D<T>& array2D, int row) : m_array2D(array2D), m_row(row)
{ }
																					 

/*****************************************
* Purpose: reset Row object to default state
*
* Precondition:
*
* Postcondition:
*		because Row doesn't have a default state, it doesn't do anything.
*****************************************/
template<typename T>
Row<T>::~Row()
{
	m_row = 0;
}


/*****************************************
* Purpose: Create an object with parameters copied from input
* 
* Precondition:
*		
* Postcondition:
*		Object is instantiated with a copy of data in copy
*****************************************/
template<typename T>
Row<T>::Row(const Row<T>& copy) : m_array2D(copy.m_array2D), m_row(copy.m_row)
{}


/*****************************************
* Purpose: changes data in current object to data copied from rhs
*
* Precondition:
*
* Postcondition:
*		current object contains data that is copy of rhs' data
*****************************************/
template<typename T>
Row<T>::Row(Row<T>&& copy) : m_array2D(copy.m_array2D), m_row(copy.m_row)
{
	m_row = 0;
}


/*****************************************
* Purpose: allows Array2D<T> to have calls with 2 subscript operators (i.e. Array2D<T> [0][0]
*
* Precondition:
*
* Postcondition:
*		Instantiates Row object with data ready to use subscript operator on
*****************************************/
template<typename T>
T& Row<T>::operator[](int column) const
{
	return m_array2D.Select(m_row,column);
}