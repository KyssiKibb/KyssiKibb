#pragma once
/*****************************************
* Author: Kobi Conn
* Filename: array.h
* Date Created: 4/1/22
* Modifications: 4/4/22 changed subscript operator to be const, fixed logic on copy ctor and setlength method
*****************************************/

#include "exception.h"

/*****************************************
* Class: Array
*
* Purpose: This class holds an array of data in 1 contiguous block of memory. it is templated so that it can hold any piece of data
*
* Manager functions:
*		Array ( )
*			Default values for Array are: m_length = 0, m_start_index = 0, m_array = nullptr
*		Array (int length, int start_index = 0)
*			instantiates Array which can have initialized values of length and starting index. it will allocate based on length given
*		~Array ( )
*		Array (const Array<T> & copy)
*		operator = (const Array<T> & rhs)
*		Array (Array<T> && copy)
*			constructs an Array, moving the data from copy. it then resets copy to its default state
*		operator = (Array<T> && rhs)
*			if it is not self reference, it deallocates memory that m_array is pointing at and takes the data from rhs. resets rhs to default state
*
* Methods:
*		operator[] (int index)
*			Returns by ref the value at the (index-m_start_index) in m_array
*		GetStartIndex()
*			returns by value the value of m_start_index
*		SetStartIndex(int start_index)
*			sets value of m_start_index to whatever is passed in
*		GetLength()
*			returns by value the value of m_length (length of array)
*		SetLength(int length)
*			resizes array to new specified length. does not work if the new length is negative.
*			when resizing, copies old data in elements available, and gets rid of the rest if there isn't enough room.
*****************************************/
template<typename T>
class Array
{
public:
	Array();
	Array(int length, int start_index = 0);
	~Array();
	Array(const Array<T>& copy);
	Array(Array<T>&& copy) noexcept;
	Array<T>& operator =(const Array<T>& rhs);
	Array<T>& operator =(Array<T>&& rhs) noexcept;

	T& operator[](int index) const;
	int GetStartIndex();
	void SetStartIndex(int start_index);
	int GetLength();
	void SetLength(int length);


private:
	T* m_array;
	int m_start_index;
	int m_length;
};


/*****************************************
* Purpose: create an array in a default state
*
* Precondition:
*
* Postcondition:
*		Array is created with starting parameters m_array = nullptr, m_start_index = 0, and m_length = 0
*****************************************/
template<typename T>
Array<T>::Array() : m_array(nullptr), m_start_index(0), m_length(0)
{

}


/*****************************************
* Purpose: be able to create an array through initialization without needing to first make a default array and then change values
*
* Precondition:
*		Length given is not negative
* Postcondition:
*		Array is instantiated with length and start index initialized to what the consumer wants
*****************************************/
template<typename T>
Array<T>::Array(int length, int start_index) : m_array(nullptr), m_length(length), m_start_index(start_index)
{
	if (length < 0)
	{
		throw Exception("cannot create array of negative length");
	}
	m_array = new T[length];
}


/*****************************************
* Purpose: reset the array and get rid of any memory that we have allocated
*
* Precondition:
*
* Postcondition:
*		all memory in Array<T> is deallocated
*		current object is reset to default state
*****************************************/
template<typename T>
Array<T>::~Array()
{
	delete[] m_array;
	m_array = nullptr;
	m_length = 0;
	m_start_index = 0;
}


/*****************************************
* Purpose: Copy data from copy into current Array<T> object
*
* Precondition:
*
* Postcondition:
*		both the current object and copy hold copies of the same data
*****************************************/
template<typename T>
Array<T>::Array(const Array<T>& copy) : m_array(nullptr), m_length(copy.m_length), m_start_index(copy.m_start_index)
{
	if (m_length > 0)
	{
		m_array = new T[m_length];
		for (int i = 0; i < m_length; ++i)
		{
			m_array[i] = copy.m_array[i];
		}
	}
}


/*****************************************
* Purpose: Move the data from copy into the current array through instantiation
*
* Precondition:
*
* Postcondition:
*		all data in copy is moved into current object
*		copy gets reset to default state
*****************************************/
template<typename T>
Array<T>::Array(Array<T>&& copy) noexcept : m_array(copy.m_array), m_length(copy.m_length), m_start_index(copy.m_start_index)
{
	copy.m_array = nullptr;
	copy.m_length = 0;
	copy.m_start_index = 0;
}


/*****************************************
* Purpose: copy all data in one Array object into the current one through assignment
*
* Precondition:
*		Not self assignment
* Postcondition:
*		Deletes old data in m_array
*		allocates new memory to size of rhs' length
*		copy assigns all data in rhs' array to m_array
*		Returns *this for function chaining
*****************************************/
template<typename T>
Array<T>& Array<T>::operator =(const Array<T>& rhs)
{
	if (this != &rhs)
	{
		delete[] m_array;
		m_array = new T[rhs.m_length];
		m_length = rhs.m_length;
		m_start_index = rhs.m_start_index;
		for (int i = 0; i < rhs.m_length; ++i)
		{
			m_array[i] = rhs.m_array[i];
		}
	}
	return *this;
}


/*****************************************
* Purpose: move the contents of one array into another
*
* Precondition:
*		is not self assignment (same address)
* Postcondition:
*		deletes old data in m_array
*		sets all data to copies data
*		resets copies data to default state
*		Returns *this for function chaining
*****************************************/
template<typename T>
Array<T>& Array<T>::operator =(Array<T>&& rhs) noexcept
{
	if (this != &rhs)
	{
		delete[] m_array;
		m_array = rhs.m_array;
		m_length = rhs.m_length;
		m_start_index = rhs.m_start_index;
		rhs.m_array = nullptr;
		rhs.m_length = 0;
		rhs.m_start_index = 0;
	}
	return *this;
}



/*****************************************
* Purpose: allow random access to data stored in Array.
*
* Precondition:
*		index given is not negative
*		index given is not above bounds of array
* Postcondition:
*		returns by ref the data in the (index - m_start_index) element in the array
*****************************************/
template<typename T>
T& Array<T>::operator[](int index) const
{
	if (index < m_start_index || index >= (m_length + m_start_index))
	{
		throw Exception("index not in bounds of array");
	}

	return m_array[index - m_start_index];
}


/*****************************************
* Purpose: give consumer easy access to what their starting index is
*
* Precondition:
*
* Postcondition:
*		Returns current m_start_index
*****************************************/
template<typename T>
int Array<T>::GetStartIndex()
{
	return m_start_index;
}


/*****************************************
* Purpose: give consumer ability to manipulate their starting index
*
* Precondition:
*
* Postcondition:
*		sets m_start_index to whatever user inputs
*****************************************/
template<typename T>
void Array<T>::SetStartIndex(int start_index)
{
	m_start_index = start_index;
}


/*****************************************
* Purpose: easy access to how long the array is
*
* Precondition:
*
* Postcondition:
*		Returns Length of current array
*****************************************/
template<typename T>
int Array<T>::GetLength()
{
	return m_length;
}


/*****************************************
* Purpose: Resize array to given length and keep required data integrity
*
* Precondition:
*		Value of Length is not zero
*
* Postcondition:
*		Array will have length elements, and any data that was in the old array is copied up until the size of length or the size of the old array
*****************************************/
template<typename T>
void Array<T>::SetLength(int length)
{
	if (length < 0)
	{
		throw Exception("Cannot have array with negative length");
	}
	else if (length == 0)
	{
		delete[] m_array;
		m_array = nullptr;
		m_length = length;
	}
	else
	{
		T* temp = new T[length];
		for (int i = 0; i < length && i < m_length; ++i)
		{
			temp[i] = m_array[i];
		}
		delete[] m_array;
		m_array = temp;
		m_length = length;
	}
}

