#pragma once
/*****************************************
* Author: Kobi Conn
* Filename: array2d.h
* Date Created: 4/4/22
* Modifications:
*****************************************/

#include "array.h"
#include "row.h"

/*****************************************
* Class: Array2D
*
* Purpose: Creates a 2D Array that uses a 1D Array as a base. holds <T> data in a 2D format, meaning it has both rows and columns
*
* Manager Functions:
*		Array2D()
*			Creates a Array2D<T> object with default parameters of: m_rows = 0, m_columns = 0, m_array()
*		Array2D(int row, int column)
*			Creates appropriately sized array with input parameters (cannot be negative)
*		Array2D(const Array2D<T> & copy)
*		operator = (const Array & copy)
*		~Array()
* 
* Methods:
*		getRow() const
*			Returns the number of rows
*		getColumns() const
*			Returns the number of columns
*		setRows(int rows)
*			sets the amount of rows to whatever is input
*			Cannot be negative
*			Keeps data integrity
*		setColumns(int columns)
*			sets the amount of columns to whatever is input
*			Cannot be negative
*			Keeps data integrity
*		operator[] (int row) const
*			returns row object to allow use of 2 subscript operators
*		Select(int desired_row, int desired_column)
*			calculates which data element to return based on input
*****************************************/
template <typename T>
class Array2D
{
public:
	Array2D();
	Array2D(int row, int column);
	Array2D(const Array2D<T> & copy);
	Array2D& operator =(const Array2D<T> & rhs);
	~Array2D();
	Array2D(Array2D<T>&& copy);
	Array2D& operator = (Array2D<T> && rhs);



	int getRow()const;
	int getColumns()const;
	void setRows(int rows);
	void setColumns(int columns);
	Row<T> operator [](int row) const;
	T& Select(int desired_row, int desired_column) const;


private:
	Array<T> m_array;
	int m_rows;
	int m_columns;
};


/*****************************************
* Purpose: Constructs default Array2D object
*
* Precondition:
*
* Postcondition:
*		Instantiates Array2D object with default values:
*		m_columns(0)
*		m_rows(0)
*		m_array()
*****************************************/
template<typename T>
Array2D<T>::Array2D() : m_array(),m_rows(0), m_columns(0)
{

}

/*****************************************
* Purpose: Constructs Array2D object using input parameters
*
* Precondition:
*
* Postcondition:
*		if m_columns or m_rows is negative, throws exception
*		sets values for row and column
*		creates array1d based on row and column length
*****************************************/
template<typename T>
Array2D<T>::Array2D(int row, int column) : m_rows(row), m_columns(column), m_array()
{
	if (m_columns >= 0 && m_rows >= 0)
	{
		m_array.SetLength(m_columns * m_rows);
	}
	else
	{
		throw Exception("cannot have column or row length below 0");
	}
}


/*****************************************
* Purpose: Constructs Array2D<T> object by copying another Array2D<T>'s parameters
*
* Precondition:
*
* Postcondition:
*		new object with same parameters as copy are made
*****************************************/
template<typename T>
Array2D<T>::Array2D(const Array2D<T>& copy) : m_rows(copy.m_rows), m_columns(copy.m_columns), m_array(copy.m_array)
{

}


/*****************************************
* Purpose: Constructs Array2D<T> object by moving data from another Array2D<T>
*
* Precondition:
*
* Postcondition:
*		new object with parameters moved from copy
*****************************************/
template<typename T>
Array2D<T>::Array2D(Array2D<T>&& copy) : m_rows(std::move(copy.m_rows)), m_columns(std::move(copy.m_columns)), m_array(std::move(copy.m_array))
{

}


/*****************************************
* Purpose: assigns Array2D<T> object's parameters by copying rhs's parameters
*
* Precondition:
*
* Postcondition:
*		current object and rhs object have copies of the same parameters
*****************************************/
template<typename T>
Array2D<T>& Array2D<T>::operator =(const Array2D<T>& rhs)
{
	if (this != &rhs)
	{
		m_rows = rhs.m_rows;
		m_columns = rhs.m_columns;
		m_array = rhs.m_array;
	}
	return *this;
}


/*****************************************
* Purpose: assigns Array2D<T> object's parameters by copying rhs's parameters
*
* Precondition:
*
* Postcondition:
*		moves data from rhs to current object
*		if self assignment, doesn't do anything
*		resets rhs' parameters to default state
*****************************************/
template<typename T>
Array2D<T>& Array2D<T>::operator =(Array2D<T>&& rhs)
{
	if (this != &rhs)
	{
		m_rows = rhs.m_rows;
		m_columns = rhs.m_columns;
		m_array = rhs.m_array;
		rhs.m_array.SetLength(0);
		rhs.m_columns = 0;
		rhs.m_rows = 0;
	}
	return *this;
}


/*****************************************
* Purpose: resets current object's parameters to default values
*
* Precondition:
*
* Postcondition:
*		current object's data has been reset to default parameter values
*****************************************/
template<typename T>
Array2D<T>::~Array2D()
{
	m_rows = 0;
	m_columns = 0;
	m_array.SetLength(0);
}


/*****************************************
* Purpose: Return amount of columns in Array2D
*
* Precondition:
*
* Postcondition:
*		Returns m_columns
*****************************************/
template<typename T>
int Array2D<T>::getColumns() const
{
	return m_columns;
}


/*****************************************
* Purpose: Return amount of rows in Array2D
*
* Precondition:
*
* Postcondition:
*		Returns m_rows
*****************************************/
template<typename T>
int Array2D<T>::getRow() const
{
	return m_rows;
}


/*****************************************
* Purpose: changes length of array and sets m_rows to input value
*
* Precondition:
*
* Postcondition:
*		if rows input is negative, throws exception
*		sets m_rows to input value
*		changes length of array based on new rows value
*		keeps data integrity
*****************************************/
template<typename T>
void Array2D<T>::setRows(int rows)
{
	if (rows >= 0)
	{
		m_rows = rows;
		m_array.SetLength(m_rows * m_columns);
	}
	else
	{
		throw Exception("cannot change rows to be at or below 0");
	}
}


/*****************************************
* Purpose: changes length of array and sets m_columns to input value
*
* Precondition:
*
* Postcondition:
*		if columns input is negative, throws exception
*		sets m_rows to input value
*		changes length of array based on new column's value
*		keeps data integrity
*****************************************/
template<typename T>
void Array2D<T>::setColumns(int columns)
{
	if (columns >= 0)
	{

		Array<T> temp(m_rows * columns);
		int j = 0;
		for (int i = 0; i < m_rows; ++i)
		{
			for (int j = 0; j < m_columns && j < columns; ++j)
			{
				temp[columns * i + j] = m_array[m_columns * i + j];
			}
		}
		m_array = temp;
		m_columns = columns;
	}
	else
	{
		throw Exception("cannot change columns to be negative");
	}
}


/*****************************************
* Purpose: Returns Row object to allow use of 2 subscript operators (i.e Array2D<T> [][])
*
* Precondition:
*
* Postcondition:
*		Returns Row<T> by value so that it makes a copy (the Row<T> created goes out of scope after this function
*****************************************/
template <typename T>
Row<T> Array2D<T>::operator [](int row) const
{
	const Row<T> a(*this, row);
	return a;
}


/*****************************************
* Purpose: Selects proper element to return to Row's subscript operator based on the input parameters
*
* Precondition:
*
* Postcondition:
*		Returns T by ref at location [desired_row][desired_column]
*		if either value goes out of scope (negative or above array length) throws exception
*****************************************/
template<typename T>
T& Array2D<T>::Select(int desired_row, int desired_column) const
{
	if (desired_row  < 0 || desired_row >= m_rows)
	{
		throw  Exception("Row index is out of bounds of array");
	}
	else if (desired_column < 0 || desired_column >= m_columns)
	{
		throw Exception("Column index is out of bounds of array");
	}
	return m_array[desired_row * m_columns + desired_column];
}